
R e a d m e . t x t 

ADSP-BF548 EZ-KIT Flash Programmer Driver
-- Intel. PC28F128 --

Date Modified:		3/07/07 

_____________________________________________________________________

C o n t e n t s 

I.    Overview
II.   Required Hardware
III.  Deliverables

NOTE:  Flash programmer drivers must be built to include symbolic information
       and the symbols must be globally defined.
       
I. Overview

The flash programmer driver is an example that demonstrates the use
of flash driver to implement new algorithms, modify existing ones, 
or add support for a new flash device/DSP combination. After creating 
the flash driver, you must load it onto the DSP using the ADI Flash 
Programmer utility.The Flash Programmer is installed with VisualDSP++ 
and is accessible from the "Tools" pull-down menu

The program includes all the source code for the top-end dxe and the 
flash specific library. The library adheres to the ADI Driver Model 
which is new in VDSP++ and has a straight-forward API and powerful 
support libraries that simplify the process of creating custom drivers 
and applications.


II. Required Hardware 

The hardware requirements of the flash driver example are:

 * Blackfin ADSP-BF548 EZ-KIT Lite evaluation system
 * High-Performance PCI Emulator, HP-USB ICE, or Blackfin ADSP-BF548 
   EZ-KIT Lite evaluation system (using supplied USB debug agent)


III. Deliverables

All the flash driver examples ship pre-built but you can rebuild them
yourself.  The source files for both the top-end dxe and the flash 
specific library are included in the directory structure shown below:

+---Blackfin
    +---Examples
    �   +---ADSP-BF548 EZ-KIT Lite
    �       +---Flash Programmer 	
    �           +---Burst    [Top-end dxe]
    �		       BF548EzFlashDriver_PC28f128.dpj
    �		       BF548EzFlashDriver_PC28f128.dxe
    �		       main.c
    �		       Readme.txt
    +---include
    |   +---drivers
    |       +---flash				[Flash header files]
    |           adi_pc28f128k.h
    |           Errors.h
    |           util.h
    |           adi_flash.h
    +---lib
    	+---src
    	    +---drivers
    	        +---flash
    	            +---PC28F128K 	[Flash specific library]
                            adi_pc28f128k.c
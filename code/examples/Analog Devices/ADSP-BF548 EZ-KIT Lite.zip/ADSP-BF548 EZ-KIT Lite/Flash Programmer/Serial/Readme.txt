****************************************************************************************************

ADSP-BF548 EZ-KIT Flash Programmer Driver (Serial Flash)
-- STMicro M25P16  (16MBit) --

Analog Devices, Inc.
DSP Division
Three Technology Way
Norwood, MA 02062

Date Created: 06/27/07 

____________________________________________________________________

This directory contains an example ADSP-BF548 EZ-KIT Flash Programmer 
(Serial Flash) Driver Project. 

Files contained in this directory:

BF548EzFlashDriver_M25P16.dpj	VisualDSP project file
BF548EzFlashDriver_M25P16.dxe	Pre-Built Executable
main_m25p16.c			Main Module
Readme.txt 			This file

____________________________________________________________________________________________________

CONTENTS

I. FUNCTIONAL DESCRIPTION
II. IMPLEMENTATION DESCRIPTION
III. OPERATION DESCRIPTION


I. FUNCTIONAL DESCRIPTION

The flash programmer driver is an example that demonstrates the use
of flash driver to implement new algorithms, modify existing ones, 
or add support for a new flash device/DSP combination. After creating 
the flash driver, you must load it onto the DSP using the ADI Flash 
Programmer utility.The Flash Programmer is installed with VisualDSP++ 
and is accessible from the "Tools" pull-down menu

The program includes all the source code for the top-end dxe and the 
flash specific library. The library adheres to the ADI Driver Model 
which is new in VDSP++ 4.5 and has a straight-forward API and powerful 
support libraries that simplify the process of creating custom drivers 
and applications.


II. IMPLEMENTATION DESCRIPTION

The harware requirements of the flash driver example are:

 * Sharc ADSP-BF548 EZ-KIT Lite evaluation system
 * High-Performance PCI Emulator, HP-USB ICE, or Sharc ADSP-BF548 
   EZ-KIT Lite evaluation system (using supplied USB debug agent)

EZ-KIT Lite switch and jumper settings:
	- SW1	Position 3(Boot from serial SPI memory).
	- SW2	ALL ON.
	- SW4	1 = ON,  2 = ON,  3 = OFF, 4 = OFF.
	- SW5	ALL ON.
	- SW6	1 = OFF, 2 = OFF, 3 = ON,  4 = ON.
	- SW7	1 = ON,  2 = ON,  3 = ON,  4 = OFF.
	- SW8	ALL OFF.
	- SW14	ALL ON.
	- SW15	1 = OFF, 2 = OFF, 3 = ON,  4 = ON.
	- SW16	ALL ON.
	- SW17	1 = ON,  2 = OFF, 3 = ON,  4 = OFF.
	
	- JP1-3,7,8: OFF
	- JP4-6: ON
	- JP11:	ON ON


III. OPERATION DESCRIPTION (DELIVERABLES)

All the flash driver examples ship pre-built but you can rebuild them
yourself.  The source files for both the top-end dxe and the flash 
specific library are included in the directory structure shown below:


+---Sharc
    +---Examples
    �   +---ADSP-BF548 EZ-KIT Lite
    �       +---Flash Programmer 	[Top-end dxe]
    �			BF548EzFlashDriver_M25P16.dpj
    �			BF548EzFlashDriver_M25P16.dxe
    �			main_m25p16.c
    �			Readme.txt
    +---lib
    �  	+---src
    �	    +---drivers
    �	        +---flash
    �               +---M25P16 	[Flash specific library]
    �                       adi_m25p16.c
    �                      
    +---include
    	+---drivers
    	    +---flash
            �	    adi_flash.h
            �       adi_m25p16.h       
            �       Errors.h
            �	    Services_Sharc.h   
            �       util.h
                    
		    
         
     
_____________________________________________________________________
		

 /////////////////////////////////////////////////////////////////////////////
//
// Example C program using Background Telemetry Channel (BTC)
// Analog Devices 2004
//
// This program defines several BTCs to allow transfer of data over the BTC
// interface while the DSP is running.  Use the BTC Memory window in the
// debugger to view each channels data.  The defined channels are described
// below:
// 
// Timer Interrupt Counter:  This channel is defined to be 1-word (4-bytes)
//		   				     in length and simply counts the number of timer
//							 interrupts that have occured.
//
// PB2 Counter: This channel is defined to be 1-word (4-bytes) in length and
//			     simply counts the number of times the PB2 pushbutton is pressed
//				 on the BF533 Ez-Kit. (Must have SW5.1 set to ON for PB2 pushbutton to work)
//
// PB3 Counter: This channel is defined to be 1-word (4-bytes) in length and
//			     simply counts the number of times the PB3 pushbutton is pressed
//				 on the BF533 Ez-Kit. (Must have SW5.2 set to ON for PB3 pushbutton to work)
//
// 256 word channel (PB2): This channel is defined to be 256-words (1024-bytes) in length and
//			     			simply counts the number of times the PB2 pushbutton is pressed
//				 			on the BF533 Ez-Kit.  Each word in the channel is updated with the count.
//
// 256 word channel (PB21): This channel is defined to be 256-words (1024-bytes) in length and
//			     			simply counts the number of times the PB21 pushbutton is pressed
//				 			on the BF533 Ez-Kit.  Each word in the channel is updated with the count.
//
// 4k byte channel:   This channel is defined to be 4-kbytes in length.  The first word of the
//					  channel is used to count the number of timer interrupts that have occured.
//
/////////////////////////////////////////////////////////////////////////////
//#include <defbf548.h>
//#include <def_lpblackfin.h>
#include <cdefBF548.h>
#include <ccblkfn.h>
#include <sys/exception.h>
#include "btc.h"

////////////////////////
// function prototypes
////////////////////////
void initTimer(void);
void initGPIO(void);

/////////////////////////////////
// interrupt handler prototypes
/////////////////////////////////
EX_INTERRUPT_HANDLER(timerISR);		// timer interrupt handler
EX_INTERRUPT_HANDLER(int12ISR);		// int12 interrupt handler (pushbuttons)

/////////////////////
// global variables
/////////////////////
int timerCounter;		// counts the number of timer interrupts that have fired
int pbCounter;			// counts the number of times any pushbutton on the ez-kit was pressed
int PB2Counter;			// counts the number of times the PB2 pushbutton on the ez-kit was pressed
int PB3Counter;			// counts the number of times the PB3 pushbutton on the ez-kit was pressed

int PB2Array[0x100];		// a 256-word array
int PB3Array[0x100];		// a 256-word array

char array1[0x1000];		// a 4k-byte array

////////////////////
// BTC Definitions
////////////////////
BTC_MAP_BEGIN
//             Channel Name,             Starting Address,    Length
BTC_MAP_ENTRY("Timer Interrupt Counter", (long)&timerCounter, sizeof(timerCounter))
BTC_MAP_ENTRY("PB2 Counter",            (long)&PB2Counter,  sizeof(PB2Counter))
BTC_MAP_ENTRY("PB3 Counter",            (long)&PB3Counter,  sizeof(PB3Counter))
BTC_MAP_ENTRY("256 word channel (PB2)", (long)&PB2Array, 	  sizeof(PB2Array))
BTC_MAP_ENTRY("256 word channel (PB3)", (long)&PB3Array, 	  sizeof(PB3Array))
BTC_MAP_ENTRY("4k byte channel",         (long)&array1, 	  sizeof(array1))
BTC_MAP_END

///////////////
// main
///////////////
void main()
{
	// an example of getting the starting address and length of
	// a defined channel using macros defined in btc.h
	int addr, len;
	addr = BTC_CHANNEL_ADDR(0);
	len  = BTC_CHANNEL_LEN(0);
	
	// install our interrupt handlers
   	register_handler(ik_ivg12, int12ISR);	
   	register_handler(ik_timer, timerISR);
      
   	// initialize the timer and the programmable flags
   	initTimer();
   	initGPIO();

	// initialize the BTC
	btc_init();
	
	// this is the polling loop for servicing all BTC transactions
	while (1)
		btc_poll();
	
}

//////////////////////
// initTimer
//////////////////////
void initTimer()
{
		
	*pTCNTL = TMPWR | TAUTORLD;				// timer control register
	*pTPERIOD = 0x00040000;					// timer period register
	*pTSCALE = 0x00000080;					// timer scale register
	*pTCOUNT = 0x00040000;					// timer count register
	*pTCNTL = TMPWR | TMREN | TAUTORLD;		// enable the timer
}


/////////////////////
// initGPIO
/////////////////////
void initGPIO()
{

	*pPORTG_FER 		= 0x0000;		// Setup PG4 - PG9 for LEDs
	*pPORTG_MUX 		= 0x0000;		// Turn all LEDs on
	*pPORTG_DIR_SET		= 0x0FC0;		// Setup port for output
	*pPORTG_CLEAR		= 0x0FC0;		// Turn all LEDs off
/*
	*pPORTB_INEN		= 0x0C00;		// Enable input buffer
	*pPORTB_DIR_SET		&= (~0x0C00);	// Setup port for inputs		
	*pPINT0_INVERT_CLEAR = 0x0C00;
	*pPINT0_EDGE_SET 	 = 0x0C00;
	// unmask interrupts
    *pPINT0_MASK_SET 	= 0x0C00;
 */
  	*pPORTB_FER 		= 0x0000;	
    *pPORTB_MUX 		= 0x0000;
 	*pPORTB_INEN		= 0x0300;		// Enable input buffer
	*pPORTB_DIR_SET		&= (~0x0300);	// Setup port for inputs		

	*pPINT0_INVERT_CLEAR = 0x0300;
	*pPINT0_EDGE_SET 	 = 0x0300;
	// unmask interrupts
    *pPINT0_MASK_SET 	= 0x0300;
    
    *pSIC_IMASK0		= 0x00080000;	// System Interrupt Control Mask register
}



////////////////////////////
// timer interrupt handler
////////////////////////////
EX_INTERRUPT_HANDLER(timerISR)
{
	unsigned short *smmrPtr;
	int i;
	
	++timerCounter;							// count the timer interrupts
	for (i = 0; i < 4; ++i)
	{
		// update the first location of array1 with the timerCounter
		array1[i] = ((char*)&timerCounter)[i];
	}
	
	// toggle the timer LED
	smmrPtr = (unsigned short*)PORTG;
	*smmrPtr ^= (*smmrPtr & 0x40) | ( (timerCounter & 0x00000001) << 6);	// turn on the timer LED
	
}

////////////////////////
// interrupt12 handler
////////////////////////
EX_INTERRUPT_HANDLER(int12ISR)
{
	unsigned short *smmrPtr;
	unsigned long *memPtr;
	unsigned long length;
	unsigned short temp;
	bool bFlag = false;
	unsigned long i;
	unsigned char ucShift = 0;
	
	// figure out which push button was pressed and increment the appropriate
	// counter...if PB2-PB21 did not generate the interrupt then just return
	//smmrPtr = (unsigned short*)PORTB_SET;	// PB Set register
	
	temp = *pPINT0_LATCH;						// get which flags are currently set

	// clear interrupt request
    *pPINT0_IRQ = temp;
    
	// check if PB2 is set
	if (temp & 0x100)
	{
		++PB2Counter;
		PB2Array[0] = PB2Counter;
		bFlag = true;
		ucShift = 0xB;
	}
	// check if PB3 is set
	if (temp & 0x200)
	{
		++PB3Counter;
		PB3Array[0] = PB3Counter;
		bFlag = true;
		ucShift = 0xA;
	}
				
	// if any of PB2 or PB3 were set then update the LEDs
	if (bFlag)
	{
		smmrPtr = (unsigned short*)PORTG_CLEAR;		// PB Clear register
		*smmrPtr = temp;							// clear the input pins (PB2-PB5)
		
		++pbCounter;								// inc the global pushbutton counter
		
		// toggle the PB LED
		smmrPtr = (unsigned short*)PORTG;
		*smmrPtr ^= (*smmrPtr & 0xC00) | ((pbCounter & 0x00000001) << ucShift);
		
	}
}



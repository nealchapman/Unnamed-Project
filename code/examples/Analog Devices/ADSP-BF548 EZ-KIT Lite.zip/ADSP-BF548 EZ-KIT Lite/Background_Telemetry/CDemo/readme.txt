R e a d m e . t x t 

ADSP-BF548 EZ-KIT BTC CDemo

Date Modified:		23/1/07
			1/31/06
			11/16/05
_____________________________________________________________________

C o n t e n t s 

I.    Overview
II.   Required Hardware
III.  Operation Description
IV.   Deliverables


I. Overview
The BTC CDemo demonstrates transfering data from the Blackfin BF548 Ez-Kit Using C
over Background Telemetry Channels.  This is the most basic of demo programs.
The demo sets up a timer interrupt, and the timer ISR toggles the LED on the EZ-Kit.
During times when the interrupt is not being serviced, BTC transactions can occur.

II. Required Hardware:
1) Blackfin BF548 Ez-Kit.
2) High Performance PCI Emulator, HP-USB ICE, or BF548 EZ-Kit using supplied USB debug agent.

III. Operation Description:
1) Start the IDDE.
2) Select a HPPCI-ICE BF548 session (or EZ-Kit session)
3) Build and load the DSP program.
4) Open a BTC Memory Window (View->Debug Windows->BTC Memory)
7) Run the DSP Program.
8) Right-click on the BTC memory window and select "Auto Refresh"
9) In the BTC memory window, select a channel to view.

IV.   Deliverables

+---Blackfin
    +---Examples
    �   +---ADSP-BF548 EZ-KIT Lite
    �       +---Background_Telemetry 
    |			+---CDemo
    |				Btc_CDemo.dpj
    |				Btc_CDemo.asm
    |
    +---include
    |	btc.h
    |	btc_struct.h
    +---lib
    	libbtc532.dlb
    	

/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: ConfigureVideoOut.c,v $
$Revision: 1.1 $
$Date: 2007/05/14 18:16:13 $

Description:
        Example to show how to operate Pixel Compositor and EPPI 
        in parallel, and how to use Pixel Compositor for color conversion 
        (YUV422 to RGB888 or RGB888 to YUV422) and to handle overlays.
        
        This file contains video output device (LCD or ADV7179) 
        configuration and video output buffer preparation function.
        
        Refer to associsated text file for project information

*****************************************************************************/

/*****************************************************************************

Include files

*****************************************************************************/

#include "PixcVideoOut.h"                  				/* Project includes */

/*****************************************************************************

TWI Configuration table to access ADV7179 registers

*****************************************************************************/

/* Hardware TWI Configuration table for BF548 to access ADV7179 regs */
/* Run TWI clock at 100MHz & 50% Duty Cycle */
adi_twi_bit_rate rate={100,50};

ADI_DEV_CMD_VALUE_PAIR TWIConfig[]=
{ 
    { ADI_TWI_CMD_SET_HARDWARE, (void *)ADI_INT_TWI0    },  /* use hardware TWI port 0 */
    { ADI_TWI_CMD_SET_FIFO,     (void *)0x0000          },
    { ADI_TWI_CMD_SET_LOSTARB,  (void *)5               },
    { ADI_TWI_CMD_SET_RATE,     (void *)(&rate)         },     
    { ADI_TWI_CMD_SET_ANAK,     (void *)0               },
    { ADI_TWI_CMD_SET_DNAK,     (void *)0               },
    { ADI_DEV_CMD_END,          NULL                    }
};

/* IF (PixC output format is selected as RGB888)  */
#if defined(PIXC_OUTPUT_IMAGE_RGB888)
/*****************************************************************************

    Function:       ConfigureLcdVideoOut

    Description:    Opens and configures Sharp LQ043T1DG01 LCD
                    Also prepares 2D buffers for RGB Video out
                                        
*****************************************************************************/
u32 ConfigureLcdVideoOut(void)
{
    u32 Result = ADI_DEV_RESULT_SUCCESS;
    ADI_LQ043T1DG01_TIMER_FLAG  	Disp;	/* Disp flag info for Sharp LCD */
    u32 i;
    
    do
    {
        /* Open Sharp LQ043T1DG01 driver (Device 0) */
        if((Result = adi_dev_Open(  adi_dev_ManagerHandle,     		/* Dev manager Handle */
                     	            &ADILQ043T1DG01EntryPoint,      /* Device Entry point */
                                    0,                              /* Device number*/
	                                NULL,                           /* No client handle */
    	                            &VideoOutDriverHandle,          /* Device manager handle address */
        	                        ADI_DEV_DIRECTION_OUTBOUND,     /* Data Direction */
            	                    adi_dma_ManagerHandle,         	/* Handle to DMA Manager */
                	                NULL,                           /* Live callbacks */
                        	        VideoOutCallback))				/* Callback Function */
	        	!= ADI_DEV_RESULT_SUCCESS) 
        {
         	printf("Open Sharp LQ043T1DG01 LCD driver Failed!, Error Code: 0x%08X\n",Result);
         	break;
        }

        /**************** LQ043T1DG01 driver Configuration ****************/
    
        Disp.DispTimerId = LCD_DISP_TIMER_ID;	/* Timer ID used to generate DISP signal */
        Disp.DispFlagId  = LCD_DISP_FLAG_ID;	/* Flag pin connected to LCD DISP signal */
    
	    /* Set DISP Timer & Flag ID */
	    if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_LQ043T1DG01_CMD_SET_DISP_TIMER_FLAG, (void*)&Disp ))!= ADI_DEV_RESULT_SUCCESS)
	    {
		    printf("Failed to set DISP Timer & Flag ID, Error Code: 0x%08X\n",Result);
		    break;
        }
    
	    /* Set EPPI Device number */
	    if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_LQ043T1DG01_CMD_SET_EPPI_DEV_NUMBER, (void*)EPPI_DEV_NUMBER ))!= ADI_DEV_RESULT_SUCCESS)
	    {
		    printf("Failed to set EPPI device number for SHARP LQ043T1DG01 LCD out, Error Code: 0x%08X\n",Result);
		    break;
        }
    
        /* Open EPPI Device for LCD out */
	    if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_LQ043T1DG01_CMD_SET_OPEN_EPPI_DEVICE, (void*)TRUE ))!= ADI_DEV_RESULT_SUCCESS)
	    {
		    printf("Failed to open EPPI device for SHARP LQ043T1DG01 LCD out, Error Code: 0x%08X\n",Result);
		    break;
        }
	
	    /**************** EPPI Configuration ****************/

	    /* EPPI Control register configuration value for RGB out
    	    - EPPI as Output
        	  GP 2 frame sync mode, 
        	  Internal Clock generation disabled, Internal FS generation enabled,
      	      Receives samples on EPPI_CLK raising edge, Transmits samples on EPPI_CLK falling edge,
          	  FS1 & FS2 are active high, 
          	  DLEN = 6 (24 bits for RGB888 out) or 5 (18 bits for RGB666 out)
      	      DMA Unpacking disabled when RGB Formating is enabled, otherwise DMA unpacking enabled
          	  Swapping Disabled, 
          	  One (DMA) Channel Mode,
      	      RGB Formatting Enabled for RGB666 output, disabled for RGB888 output
          	  Regular watermark - when FIFO is 75% full, 
          	  Urgent watermark - when FIFO is 25% full 
	    */

    	/* EPPI Configuration table for Sharp LQ043T1DG01 LCD on the ADSP-BF548 Ez-Kit */
	    ADI_DEV_CMD_VALUE_PAIR EppiLcdConfig[]={
/* IF (RGB888 output selected) */
#if defined (LCD_OUTPUT_RGB888)	/* set EPPI for RGB888 (24-bit) output */
		    { ADI_EPPI_CMD_SET_DATA_LENGTH,             (void *)6       },  /* 24 bit out   */
		    { ADI_EPPI_CMD_ENABLE_RGB_FORMATTING,       (void *)FALSE   },  /* Disable RGB formatting */
#else	/* set EPPI for RGB666 (18-bit) output */
		    { ADI_EPPI_CMD_SET_DATA_LENGTH,             (void *)5       },  /* 18 bit out   */
		    { ADI_EPPI_CMD_ENABLE_RGB_FORMATTING,       (void *)TRUE   	},  /* Enable RGB formatting */
#endif
	    
    	    { ADI_EPPI_CMD_SET_PORT_DIRECTION,          (void *)1       },  /* Output mode  */
    	    { ADI_EPPI_CMD_SET_TRANSFER_TYPE,           (void *)3       },  /* GP mode      */
        	{ ADI_EPPI_CMD_SET_FRAME_SYNC_CONFIG,       (void *)2       },  /* GP2 mode     */
        	{ ADI_EPPI_CMD_ENABLE_INTERNAL_CLOCK_GEN,   (void *)TRUE    },  /* Internally generated Clock  */
    	    { ADI_EPPI_CMD_ENABLE_INTERNAL_FS_GEN,      (void *)TRUE    },  /* Internally generated Frame sync  */
    	    { ADI_EPPI_CMD_SET_CLOCK_POLARITY,          (void *)1       },  /* Tx raising edge, Rx falling edge */
        	{ ADI_EPPI_CMD_SET_FRAME_SYNC_POLARITY,     (void *)3       },  /* FS1 & FS2 active low	*/
        	{ ADI_EPPI_CMD_SET_SKIP_ENABLE,             (void *)FALSE   },  /* Disable skipping 	*/
	        { ADI_EPPI_CMD_SET_PACK_UNPACK_ENABLE,      (void *)TRUE    },  /* DMA unpacking enabled*/
        	{ ADI_EPPI_CMD_SET_SWAP_ENABLE,             (void *)FALSE   },  /* Swapping disabled 	*/
        	{ ADI_EPPI_CMD_SET_SPLIT_EVEN_ODD,          (void *)FALSE   },  /* Splitting diabled 	*/
    	    { ADI_EPPI_CMD_SET_FIFO_REGULAR_WATERMARK,  (void *)1      	},  /* Regular watermark  	*/
    	    { ADI_EPPI_CMD_SET_FIFO_URGENT_WATERMARK,   (void *)3       },  /* Urgent watermark 	*/
	        { ADI_DEV_CMD_END,                          NULL            }
    	}; 
    
        /* Configure EPPI Control register */
	    if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_DEV_CMD_TABLE, (void*)EppiLcdConfig ))!= ADI_DEV_RESULT_SUCCESS)
	    {
		    printf("Failed to configure EPPI control register for SHARP LQ043T1DG01 LCD out, Error Code: 0x%08X\n",Result);
		    break;
        }
    
        /****************** Buffer preparation for LCD Video out **********************/

        /* FOR (Number of output 2D buffers) */
        for (i = 0; i < NUM_FRAMES ; i++)  
        {
            VideoOutBuffer[i].Data              = pOutFrame;  
            VideoOutBuffer[i].ElementWidth      = DMA_BUS_SIZE;
            VideoOutBuffer[i].XCount            = (VIDEO_OUT_ACTIVE_DATA_PER_LINE/DMA_BUS_SIZE);
            VideoOutBuffer[i].XModify           = DMA_BUS_SIZE;
            VideoOutBuffer[i].YCount            = VIDEO_OUT_LINES_PER_FRAME;
            VideoOutBuffer[i].YModify           = DMA_BUS_SIZE;
            VideoOutBuffer[i].CallbackParameter = NULL;
            VideoOutBuffer[i].pNext             = &VideoOutBuffer[i + 1];   /* chain to next buffer in the list */
        }

        /* DMA generates Callback when last buffer in the chain is processed
           address of Pixel Compositor Output buffer as callback parameter */
        VideoOutBuffer[NUM_FRAMES - 1].CallbackParameter = &OutBufferPixc;
        /* Terminate this buffer chain */
        VideoOutBuffer[NUM_FRAMES - 1].pNext = NULL;

        /* fill RGB888 Output frame with background color */
   		adi_rgb888_FrameFill(pOutFrame,VIDEO_OUT_ACTIVE_DATA_PER_LINE,VIDEO_OUT_LINES_PER_FRAME,ADI_COLOR_BLACK);

    }while(0);
    
    /* return */
    return (Result);
}

/* ELSE (PixC output format is YUV422)  */
#else
/*****************************************************************************

    Function:       ConfigureItuVideoOut

    Description:    Opens and configures ADV717x device
                    Also prepares 2D buffers for ITU-R 656 Video out
                                        
*****************************************************************************/
u32 ConfigureItuVideoOut(void)
{
    u32 Result = ADI_DEV_RESULT_SUCCESS;
    ADI_DEV_ACCESS_REGISTER         ADV717x_Cfg;
    ADI_DEV_ACCESS_REGISTER_FIELD   FieldVal;
    u32 i;
    
    do
    {   
        /* open the AD7179 or EPPI driver for video out */
        if((Result = adi_dev_Open(  adi_dev_ManagerHandle,          /* Dev manager Handle */
                                    &ADIADV7179EntryPoint,          /* Device Entry point */
                                    0,                              /* Device number */
                                    NULL,                           /* No client handle */
                                    &VideoOutDriverHandle,          /* Device manager handle address */
                                    ADI_DEV_DIRECTION_OUTBOUND,     /* Data Direction */
                                    adi_dma_ManagerHandle,          /* Handle to DMA Manager */
                                    NULL,                           /* Live callbacks */
                                    VideoOutCallback))              /* Callback Function */
                    != ADI_DEV_RESULT_SUCCESS) 
        {
            printf("Failed to open Video output device, Error Code: 0x%8X\n",Result);
            break;
        }

        /************** Configure ADV7179 driver ***************/

        /* Set EPPI Device number */
        if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_ADV717x_CMD_SET_PPI_DEVICE_NUMBER, (void*)EPPI_DEV_NUMBER ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to set EPPI Device Number for ADV7179, Error Code: 0x%8X\n",Result);
            break;
        }

        /* Open the EPPI for ADV717x video out */
        if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_ADV717x_CMD_SET_PPI_STATUS, (void*)ADI_ADV717x_PPI_OPEN ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to open EPPI Device for ADV7179, Error Code: 0x%8X\n",Result);
            break;
        }
        
        /* Send TWI Configuration table */
        if((Result = adi_dev_Control(VideoOutDriverHandle,ADI_ADV717x_CMD_SET_TWI_CONFIG_TABLE,(void*)TWIConfig))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to set TWI Configuration Table, Error Code: 0x%8X\n",Result);
            break;
        }
            
        /************** Configure ADV7179 registers ***************/
    
        /* ADV717x register address to switch between NTSC & PAL */
        ADV717x_Cfg.Address = ADV717x_MR0;
    
#if defined(EPPI_OUT_PAL)  /* Configure ADV717x for PAL video out */

        /* MR0 value to set ADV717x in PAL mode */
        ADV717x_Cfg.Data = 0x05;
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_ADV717x_CMD_SET_SCF_REG, (void *) ADV717x_SCF_VALUE_PAL_BI))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("adi_dev_Control failed to configure ADV717x SCF Regs: 0x%8X\n",Result);
            break;
        }
#else                   /* Configure ADV717x for NTSC video out */

        /* MR0 value to set ADV717x in NTSC mode */
        ADV717x_Cfg.Data = 0x00;
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_ADV717x_CMD_SET_SCF_REG, (void *) ADV717x_SCF_VALUE_NTSC))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("adi_dev_Control failed to configure ADV717x SCF Regs: 0x%8X\n",Result);
            break;
        }
#endif 

        /* configure ADV717x in selected mode */
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_REGISTER_WRITE, (void *)&ADV717x_Cfg))!= ADI_DEV_RESULT_SUCCESS)  
        {
            printf("adi_dev_Control failed to configure ADV717x operating mode: 0x%8X\n",Result);
            break;
        }

        /**************** EPPI Configuration for ITU-R 656 out ****************/ 

        /* AD7179 configures EPPI in following mode
           GP0 ITU Interlaced out mode, IFSGEN, ICLKGEN and BLANKGEN disabled, DMA unpacking enabled
           Also configures EPPI Lines per frame and Samples per line for selected ITU mode
        */

        /* Configure EPPI to output ITU-R 656 Video with internally generated blank information (BLANKGEN enabled) */
        /* AD7179 driver handle can be used to configure EPPI registers, as AD7179 passes unrecogonised commands to EPPI */

#if defined(EPPI_OUT_PAL)   /* Build test for PAL frame */

	    ADI_DEV_CMD_VALUE_PAIR EppiItuAVOut[] =                                 	/* ITU-R 656 PAL Active video out with BLANKGEN enabled                 */
        {
            { ADI_EPPI_CMD_ENABLE_BLANKGEN,                     (void *)TRUE    },  /* Enable BLANKGEN                                                      */
            { ADI_EPPI_CMD_SET_FS1_WIDTH,                       (void *)280     },  /* Horizontal blanking samples per line                                 */
            { ADI_EPPI_CMD_SET_FIELD1_PRE_ACTIVE_DATA_VBLANK,   (void *)22      },  /* Vertical blank before start of Field 1 Active Data                   */
            { ADI_EPPI_CMD_SET_FIELD1_POST_ACTIVE_DATA_VBLANK,  (void *)2       },  /* Vertical blank after the end of Field 1 Active Data                  */
            { ADI_EPPI_CMD_SET_FIELD2_PRE_ACTIVE_DATA_VBLANK,   (void *)23      },  /* Vertical blank before start of Field 2 Active Data                   */
            { ADI_EPPI_CMD_SET_FIELD2_POST_ACTIVE_DATA_VBLANK,  (void *)2       },  /* Vertical blank after the end of Field 2 Active Data                  */
            { ADI_EPPI_CMD_SET_FS1_PERIOD,                      (void *)1440    },  /* Active Video samples per line or Vertical blanking samples per line  */
            { ADI_EPPI_CMD_SET_FIELD1_ACTIVE_DATA_LINES,        (void *)288     },  /* # of Active data lines in Field 1                                    */
            { ADI_EPPI_CMD_SET_FIELD2_ACTIVE_DATA_LINES,        (void *)288     },  /* # of Active data lines in Field 2                                    */
            { ADI_DEV_CMD_END,                                  NULL            }
        };
        
#else                   /* Build test for NTSC frame */
 
        ADI_DEV_CMD_VALUE_PAIR EppiItuAVOut[] =                                     /* ITU-R 656 NTSC Active video out with BLANKGEN enabled                */
        {
            { ADI_EPPI_CMD_ENABLE_BLANKGEN,                     (void *)TRUE    },  /* Enable BLANKGEN                                                      */
            { ADI_EPPI_CMD_SET_FS1_WIDTH,                       (void *)268     },  /* Horizontal blanking samples per line                                 */
            { ADI_EPPI_CMD_SET_FIELD1_PRE_ACTIVE_DATA_VBLANK,   (void *)16      },  /* Vertical blank before start of Field 1 Active Data                   */
            { ADI_EPPI_CMD_SET_FIELD1_POST_ACTIVE_DATA_VBLANK,  (void *)2       },  /* Vertical blank after the end of Field 1 Active Data                  */
            { ADI_EPPI_CMD_SET_FIELD2_PRE_ACTIVE_DATA_VBLANK,   (void *)17      },  /* Vertical blank before start of Field 2 Active Data                   */
            { ADI_EPPI_CMD_SET_FIELD2_POST_ACTIVE_DATA_VBLANK,  (void *)3       },  /* Vertical blank after the end of Field 2 Active Data                  */
            { ADI_EPPI_CMD_SET_FS1_PERIOD,                      (void *)1440    },  /* Active Video samples per line or Vertical blanking samples per line  */
            { ADI_EPPI_CMD_SET_FIELD1_ACTIVE_DATA_LINES,        (void *)243     },  /* # of Active data lines in Field 1                                    */
            { ADI_EPPI_CMD_SET_FIELD2_ACTIVE_DATA_LINES,        (void *)243     },  /* # of Active data lines in Field 2                                    */
            { ADI_DEV_CMD_END,                                  NULL            }
        };
    
#endif /* EPPI_OUT_PAL */

        /* Configure EPPI for ITU-R 656 out with Internal Blank generation */
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_TABLE, (void *)EppiItuAVOut ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to configure EPPI for Internal Blank generation, Error Code: 0x%8X\n",Result);
            break;
        }    
    
        /****************** Buffer preparation for ITU-R 656 Video out **********************/
        
        /* ITU-R 656 out must be interlaced. Split PixC output buffer in to two (Field 1 & Field 2) */
        /* FOR (Number of output 2D buffers for Field 1) */
        for (i = 0; i < ((NUM_FRAMES * 2)-1); i+=2)  
        {
            VideoOutBuffer[i].Data              = pOutFrame;  /* Field 1 line start */
            VideoOutBuffer[i].ElementWidth      = DMA_BUS_SIZE;
            VideoOutBuffer[i].XCount            = (VIDEO_OUT_ACTIVE_DATA_PER_LINE/DMA_BUS_SIZE);
            VideoOutBuffer[i].XModify           = DMA_BUS_SIZE;
            VideoOutBuffer[i].YCount            = VIDEO_OUT_LINES_PER_FRAME/2;
            VideoOutBuffer[i].YModify           = DMA_BUS_SIZE + VIDEO_OUT_ACTIVE_DATA_PER_LINE; /* skip to next line */
            VideoOutBuffer[i].CallbackParameter = NULL;
            VideoOutBuffer[i].pNext             = &VideoOutBuffer[i + 1];   /* chain to next buffer in the list */
        }
    
        /* FOR (Number of output 2D buffers for Field 2) */
        for (i = 1; i < (NUM_FRAMES * 2); i+=2)  
        {
            VideoOutBuffer[i].Data              = pOutFrame + VIDEO_OUT_ACTIVE_DATA_PER_LINE;	/* Field 2 line start */
            VideoOutBuffer[i].ElementWidth      = DMA_BUS_SIZE;
            VideoOutBuffer[i].XCount            = (VIDEO_OUT_ACTIVE_DATA_PER_LINE/DMA_BUS_SIZE);
            VideoOutBuffer[i].XModify           = DMA_BUS_SIZE;
            VideoOutBuffer[i].YCount            = VIDEO_OUT_LINES_PER_FRAME/2;
            VideoOutBuffer[i].YModify           = DMA_BUS_SIZE + VIDEO_OUT_ACTIVE_DATA_PER_LINE; /* skip to next line */
            VideoOutBuffer[i].CallbackParameter = NULL;
            VideoOutBuffer[i].pNext             = &VideoOutBuffer[i + 1];   /* chain to next buffer in the list */
        }
    
        /* DMA generates Callback when last buffer in the chain is processed
           address of Pixel Compositor Output buffer as callback parameter */
        VideoOutBuffer[(NUM_FRAMES*2) - 1].CallbackParameter = &OutBufferPixc;
        /* Terminate this buffer chain */
        VideoOutBuffer[(NUM_FRAMES*2) - 1].pNext = NULL;

        /* fill YUV422 Output frame with background color */
   		adi_yuv422_FrameFill(pOutFrame,VIDEO_OUT_ACTIVE_DATA_PER_LINE,VIDEO_OUT_LINES_PER_FRAME,ADI_COLOR_BLACK);
   		
    }while(0);
    
    /* return */
    return (Result);
}

#endif  /* PIXC_OUTPUT_IMAGE_RGB888 */

/*****/

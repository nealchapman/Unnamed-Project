/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: PixcVideoOut.c,v $
$Revision: 1.3 $
$Date: 2007/05/30 17:05:21 $

Description:
        Example to show how to operate Pixel Compositor and EPPI 
        in parallel, and how to use Pixel Compositor for color conversion 
        (YUV422 to RGB888 or RGB888 to YUV422) and to handle overlays.
        
        This is the project main source file
        
        Refer to associsated text file for project information

*****************************************************************************/

/*****************************************************************************

Include files

*****************************************************************************/

#include "PixcVideoOut.h"                  /* Project includes */

/*****************************************************************************

Memory locations to hold Input, Overlay and Output frames

*****************************************************************************/
/* Memory to hold Pixc Input Image frame */
section("sdram0_bank1")
static u8 InFrame[PIXC_IN_ACTIVE_DATA_PER_LINE * VIDEO_OUT_LINES_PER_FRAME];

/* Create Overlay frames */
#if defined (PIXC_OVERLAY_A_ENABLE) /* Overlay A enabled */
/* Memory to hold Overlay A frame */
section("sdram0_bank2")
static u8 OvrAFrame[OVRA_ACTIVE_DATA_PER_LINE  * OVRA_LINES_PER_FRAME ];
#endif  /* PIXC_OVERLAY_A_ENABLE */

#if defined (PIXC_OVERLAY_B_ENABLE) /* Overlay B enabled */
/* Memory to hold Overlay A frame */
section("sdram0_bank2")   
static u8 OvrBFrame[OVRB_ACTIVE_DATA_PER_LINE  * OVRB_LINES_PER_FRAME ];
#endif  /* PIXC_OVERLAY_B_ENABLE */

/* Memory to hold Pixc Output Image frame */
section("sdram0_bank3")
static u8 OutFrame [VIDEO_OUT_ACTIVE_DATA_PER_LINE * VIDEO_OUT_LINES_PER_FRAME];

/*****************************************************************************

Global data

*****************************************************************************/

/* Pointer to Input,Overlay and Output frames */
u8  *pInFrame,*pOvrAFrame,*pOvrBFrame,*pOutFrame;

/* handle to the Video Output driver */
ADI_DEV_DEVICE_HANDLE VideoOutDriverHandle;
/* handle to the PixC driver */
ADI_DEV_DEVICE_HANDLE PixcDriverHandle;

/* 2D buffers for Video out */
/* IF (PixC Output image format is selected as RGB888) */
#if defined(PIXC_OUTPUT_IMAGE_RGB888)
/* RGB (LCD) out is progressive and each frame has only 1 field */
ADI_DEV_2D_BUFFER VideoOutBuffer[NUM_FRAMES];
/* ELSE (PixC overlay format is YUV422) */
#else
/* ITU-R 656 is interlaced and each frame has 2 fields */
ADI_DEV_2D_BUFFER VideoOutBuffer[NUM_FRAMES*2];
#endif

/* 2D buffers for Pixc */
ADI_DEV_2D_BUFFER InBufferPixc, OvrABufPixc, OvrBBufPixc, OutBufferPixc;

ADI_PIXC_COLORS  OvrAColor;         /* Overlay A frame color     	*/
ADI_PIXC_COLORS  OvrBColor;      	/* Overlay B frame color     	*/
volatile u8   	 VideoOutEnable;    /* Video Output enable flag    	*/

/*****************************************************************************

Buffer Tables

*****************************************************************************/

/* Buffer table for PixC Inbound DMAs (image,overlay inputs) */   
ADI_DEV_BUFFER_PAIR     PixcInputBufs [] = 
{
    { ADI_DEV_2D,           (ADI_DEV_BUFFER *)&InBufferPixc },  /* PixC Image Buffer        */
#if defined(PIXC_OVERLAY_A_ENABLE)       /* Overlay A enabled? */
    { ADI_DEV_2D,           (ADI_DEV_BUFFER *)&OvrABufPixc  },  /* PixC Overlay Buffer(s)   */
#elif defined (PIXC_OVERLAY_B_ENABLE)    /* Overlay A disabled. Overlay B enabled? */
    { ADI_DEV_2D,           (ADI_DEV_BUFFER *)&OvrBBufPixc  },  /*PixC Overlay B Buffer only*/
#endif
    { ADI_DEV_BUFFER_END,   0                               }   /* Terminate buffer table   */
};

/*****************************************************************************

	Function:		ExceptionHandler
					HWErrorHandler

	Description:	We should never get an exception or hardware error,
					but just in case - display an error message 
					
*****************************************************************************/

static ADI_INT_HANDLER(ExceptionHandler)	        /* exception handler        */
{
	printf("Exception!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

static ADI_INT_HANDLER(HWErrorHandler)		        /* hardware error handler   */
{
	printf("HWerror!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

/*********************************************************************
*
*   Function:   main
*
*********************************************************************/
void main (void) 
{    
    u32 	ResponseCount, Result, i, Sense;

    printf("\nPixel Compositor: ");
    printf(PIXC_INPUT_IMAGE);
    printf(PIXC_OVRA_IMAGE);
    printf(PIXC_OVRB_IMAGE);
    printf(PIXC_OUTPUT_IMAGE);
    printf("EPPI: ");
    printf(EPPI_OUTPUT_MODE);

    /* Initialise pointers to Input,Overlay and Output frames */
    pInFrame    = &InFrame[0];
    pOutFrame   = &OutFrame[0];
    
/* IF (Overlay A enabled) */
#if defined (PIXC_OVERLAY_A_ENABLE) 
    pOvrAFrame  = &OvrAFrame[0];
#else
    pOvrAFrame  = NULL;
#endif  /* PIXC_OVERLAY_A_ENABLE */

/* IF (Overlay B enabled) */
#if defined (PIXC_OVERLAY_B_ENABLE)
    pOvrBFrame  = &OvrBFrame[0];
#else
    pOvrBFrame  = NULL;
#endif  /* PIXC_OVERLAY_B_ENABLE */

    do
    {
        /**************** Initialise System Services ****************/
    
        if ((Result = adi_ssl_Init()) != 0)
        {
            printf("Initialising System Services Failed! Error code: 0x%08X\n",Result);
            break;
        }

		/* crank up processor frequency to maximum */
        if ((Result = adi_pwr_SetFreq(0,0,ADI_PWR_DF_NONE)) != 0)
        {
            printf("Failed to set processor to maximum operating frequency! Error code: 0x%08X\n",Result);
            break;
        }

        /* hook the exception interrupt*/
	    if((Result = adi_int_CECHook(3, ExceptionHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook exception handler, Error Code: 0x%08X\n",Result);
		    break;
        }
        
        /* hook the hardware error*/
	    if((Result = adi_int_CECHook(5, HWErrorHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook hardware error handler, Error Code: 0x%08X\n",Result);
		    break;
        }
        
        /* Initialise the Pushbutton that is to be used to terminate this program */
        /* Open the Flag pin connected to the Terminate pushbutton */
        if((Result = adi_flag_Open(TERMINATE_BUTTON)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to open Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /* Set this flag as Input */
        if((Result = adi_flag_SetDirection(TERMINATE_BUTTON,ADI_FLAG_DIRECTION_INPUT)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to configure Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /******** Setup Pixel Compositor ********/
        
        /* Open Pixel Compositor */
        if ((Result = ConfigurePixc()) != ADI_DEV_RESULT_SUCCESS)
        {
            printf ("Failed to setup Pixel Compositor\n");
            break;
        } 
        
        /* Load PixC input frame with selected display pattern */
   		adi_Pixc_InputImage();
   		
        /****** Setup Video output device ******/
    
/* IF (PixC output format is selected as RGB888)  */
#if defined(PIXC_OUTPUT_IMAGE_RGB888)

        /* Open Sharp LQ043T1DG01 for RGB video out */
        if ((Result = ConfigureLcdVideoOut()) != ADI_DEV_RESULT_SUCCESS)
        {
            printf ("Failed to setup LCD Video Out\n");
            break;
        }
    
/* ELSE (PixC output format is YUV422)  */
#else

        /* Open ADV717x for ITU video out */
        if ((Result = ConfigureItuVideoOut()) != ADI_DEV_RESULT_SUCCESS)
        {
            printf ("Failed to setup ADV7179 Video Out\n");
            break;
        }
      
#endif  /* PIXC_OUTPUT_IMAGE_RGB888 */       
        
        /* Set Video output device Dataflow Method */
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW_METHOD, (void *)ADI_DEV_MODE_CHAINED_LOOPBACK ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to set dataflow method for video out, Error Code: 0x%08X\n",Result);
            break;
        }
        
        /********** Submit PixC buffers **********/
        
		/* Submit the PixC Input buffers*/
        if((Result = adi_dev_Write(PixcDriverHandle, ADI_DEV_BUFFER_TABLE, (ADI_DEV_BUFFER *) PixcInputBufs))!= ADI_DEV_RESULT_SUCCESS)
        {
        	printf("Failed to submit Input buffers for PixC, Error Code: 0x%08X\n",Result);
        	break;
        }

        /* submit the PixC Output buffer(s)*/
        if((Result = adi_dev_Read(PixcDriverHandle, ADI_DEV_2D, (ADI_DEV_BUFFER *) &OutBufferPixc))!= ADI_DEV_RESULT_SUCCESS)
        {
        	printf("Failed to submit Output buffers for PixC, Error Code: 0x%08X\n",Result);
           	break;
		}
			
		/* Enable PixC dataflow */
        if((Result = adi_dev_Control(PixcDriverHandle,ADI_DEV_CMD_SET_DATAFLOW, (void *) TRUE)) != ADI_DEV_RESULT_SUCCESS)
        {
        	printf("Failed to enable PixC dataflow, Error Code: 0x%08X\n",Result);
       	}      	
        
    }while(0);
    
    /* IF (Video Out & PixC configuration results in success) */
  	if (Result == ADI_DEV_RESULT_SUCCESS)
    {
    	printf("Pixel Compositor is up and running...\n");
    	printf("Press Pushbutton 4 (PB4) to terminate this program\n");
        /* continue color conversion/overlay/display frames until user presses the terminate button */
        while ((Result = adi_flag_Sense(TERMINATE_BUTTON, &Sense)) == ADI_DEV_RESULT_SUCCESS)
        {
            /* IF (Terminate button pressed) */
            if(Sense)
            {
                break;
            }
        }

        /* Disable video out data flow */
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW, (void *)FALSE))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to disable video out dataflow, Error Code: 0x%08X\n",Result);
        }
   	
    	/* close the video out device */
    	if((Result = adi_dev_Close(VideoOutDriverHandle)) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to close video output driver, Error Code: 0x%08X\n",Result);
    	}

    	/* close the pixel compositor device */
    	if((Result = adi_dev_Close(PixcDriverHandle)) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to close pixel compositor driver, Error Code: 0x%08X\n",Result);
    	}
    	
    	/* Terminate system services */
    	if((Result = adi_ssl_Terminate()) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to terminate system services, Error Code: 0x%08X\n",Result);
    	}    
	}
	else
	{
		printf("Program terminated abnormally with error code: 0x%08X\n",Result);
	}
	printf ("Done!\n");
}

/*****************************************************************************

    Function:       VideoOutCallback

    Description:    Each type of callback event has it's own unique ID 
                    so we can use a single callback function for all 
                    callback events.  The switch statement tells us 
                    which event has occurred.
                    
*****************************************************************************/
/* place this part of code in L1 */
section ("L1_code")
void VideoOutCallback(
    void        *AppHandle,
    u32         Event,
    void        *pArg
){

    u32   Result;
               
    /* CASEOF (event type) */
    switch (Event) 
    {
        /* CASE (buffer processed) */
        case ADI_DEV_EVENT_BUFFER_PROCESSED:        
       	
/* IF (Overlay A is enabled) */
#if defined(PIXC_OVERLAY_A_ENABLE)

			OvrAColor++;	/* Next color for Overlay A Frame */

			/* IF (Overlay A color ID is beyond ADI_PIXC_COLORS range) */
            if (OvrAColor >= ADI_COLOR_END)
            {
            	OvrAColor = ADI_COLOR_BLACK; /* reset overlay A frame color */
			}
            			
			OvrBColor = (ADI_PIXC_COLORS)(OvrAColor+1);	/* Next color for Overlay B Frame */
	
			/* IF (Overlay B color ID is beyond ADI_PIXC_COLORS range) */
       	    if (OvrBColor >= ADI_COLOR_END)
           	{
           		OvrBColor = ADI_COLOR_BLACK; /* reset overlay B frame color */
            	/* update PixC input image frame */
            	adi_Pixc_InputImage();
			}

/* IF (PixC overlay format is selected as RGB888)  */
#if defined(PIXC_OVERLAY_RGB888)
   	        /* update overlay A buffer with new RGB888 color */
       	    adi_rgb888_FrameFill(OvrABufPixc.Data,OVRB_PIXELS_PER_LINE,OVRA_LINES_PER_FRAME,OvrAColor);
/* ELSE (PixC overlay format is YUV422)  */
#else
           	/* update overlay A buffer with new YUV422 color */
            adi_yuv422_FrameFill(OvrABufPixc.Data,OVRA_ACTIVE_DATA_PER_LINE,OVRA_LINES_PER_FRAME,OvrAColor);
#endif  /* PIXC_OVERLAY_RGB888 */
#endif  /* PIXC_OVERLAY_A_ENABLE */


/* IF (Overlay B is enabled) */
#if defined(PIXC_OVERLAY_B_ENABLE)
/* IF (Overlay A is disabled) */
#if !defined(PIXC_OVERLAY_A_ENABLE)

			OvrBColor++;	/* Next color for Overlay B Frame */

			/* IF (Overlay B color ID is beyond ADI_PIXC_COLORS range) */
           	if (OvrBColor >= ADI_COLOR_END)
            {
   	        	OvrBColor = ADI_COLOR_BLACK; /* reset overlay B frame color */
            	/* update PixC input image frame */
            	adi_Pixc_InputImage();
			}

#endif
/* IF (PixC overlay format is selected as RGB888)  */
#if defined(PIXC_OVERLAY_RGB888)
           	/* update overlay B buffer with new RGB888 color */
            adi_rgb888_FrameFill(OvrBBufPixc.Data,OVRB_PIXELS_PER_LINE,OVRA_LINES_PER_FRAME,OvrBColor);
/* ELSE (PixC overlay format is YUV422)  */
#else
   	        /* update overlay B buffer with new YUV422 color */
       	    adi_yuv422_FrameFill(OvrBBufPixc.Data,OVRA_ACTIVE_DATA_PER_LINE,OVRA_LINES_PER_FRAME,OvrBColor);
#endif  /* PIXC_OVERLAY_RGB888 */
#endif  /* PIXC_OVERLAY_B_ENABLE */

/* IF (Overlay A is disabled) */
#if !defined(PIXC_OVERLAY_A_ENABLE)
/* IF (Overlay B is disabled) */
#if !defined(PIXC_OVERLAY_B_ENABLE)
            /* update PixC input image frame */
            adi_Pixc_InputImage();
#endif
#endif

			/******** Submit buffers to Pixel Compositor *********/
           
           	/* Submit the PixC Input buffers*/
           	if((Result = adi_dev_Write(PixcDriverHandle, ADI_DEV_BUFFER_TABLE, (ADI_DEV_BUFFER *) PixcInputBufs))!= ADI_DEV_RESULT_SUCCESS)
           	{
               	printf("VideoOutCallback: Failed to submit Input buffers for PixC, Error Code: 0x%08X\n",Result);
               	break;
           	}

           	/* submit the PIXC Output buffer(s)*/
           	if((Result = adi_dev_Read(PixcDriverHandle, ADI_DEV_2D, (ADI_DEV_BUFFER *) &OutBufferPixc))!= ADI_DEV_RESULT_SUCCESS)
           	{
               	printf("VideoOutCallback: Failed to submit Output buffers for PixC, Error Code: 0x%08X\n",Result);
           	}
           	
            break;

        /* CASE (DMA Error) */
        case ADI_DEV_EVENT_DMA_ERROR_INTERRUPT:         
            printf("VideoOutCallback: DMA error\n");
            break;

        default:
            printf("VideoOutCallback: Event not supported. Event code: 0x%08X \n",Event);
            break;
    }

    /* return */
}

/*****************************************************************************

    Function:       PixcCallback

    Description:    Each type of callback event has it's own unique ID 
                    so we can use a single callback function for all 
                    callback events.  The switch statement tells us 
                    which event has occurred.
                    
*****************************************************************************/
/* place this part of code in L1 */
section ("L1_code")
void PixcCallback(
    void    *AppHandle,
    u32     Event,
    void    *pArg
){
    
    ADI_DEV_2D_BUFFER   *pBuffer;
    u32                 Result;

    u32 i;
    
    /* CASEOF (event type) */
    switch (Event) 
    {    
        /* CASE (buffer processed) */
        case ADI_DEV_EVENT_BUFFER_PROCESSED:

        	/* Pointer to buffer holding PixC output */
          	pBuffer = (ADI_DEV_2D_BUFFER *)pArg;

/* IF (PixC output format is selected as YUV422)  */
#if !defined(PIXC_OUTPUT_IMAGE_RGB888)
/* IF (Enable PixC Color conversion workaround) */
#if !defined (ENABLE_PIXC_ITUR656_SUPPORT)
            /* convert PixC output to ITU-R 656 format */
            adi_swap_uv((u8*)pBuffer->Data, TRUE, VIDEO_OUT_LINES_PER_FRAME, VIDEO_OUT_ACTIVE_DATA_PER_LINE );
#endif /* ENABLE_PIXC_ITUR656_SUPPORT */
#endif      /* !defined PIXC_OUTPUT_IMAGE_RGB888 */
            
			/* IF (Video out dataflow is disabled) */
            if (!VideoOutEnable)
            {
            	/* submit this buffer for video out */
            	if((Result = adi_dev_Write(VideoOutDriverHandle, ADI_DEV_2D, (ADI_DEV_BUFFER *)pArg))!= ADI_DEV_RESULT_SUCCESS)
            	{
                	printf("PixC Callback: Failed to submit video out buffer, Error Code: 0x%08X\n",Result);
            	}
                /* Enable Video out data flow */
                if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW, (void *)TRUE))!= ADI_DEV_RESULT_SUCCESS)
                {
                    printf("PixC Callback: Failed to enable video out dataflow, Error Code: 0x%08X\n",Result);
                }
                else
                {
                    VideoOutEnable = TRUE; /* Mark as video out dataflow enabled */
                }
            }
            
            break;
            
        default:
            printf("PixC Callback: Event not supported. Event code: 0x%08X \n",Event);
            break;
    }
    
    /* return */
}

/*****/

Project Name: PixcVideoOut.dpj

Description: Example to show how to operate Pixel Compositor and EPPI in parallel, 
			 and how to use Pixel Compositor for (YUV422 to RGB888 or RGB888 to YUV422) color conversion 
             and to handle overlays.

Project Type:
=============
    ADSP-BF533 [ ]
    ADSP-BF537 [ ]
    ADSP-BF548 [X]
    ADSP-BF561 [ ]

Hardware/Tools Used:
====================
    ADSP-BF548 EZ-Kit Lite Rev 1.1
    Analog Devices VisualDSP++ 5.0
    ADDS HPUSB-ICE
    Blackfin AV Ez-Extender rev 2.0 (only used for ITU-R 656 output)
    
System Services Components Used:
================================
    DMA Manager                         [X]   Deferred Callback Manager   [X]
    Interrupt Manager                   [X]   Timer Module                [X]
    Power Management Module             [X]   Flag Module                 [X]
    External Bus Interface Unit Module  [X]   Port Module                 [X]

Overview:
=========

    This example outputs overlayed and/or color converted image to a selected display device.

    The program fills input frame with a display pattern seleced using macros. This display pattern is used 
    as the pixel compositor input image.
    
    If overlays are enabled, the program fills the overlay portion with a YUV422/RGB888 color value,
    again depending on Pixel compositor operating mode macros. The overlay color gets updated every display refresh cycle.

    Macros are provided to select Pixel compositor operating mode (input/overlay/output image formats).
    
    EPPI operating mode and display panel selection are based on Pixel Compositor output format seleced by the user. 
    
    EPPI 0 is used to display the final Pixel Compositor (Color converted and/or Overlayed) output to 
    selected display device (LCD or TV screen)

    The program can be terminated by pressing Pushbutton 4 (PB4) on the Ez-Kit
    
PixC Output mode and supported Display devices:
-----------------------------------------------
    When Pixel compositor output mode is YUV422, the Color converted result is displayed to a TV monitor.
    When Pixel compositor output mode is RGB888, the Color converted result is displayed to a supported LCD panel        

Supported LCD(s): 
-----------------
    SHARP LQ043T1DG01 LCD on Moab Ez-Kit

EPPI Configuration:
-------------------
    For YUV422 out, EPPI is configured in GP0 output mode with BLANKGEN enabled. EPPI tansmits the ITU-R 656 data 
    to ADV7179 on Blackfin AV Extender, which converts the obtained data to ITU-R 656 stream.

    For RGB888 out, EPPI is configured in GP2 Output mode, with RGB formatting disabled 
    For RGB666 out, EPPI is configured in GP2 Output mode, with RGB formatting disabled 

Protocols used:
---------------
    TWI to access ADV7179 hardware registers. 
    EPPI for Video dataflow

ADI Drivers and Services used:
------------------------------
    services.h          - system services
    adi_dev.h           - Device manager
    adi_eppi.h          - EPPI driver
    adi_pixc.h          - Pixel Compositor driver
    adi_twi.h           - TWI driver
    adi_device_access.h - To access ADV7179 device registers
    adi_adv717x.h       - ADV717x device driver
    adi_lq043t1dg01.h   - SHARP LQ043T1DG01 LCD driver

Dataflow:
---------
    Configure ADV7179 registers via TWI
    Image Overlay/Color conversion using Pixel Compositor.
    Video dataflow via EPPI.

** Note: Below macros are defined in project include file "UserConfigurations.h"

Macros to select Input Image Test pattern:
==========================================
Macro name  : EIGHT_COLOR_BAR_FILL
Macro Usage : Enable this macro to set Eight color bars as Pixel Compositor input image
              Disable macro to fill the input image frame with single color.

Macros to select Pixel Compositor operating mode:
=================================================

Macros to set Pixel Compositor Input,Overlay & Output format
------------------------------------------------------------
Macro name  : PIXC_INPUT_IMAGE_RGB888
Macro Usage : Enable this macro to set Pixel Compositor input image format as RGB888.
              Disable macro to set Pixel Compositor input image format as YUV422.

Macro name  : PIXC_OUTPUT_IMAGE_RGB888
Macro Usage : Enable this macro to set Pixel Compositor output image format as RGB888.
              Disable macro to set Pixel Compositor output image format as YUV422.

Macro name  : PIXC_OVERLAY_RGB888
Macro Usage : Enable this macro to set Pixel Compositor overlay image format as RGB888.
              Disable macro to set Pixel Compositor overlay image format as YUV422.

Macros to enable Pixel Compositor Overlay
-----------------------------------------

Macro name  : PIXC_OVERLAY_A_ENABLE
Macro Usage : Enable this macro to enable PixC Overlay A. Disable macro to disable Overlay A

Macro name  : PIXC_OVERLAY_A_ENABLE
Macro Usage : Enable this macro to enable PixC Overlay B. Disable macro to disable Overlay B

User configuration macros:
==========================

Macro name  : LCD_OUTPUT_RGB888
Macro Usage : Enable this macro for RGB888 (24-bit) output. Disable it for RGB666(18-bit) output.
              Make sure SW17 positions match the selected output mode.

Macro name  : EPPI_OUT_PAL
Macro Usage : Enable macro for for ITU-R 656 PAL output, disable for NTSC output. 
              This Macro is valid only when PixC output is in YUV422 format.
              
Macro name  : ENABLE_PIXC_ITUR656_SUPPORT
Macro Usage : YUV422 data to/from Pixel compositor is always in VYUY format. 
			  Enabling this macro sets PixC color conversion registers to support color conversion of
			  ITU-R 656 (UYVY) type YUV422 frame to/from RGB888 frame
              This woraround eliminates the need of any software data handling for applications
              invloving ITU-R 656 type YUV422 data to/from RGB888 data color conversion.
              Disabling this macro invokes a software routine that formats a YUV422 frame in VYUY format 
              to ITU-R 656 (UYVY) type YUV422 frame for video output (or) 
              ITU-R 656 (UYVY) type YUV422 frame to VYUY format for PixC color conversion.

Hardware Setup:
===============

For ITU-R 656 output:
---------------------
	Connect Blackfin A-V Extender to ADSP-BF548(Moab) Ez-Kit.

	ADSP-BF548 Ez-Kit Lite Settings:
    --------------------------------
	All switches to default position
	Then, 
	SW5:  1(ON), 2(ON),   3(ON),  4(ON)
	SW14: 1(OFF), 2(OFF), 3(OFF), 4(OFF)
	SW17: 1(OFF), 2(OFF), 3(OFF), 4(OFF)


	Blackfin A-V Ez-Extender jumper settings:
    -----------------------------------------
	JP1: No Jumpers installed
	JP2: No Jumpers installed
	JP3: 3-5, 4-6 (Connects to BF548 TWI 0)
	JP4: 1-3 (Connects 27MHz clock to EPPI0_CLK)
	JP5: 3-4 (Connects ADV7179 data port to EPPI0)
	JP6: No Jumpers installed
	JP7: No Jumpers installed
	JP8: No Jumpers installed
	JP9: 3-5 (Connects AV extender reset to system reset)
	JP10: No Jumpers installed

	External connections:
	---------------------
        Connect a monitor to the A-V Extender card video-out connector. The video 
        connectors are the bank of 6 RCA-style jacks on the A-V Extender card labeled as J7.
        
         J7 +---------------------------------------------------+
            |          O          O < Video Out  O              |               
            |          O          O              O              |
            +---------------------------------------------------+

For RGB888 LCD output:
---------------------
	Remove Blackfin A-V Extender from ADSP-BF548(Moab) Ez-Kit.
	
	ADSP-BF548 Ez-Kit Lite Settings:
    --------------------------------
	All switches to default position
	Then,
	SW14: 1(ON), 2(ON), 3(ON), 4(ON)
	SW17: 1(ON), 2(OFF), 3(ON), 4(OFF)

For RGB666 LCD output:
---------------------
	Remove Blackfin A-V Extender from ADSP-BF548(Moab) Ez-Kit.

	ADSP-BF548 Ez-Kit Lite Settings:
    --------------------------------
	All switches to default position
	Then,
	SW14: 1(ON), 2(ON), 3(ON), 4(ON)
	SW17: 1(ON), 2(ON), 3(OFF), 4(OFF)
  
References:
===========
    ADSP-BF548 Hardware reference
    ADSP-BF548 EZ-Kit Lite Schematic
    SHARP LQ043T1DG01 LCD driver hardware reference
    Blackfin AV Ez-Extender rev 2.0 schematic
    ADV7179 Hardware reference manual
/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: DisplayMode.h,v $
$Revision: 1.3 $
$Date: 2007/05/18 13:22:29 $

Description:
        Example to show how to operate Pixel Compositor and EPPI 
        in parallel, and how to use Pixel Compositor for color conversion 
        (YUV422 to RGB888 or RGB888 to YUV422) and to handle overlays.
        
        This file hold macros that defines Pixel Compositor Overlay A/B
        frame size and placement. Also, the fle contains macros defining 
        output display size, data format, and macros used to display project 
        build and important hardware information
		
        Refer to associsated text file for project information
        
*****************************************************************************/

/*****************************************************************************

Include files

*****************************************************************************/

#include "UserConfigurations.h"                 /* User configurations      */

/*****************************************************************************

Overlay size/placement defines

*****************************************************************************/

/************* Overlay A Defines *************/
/**** Donot overlap Overlay A & Overlay B Horizontal regions ****/
/* Overlay A Pixels per Line */
#define     OVRA_PIXELS_PER_LINE            20
/* Overlay A Lines per Frame */
#define     OVRA_LINES_PER_FRAME            20
/* Overlay A Horizontal Start pixel */
#define     ADI_PIXC_OVRA_HSTART            20
/* Overlay A Horizontal End pixel   */
#define     ADI_PIXC_OVRA_HEND              (ADI_PIXC_OVRA_HSTART + (OVRA_PIXELS_PER_LINE-1))
/* Overlay A Vertical Start pixel   */
#define     ADI_PIXC_OVRA_VSTART            20
/* Overlay A Horizontal End pixel   */
#define     ADI_PIXC_OVRA_VEND              (ADI_PIXC_OVRA_VSTART + (OVRA_LINES_PER_FRAME-1))
/* Overlay A Transparency Ratio (alpha) */
#define     ADI_PIXC_OVRA_ALPHA             15

/************* Overlay B Defines *************/
/**** Donot overlap Overlay A & Overlay B Horizontal regions ****/
/* Overlay B Pixels per Line */
#define     OVRB_PIXELS_PER_LINE            20
/* Overlay B Lines per Frame */
#define     OVRB_LINES_PER_FRAME            20
/* Overlay A Horizontal Start pixel */
#define     ADI_PIXC_OVRB_HSTART            380
/* Overlay A Horizontal End pixel   */
#define     ADI_PIXC_OVRB_HEND              (ADI_PIXC_OVRB_HSTART + (OVRB_PIXELS_PER_LINE-1))
/* Overlay A Vertical Start pixel   */
#define     ADI_PIXC_OVRB_VSTART            200
/* Overlay A Horizontal End pixel   */
#define     ADI_PIXC_OVRB_VEND              (ADI_PIXC_OVRB_VSTART + (OVRB_LINES_PER_FRAME-1))
/* Overlay A Transparency Ratio (alpha) */
#define     ADI_PIXC_OVRB_ALPHA             15

/*****************************************************************************

Display mode defines (derived from User configurations)

*****************************************************************************/
/************* Output image Defines *************/
/* IF (PixC output format is selected as RGB888)  */
#if defined(PIXC_OUTPUT_IMAGE_RGB888)

#define     NUM_FRAMES                      60  	/* color change rate for LCD            */
#define     VIDEO_OUT_PIXELS_PER_LINE    	480     /* # pixels per line for LCD out        */
#define     VIDEO_OUT_LINES_PER_FRAME    	272     /* # active lines per LCD frame         */
/* Video output active data per line*/
#define     VIDEO_OUT_ACTIVE_DATA_PER_LINE	(VIDEO_OUT_PIXELS_PER_LINE*3)	

/* ELSE (PixC output format is YUV422)  */
#else

/* # pixels per line for ITU-R 656 video*/
#define     VIDEO_OUT_PIXELS_PER_LINE		720		
/* Video output - active data per line for ITU-R 656 video   */
#define     VIDEO_OUT_ACTIVE_DATA_PER_LINE  (VIDEO_OUT_PIXELS_PER_LINE*2)

#if defined(EPPI_OUT_PAL)   /* build for ITU-R 656 PAL interlaced */
#define     NUM_FRAMES                      25      /* color change rate for PAL            */
#define     VIDEO_OUT_LINES_PER_FRAME    	576     /* # active lines per PAL frame         */
#else                       /* build for ITU-R 656 NTSC interlaced */
#define     NUM_FRAMES                      30      /* color change rate for NTSC           */
#define     VIDEO_OUT_LINES_PER_FRAME    	486     /* # active lines per NTSC frame        */
#endif      /* EPPI_OUT_PAL */

#endif      /* PIXC_OUTPUT_IMAGE_RGB888 */

/************* Input image Defines *************/
/* IF (PixC input format is selected as RGB888)  */
#if defined(PIXC_INPUT_IMAGE_RGB888)

/* # input active data per line for PixC */
#define     PIXC_IN_ACTIVE_DATA_PER_LINE	(VIDEO_OUT_PIXELS_PER_LINE*3)

/* ELSE (PixC input format is YUV422)  */
#else

/* # input active data per line for PixC */
#define     PIXC_IN_ACTIVE_DATA_PER_LINE   	(VIDEO_OUT_PIXELS_PER_LINE*2)

#endif  /* PIXC_INPUT_IMAGE_RGB888 */

/************* Overlay A Defines *************/
/* # Active data per line for this Overlay A frame */
/* IF (PixC overlay format is selected as RGB888) */
#if defined(PIXC_OVERLAY_RGB888)
#define     OVRA_ACTIVE_DATA_PER_LINE       (OVRA_PIXELS_PER_LINE*3)
/* ELSE (PixC overlay format is YUV422) */
#else
#define     OVRA_ACTIVE_DATA_PER_LINE       (OVRA_PIXELS_PER_LINE*2)
#endif  /* PIXC_OVERLAY_RGB888 */

/************* Overlay B Defines *************/
/* # Active data per line for this Overlay B frame */
/* IF (PixC overlay format is selected as RGB888) */
#if defined(PIXC_OVERLAY_RGB888)
#define     OVRB_ACTIVE_DATA_PER_LINE       (OVRB_PIXELS_PER_LINE*3)
/* ELSE (PixC overlay format is YUV422) */
#else
#define     OVRB_ACTIVE_DATA_PER_LINE       (OVRB_PIXELS_PER_LINE*2)
#endif  /* PIXC_OVERLAY_RGB888 */

/*****************************************************************************

Console output defines - displays project build information and 
reminds user about required hardware setup

*****************************************************************************/
/* IF (PixC input format is selected as RGB888)  */
#if defined(PIXC_INPUT_IMAGE_RGB888)
#define 	PIXC_INPUT_IMAGE    			"Input Image = RGB888, "
#define 	PIXC_INPUT_FRAME    			ADI_PIXC_FRAME_RGB888;      /* Input image is in RGB888 format	*/
/* ELSE (PixC input format is YUV422)  */
#else
#define 	PIXC_INPUT_IMAGE    			"Input Image = YUV422, "
#define 	PIXC_INPUT_FRAME    			ADI_PIXC_FRAME_YUV422;      /* Input image is in YUV422 format  */
#endif      /* PIXC_INPUT_IMAGE_RGB888 */

/* IF (PixC overlay A enabled)  */
#if defined(PIXC_OVERLAY_A_ENABLE)
/* IF (PixC overlay format is selected as RGB888)  */
#if defined(PIXC_OVERLAY_RGB888)
#define 	PIXC_OVRA_IMAGE     			"Overlay A = RGB888, "
#define 	PIXC_OVRA_FRAME     			ADI_PIXC_FRAME_RGB888;      /* Overlay in RGB888 format	*/
/* ELSE (PixC overlay format is YUV422)  */
#else
#define 	PIXC_OVRA_IMAGE     			"Overlay A = YUV422, "
#define 	PIXC_OVRA_FRAME     			ADI_PIXC_FRAME_YUV422;      /* Overlay in YUV422 format	*/
#endif  /* PIXC_OVERLAY_RGB888 */
/* ELSE (PixC overlay A disabled)  */
#else
#define 	PIXC_OVRA_IMAGE     			"Overlay A Disabled, "
#define 	PIXC_OVRA_FRAME     			ADI_PIXC_FRAME_DISABLE;     /* Overlay A frame disabled */
#endif  /* PIXC_OVERLAY_A_ENABLE */

/* IF (PixC overlay B enabled)  */
#if defined(PIXC_OVERLAY_B_ENABLE)
/* IF (PixC overlay format is selected as RGB888)  */
#if defined(PIXC_OVERLAY_RGB888)
#define 	PIXC_OVRB_IMAGE     			"Overlay B = RGB888, "
#define 	PIXC_OVRB_FRAME     			ADI_PIXC_FRAME_RGB888;      /* Overlay in RGB888 format	*/
/* ELSE (PixC overlay format is YUV422)  */
#else
#define 	PIXC_OVRB_IMAGE     			"Overlay B = YUV422, "
#define 	PIXC_OVRB_FRAME     			ADI_PIXC_FRAME_YUV422;      /* Overlay in YUV422 format	*/
#endif  /* PIXC_OVERLAY_RGB888 */
/* ELSE (PixC overlay B disabled)  */
#else
#define 	PIXC_OVRB_IMAGE     			"Overlay B Disabled, "
#define 	PIXC_OVRB_FRAME     			ADI_PIXC_FRAME_DISABLE;     /* Overlay B frame disabled */
#endif  /* PIXC_OVERLAY_A_ENABLE */

/* IF (PixC output format is selected as RGB888)  */
#if defined(PIXC_OUTPUT_IMAGE_RGB888)
#define 	PIXC_OUTPUT_IMAGE   			"Output = RGB888\n"
#define 	PIXC_OUTPUT_FRAME   			ADI_PIXC_FRAME_RGB888;      /* Output image is in RGB888 format	*/
/* IF (EPPI output is RGB888) */
#if defined(LCD_OUTPUT_RGB888)
#define 	EPPI_OUTPUT_MODE   				"RGB888 output to SHARP LQ043T1DG01 LCD\nRemove BF AV Extender, Set Ez-Kit SW17: 1(ON), 2(OFF), 3(ON), 4(OFF)\n"
/* ELSE (RGB666 output) */
#else
#define 	EPPI_OUTPUT_MODE   				"RGB666 output to SHARP LQ043T1DG01 LCD\nRemove BF AV Extender, Set Ez-Kit SW17: 1(ON), 2(ON), 3(OFF), 4(OFF)\n"
#endif
/* ELSE (PixC input format is YUV422)  */
#else
#define 	PIXC_OUTPUT_IMAGE   			"Output = YUV422\n"
#define 	PIXC_OUTPUT_FRAME   			ADI_PIXC_FRAME_YUV422;      /* Output image is in YUV422 format	*/
/* IF (EPPI ITU-R 656 PAL Output) */
#if defined(EPPI_OUT_PAL)
#define 	EPPI_OUTPUT_MODE   				"ITU-R 656 PAL interlaced out with Internal Blank generation\nSet Ez-Kit SW17: 1(OFF), 2(OFF), 3(OFF), 4(OFF)\n"
/* ELSE (ITU-R 656 NTSC Output) */
#else
#define 	EPPI_OUTPUT_MODE   				"ITU-R 656 NTSC interlaced out with Internal Blank generation\nSet Ez-Kit SW17: 1(OFF), 2(OFF), 3(OFF), 4(OFF)\n"
#endif
#endif      /* PIXC_INPUT_IMAGE_RGB888 */

/*****/

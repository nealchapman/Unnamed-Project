/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: HelperFunctions.c,v $
$Revision: 1.1 $
$Date: 2007/05/14 18:16:13 $

Description:

        Example to show how to operate Pixel Compositor and EPPI 
        in parallel, and how to use Pixel Compositor for color conversion 
        (YUV422 to RGB888 or RGB888 to YUV422) and to handle overlays.
        
        This file hold Helper functions used to fill Pixel Compositor
        Input,Overlay and Output image frames with display colors/patterns
        
        Refer to associsated text file for project information

*****************************************************************************/

/*****************************************************************************

Include files

*****************************************************************************/

#include "PixcVideoOut.h"                  				/* Project includes */

/*****************************************************************************

RGB888/YUV422 Color Table

*****************************************************************************/

/* Structure to hold YUV422 color values
   make sure the 'Yuv422Colors' array table id maps to 
   corresponding colors ids defined in ADI_PIXC_COLORS */
typedef struct {
    u8      Y;
    u8      U;
    u8      V;
} ADI_PIXC_YUV422_COLOR_TABLE;

/* Structure to hold RGB888 color values
   make sure the 'Rbg888Colors' array table id maps to 
   corresponding colors ids defined in ADI_PIXC_COLORS */
typedef struct {
    u8      R;
    u8      G;
    u8      B;
} ADI_PIXC_RGB888_COLOR_TABLE;

/* YUV422 values for colors listed in ADI_PIXC_COLORS */
ADI_PIXC_YUV422_COLOR_TABLE   Yuv422Colors [] = 
    {
        { 0x10, 0x80, 0x80 },   /* YUV for Black pixel  */
        { 0x51, 0x5A, 0xF0 },   /* YUV for Red pixel    */
        { 0x91, 0x36, 0x22 },   /* YUV for Green pixel  */
        { 0x29, 0xF0, 0x6E },   /* YUV for Blue pixel   */
        { 0xD2, 0x10, 0x92 },   /* YUV for Yellow pixel */
        { 0xAA, 0xA6, 0x10 },   /* YUV for Cyan pixel   */
        { 0x6A, 0xCA, 0xDE },   /* YUV for Magenta pixel*/
        { 0xEB, 0x80, 0x80 },   /* YUV for White pixel  */
    };

/* RGB888 values for colors listed in ADI_PIXC_COLORS */
ADI_PIXC_RGB888_COLOR_TABLE   Rgb888Colors [] = 
    {
        { 0x00, 0x00, 0x00 },   /* RGB for Black pixel  */
        { 0xFF, 0x00, 0x00 },   /* RGB for Red pixel    */
        { 0x00, 0xFF, 0x00 },   /* RGB for Green pixel  */
        { 0x00, 0x00, 0xFF },   /* RGB for Blue pixel   */
        { 0xFF, 0xFF, 0x00 },   /* RGB for Yellow pixel */
        { 0x00, 0xFF, 0xFF },   /* RGB for Cyan pixel   */
        { 0xFF, 0x00, 0xFF },   /* RGB for Magenta pixel*/
        { 0xFF, 0xFF, 0xFF },   /* RGB for White pixel  */        
    };

/* Array holding list of colors to be used for testing */
ADI_PIXC_COLORS DisplayColors[] =   {   ADI_COLOR_BLACK,    ADI_COLOR_RED,
                                        ADI_COLOR_GREEN,    ADI_COLOR_BLUE,
                                        ADI_COLOR_YELLOW,   ADI_COLOR_CYAN,
                                        ADI_COLOR_MAGENTA,  ADI_COLOR_WHITE
                                    };

/******************************************************************************
    Function:       adi_PixC_InputImage

    Description:    Fills PixC Input frame with the RGB888/YUV422 color
    
******************************************************************************/
void adi_Pixc_InputImage(void)
{
    u32	Line,ColorId,Pixel,DataPerLine,i;
    ADI_PIXC_COLORS	ColorCycle;
    u8	*pDataBuffer;   
    
    /* pointer to input image frame */
    pDataBuffer = pInFrame;
    
/* IF (PixC input format is selected as RGB888)  */
#if defined(PIXC_INPUT_IMAGE_RGB888)

/* load input image buffer with a RGB888 color */

/* Display pattern - Eight color bar fill */
#if defined (EIGHT_COLOR_BAR_FILL)
	/* FOR (each line) */ 
	for(Line = 1; Line <= VIDEO_OUT_LINES_PER_FRAME; Line++)
	{	
	    /* fill this line with 8 color bars */
	    for (ColorId = 0; ColorId<=7; ColorId++)
	    {
        	/* Fill a color block color */ 
			for (Pixel = 1; Pixel <= (VIDEO_OUT_PIXELS_PER_LINE/8); Pixel++ )
			{
            	*pDataBuffer++ = Rgb888Colors[DisplayColors[ColorId]].R;
            	*pDataBuffer++ = Rgb888Colors[DisplayColors[ColorId]].G;
            	*pDataBuffer++ = Rgb888Colors[DisplayColors[ColorId]].B;
			}
	    }
    }

/* Test pattern - Single color fill */
#else

    /* fill PixC input frame with RGB888 color */
    adi_rgb888_FrameFill(pDataBuffer,VIDEO_OUT_PIXELS_PER_LINE, VIDEO_OUT_LINES_PER_FRAME, DisplayColors[0]);
    
#endif

/* ELSE (PixC input format is YUV422)  */
#else

/* load input image buffer with a YUV422 color */

/* Test pattern - Eight color bar fill */
#if defined (EIGHT_COLOR_BAR_FILL)
	/* FOR (each line) */ 
	for(Line = 1; Line <= VIDEO_OUT_LINES_PER_FRAME; Line++)
	{	
	    /* fill this line with 8 color bars */
	    for (ColorId = 0; ColorId<=7; ColorId++)
	    {
        	/* Fill a color block with test color */ 
			for (DataPerLine = 1; DataPerLine <= (PIXC_IN_ACTIVE_DATA_PER_LINE/8); DataPerLine+=4 )
			{
            	*pDataBuffer++ = Yuv422Colors[DisplayColors[ColorId]].U;
            	*pDataBuffer++ = Yuv422Colors[DisplayColors[ColorId]].Y;
            	*pDataBuffer++ = Yuv422Colors[DisplayColors[ColorId]].V;
            	*pDataBuffer++ = Yuv422Colors[DisplayColors[ColorId]].Y;
			}
	    }
    }

/* Test pattern - Single color fill */
#else

    /* Fill PixC input frame with YUV422 color */
    adi_yuv422_FrameFill(pDataBuffer,PIXC_IN_ACTIVE_DATA_PER_LINE,VIDEO_OUT_LINES_PER_FRAME,DisplayColors[0]);

#endif   		
#endif  /* PIXC_INPUT_IMAGE_RGB888 */

	/* Cycle Test color array */
	ColorCycle = DisplayColors[0];
	for (i=0;i < (sizeof(DisplayColors)/sizeof(u32));i++)
	{
	    DisplayColors[i] = DisplayColors[i+1];
	}
	DisplayColors[(sizeof(DisplayColors)/sizeof(u32))-1] = ColorCycle;
}

/*****************************************************************************

    Function:       adi_yuv422_FrameFill

    Description:    Fills YUV422 frame with the given color (UYVY format) 
                    
*****************************************************************************/
void adi_yuv422_FrameFill(
    u8                  *pDataBuffer,       /* Pointer to YUV422 frame      */
    u32                 DataPerLine,        /* # Data per line              */
    u32                 LinesPerFrame,      /* # lines per frame            */
    ADI_PIXC_COLORS     Color               /* color id to fill with        */
)
{
    u32 i,j;

    /* FOR (each line) */
    for(i = 0; i < LinesPerFrame; i++)
    {
        /* FOR (each pixel) */ 
        for(j = 0; j < (DataPerLine / 4); j++)
        {
			/* fill with UYVY Data */
            *pDataBuffer++ = Yuv422Colors[Color].U;
            *pDataBuffer++ = Yuv422Colors[Color].Y;
            *pDataBuffer++ = Yuv422Colors[Color].V;
            *pDataBuffer++ = Yuv422Colors[Color].Y;
        }
    }

    /* return */
    return;
}

/*****************************************************************************

    Function:       adi_rgb888_FrameFill

    Description:    Fills RGB888 frame with the given color
                    
*****************************************************************************/
/* place this part of code in L1 */
section ("L1_code")
void adi_rgb888_FrameFill(
    u8                  *pDataBuffer,       /* Pointer to RGB888 frame      */
    u32                 PixelsPerLine,      /* # Pixels per line            */
    u32                 LinesPerFrame,      /* # lines per frame            */
    ADI_PIXC_COLORS     Color               /* color id to fill with        */
)
{
    u32 i,j;
    
    /* FOR (each line) */ 
    for(i = 0; i<LinesPerFrame; i++)
    {
        /* FOR (each pixel) */ 
        for (j = 0; j < PixelsPerLine; j++ )
        {
            *pDataBuffer++ = Rgb888Colors[Color].R;
            *pDataBuffer++ = Rgb888Colors[Color].G;
            *pDataBuffer++ = Rgb888Colors[Color].B;
        }
    }
    /* return */
    return;
}

/*****************************************************************************

    Function:       adi_swap_uv

    Description:    Converts the given YUV422 buffer to ITU656 supported format 
                    (OR) to Pixel Compositor supported format
    
                    Pass YuvOutFlag as TRUE to convert a buffer in 
                    Pixel Compositor format (VYUY) to ITU-R 656 format (UYVY)
                    
                    Pass YuvOutFlag as FALSE to convert a buffer in 
                    ITU-R 656 format (UYVY) to Pixel Compositor supported format (VYUY)                 
                    
*****************************************************************************/
/* place this part of code in L1 */
section ("L1_code")
void adi_swap_uv(
    u8      *pDataBuffer,   /* Pointer to YUV422 buffer */
    u8      YuvOutFlag,     /* TRUE to format above buffer for ITU-R 656 output, 
                               FALSE to format above buffer for Pixel Compositor input */
    u32     DataPerLine,    /* YUV422 data per line */
    u32     LinesPerFrame   /* Lines per frame */

){
    u32 i,j;
    u8  SwapData;
    
    u8  *pUData;    /* pointer to U sample */
    u8  *pVData;    /* pointer to V sample */
    
    /* IF (format buffer for ITU-R 656 output) */
    if (YuvOutFlag)
    {
        /* The given buffer is in Pixel compositor (VYUV) format */
        pVData = pDataBuffer;   /* point to first V sample in the given buffer */
        pUData = pDataBuffer+2; /* point to first U sample in the given buffer */
    }
    /* ELSE (format buffer for  Pixel Compositor input) */
    else
    {
        /* The given buffer is in ITU-R 656 (UYVV) format */
        pUData = pDataBuffer;   /* point to first U sample in the given buffer */
        pVData = pDataBuffer+2; /* point to first V sample in the given buffer */
    }
    
    /* FOR (each line) */ 
    for(i = 0; i<LinesPerFrame; i++)
    {
        /* FOR (each pixel) */ 
        for (j = 0; j < (DataPerLine / 4); j++ )
        {
            SwapData = *pVData;
            *pVData = *pUData;
            *pUData = SwapData;         
            pVData += 4;
            pUData += 4;
        }
    }
    /* return */
    return;
}

/*****/

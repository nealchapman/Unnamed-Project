/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: ConfigurePixc.c,v $
$Revision: 1.1 $
$Date: 2007/05/14 18:16:13 $

Description:
        Example to show how to operate Pixel Compositor and EPPI 
        in parallel, and how to use Pixel Compositor for color conversion 
        (YUV422 to RGB888 or RGB888 to YUV422) and to handle overlays.
        
        This file contains Pixel compositor configuration and 
        buffer preparation function for color conversion/overlay.
        
        Refer to associsated text file for project information

*****************************************************************************/

/*****************************************************************************

Include files

*****************************************************************************/

#include "PixcVideoOut.h"                  				/* Project includes */

/*****************************************************************************

    Function:       ConfigurePixc

    Description:    Opens and configures Pixel compositor for selected
                    color conversion mode.
                                        
*****************************************************************************/
u32 ConfigurePixc(void)
{
    u32 Result = ADI_DEV_RESULT_SUCCESS;
    /* structure to hold Pixel compositor coversion mode */
    ADI_PIXC_CONVERSION_MODE    	PixcMode;
    u32 i;
    
    do
    {    
        /* open the PixC driver */
        if((Result = adi_dev_Open(  adi_dev_ManagerHandle,          /* Dev manager Handle */
                                    &ADIPIXCEntryPoint,             /* Device Entry point */
                                    0,                              /* Device number    */
                                    NULL,                           /* No client handle */
                                    &PixcDriverHandle,              /* Device manager handle address */
                                    ADI_DEV_DIRECTION_BIDIRECTIONAL,/* Data Direction */
                                    adi_dma_ManagerHandle,          /* Handle to DMA Manager */
                                    NULL,                           /* Live callbacks */
                                    PixcCallback))                  /* Callback Function */
                    != ADI_DEV_RESULT_SUCCESS) 
        {
            printf("Open PixC Failed!, Error Code: 0x%8X\n",Result);
            break;
        }

        /************** Configure Pixel Compositor ***************/

        /* Pixel compositor operating mode */
        PixcMode.InputFrame     = PIXC_INPUT_FRAME;		/* Input Frame Format 	*/
        PixcMode.OverlayAFrame  = PIXC_OVRA_FRAME;		/* Overlay A Format 	*/
        PixcMode.OverlayBFrame  = PIXC_OVRB_FRAME;		/* Overlay B Format 	*/
        PixcMode.OutputFrame    = PIXC_OUTPUT_FRAME;	/* Output Frame Format 	*/
    
        /* Pixel Compositor Configuration table */
        ADI_DEV_CMD_VALUE_PAIR PixcConfig[]=
        { 
            { ADI_DEV_CMD_SET_DATAFLOW_METHOD,              (void *)ADI_DEV_MODE_CHAINED		},  /* Dataflow method                      */
            { ADI_PIXC_CMD_SET_COLOR_CONVERSION_MODE,       (void *)&PixcMode               	},  /* Pixel compositor operating mode      */
            { ADI_PIXC_CMD_SET_PIXELS_PER_LINE,             (void *)VIDEO_OUT_PIXELS_PER_LINE  	},  /* Pixels per line                      */
            { ADI_PIXC_CMD_SET_LINES_PER_FRAME,             (void *)VIDEO_OUT_LINES_PER_FRAME	},  /* Lines per frame                      */
            { ADI_PIXC_CMD_SET_TRANSPARENCY_COLOR_ENABLE,   (void *)FALSE                   	},  /* Disable Transparency                 */ 
            { ADI_PIXC_CMD_SET_OVERLAY_A_HSTART,            (void *)ADI_PIXC_OVRA_HSTART    	},  /* Overlay A Horizontal start (pixel)   */
            { ADI_PIXC_CMD_SET_OVERLAY_A_HEND,              (void *)ADI_PIXC_OVRA_HEND      	},  /* Overlay A Horizontal end (pixel)     */
            { ADI_PIXC_CMD_SET_OVERLAY_A_VSTART,            (void *)ADI_PIXC_OVRA_VSTART    	},  /* Overlay A Vertical start (line)      */
            { ADI_PIXC_CMD_SET_OVERLAY_A_VEND,              (void *)ADI_PIXC_OVRA_VEND      	},  /* Overlay A vertical end (line)        */
            { ADI_PIXC_CMD_SET_OVERLAY_A_TRANSPARENCY,      (void *)ADI_PIXC_OVRA_ALPHA     	},  /* Overlay A Transpareny ratio (alpha)  */
            { ADI_PIXC_CMD_SET_OVERLAY_B_HSTART,            (void *)ADI_PIXC_OVRB_HSTART    	},  /* Overlay B Horizontal start (pixel)   */
            { ADI_PIXC_CMD_SET_OVERLAY_B_HEND,              (void *)ADI_PIXC_OVRB_HEND      	},  /* Overlay B Horizontal end (pixel)     */
            { ADI_PIXC_CMD_SET_OVERLAY_B_VSTART,            (void *)ADI_PIXC_OVRB_VSTART    	},  /* Overlay B Vertical start (line)      */
            { ADI_PIXC_CMD_SET_OVERLAY_B_VEND,              (void *)ADI_PIXC_OVRB_VEND      	},  /* Overlay B vertical end (line)        */
            { ADI_PIXC_CMD_SET_OVERLAY_B_TRANSPARENCY,      (void *)ADI_PIXC_OVRB_ALPHA     	},	/* Overlay B Transpareny ratio (alpha)  */
            { ADI_DEV_CMD_END,                              NULL                            	}
        };

        /* Configure Pixel Compositor */
        if((Result = adi_dev_Control(PixcDriverHandle, ADI_DEV_CMD_TABLE, (void *) PixcConfig)) != ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to configure PixC, Error Code: 0x%08X\n",Result);
            break;
        }

/* IF (Enable PixC Color conversion workaround to support YUV422 (UYVY format) <-> RGB888 format conversion without handling the data) */
#if defined (ENABLE_PIXC_ITUR656_SUPPORT)
		
		/* Configure PixC to enable ITU-R 656 type YUV422 frame conversion support */
        if((Result = adi_dev_Control(PixcDriverHandle, ADI_PIXC_CMD_ENABLE_ITUR656_SUPPORT, (void *) TRUE)) != ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to enable ITU-R 656 type YUV422 frame conversion support, Error Code: 0x%08X\n",Result);
            break;
        }
        
#else	/* Disable ITU-R 656 type YUV422 frame conversion support */

		/* Configure PixC to disable ITU-R 656 type YUV422 frame conversion support */
        if((Result = adi_dev_Control(PixcDriverHandle, ADI_PIXC_CMD_ENABLE_ITUR656_SUPPORT, (void *) FALSE)) != ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to disable ITU-R 656 type YUV422 frame conversion support, Error Code: 0x%08X\n",Result);
            break;
        }

/* Test YUV to RGB color conversion ? */
#if ((!defined (PIXC_INPUT_IMAGE_RGB888) || ((defined(PIXC_OVERLAY_A_ENABLE) || defined(PIXC_OVERLAY_B_ENABLE)) && !defined (PIXC_OVERLAY_RGB888))) && defined (PIXC_OUTPUT_IMAGE_RGB888))
	  /* convert ITU656 type (UYVY) input image to PixC supported format (VYUY) */
	  adi_swap_uv((u8*)pInFrame, FALSE, VIDEO_OUT_LINES_PER_FRAME, PIXC_IN_ACTIVE_DATA_PER_LINE );
#endif
        
#endif /* ENABLE_PIXC_ITUR656_SUPPORT */

        /****************** Prepare PixC Input Image Buffer **********************/
        
        /* No callback generated for Pixel Compositor Input image buffers */    
        InBufferPixc.Data                   = pInFrame;
        InBufferPixc.ElementWidth           = DMA_BUS_SIZE;
        InBufferPixc.XCount                 = (PIXC_IN_ACTIVE_DATA_PER_LINE/DMA_BUS_SIZE);
        InBufferPixc.XModify                = DMA_BUS_SIZE;
        InBufferPixc.YCount                 = VIDEO_OUT_LINES_PER_FRAME;
        InBufferPixc.YModify                = DMA_BUS_SIZE;
        InBufferPixc.CallbackParameter      = NULL;
        InBufferPixc.pNext                  = NULL;

#if defined(PIXC_OVERLAY_A_ENABLE)      /* Overlay A enabled? */
        /* Overlay A buffer */
        OvrABufPixc.Data                    = pOvrAFrame;
        OvrABufPixc.ElementWidth            = DMA_BUS_SIZE;
        OvrABufPixc.XCount                  = (OVRA_ACTIVE_DATA_PER_LINE/DMA_BUS_SIZE);
        OvrABufPixc.XModify                 = DMA_BUS_SIZE;
        OvrABufPixc.YCount                  = OVRA_LINES_PER_FRAME;
        OvrABufPixc.YModify                 = DMA_BUS_SIZE;
        OvrABufPixc.CallbackParameter       = NULL;
        OvrABufPixc.pNext                   = NULL;
#endif

#if defined(PIXC_OVERLAY_B_ENABLE)      /* Overlay B enabled? */
        /* Overlay B buffer */
        OvrBBufPixc.Data                    = pOvrBFrame;
        OvrBBufPixc.ElementWidth            = DMA_BUS_SIZE;
        OvrBBufPixc.XCount                  = (OVRB_ACTIVE_DATA_PER_LINE/DMA_BUS_SIZE);
        OvrBBufPixc.XModify                 = DMA_BUS_SIZE;
        OvrBBufPixc.YCount                  = OVRB_LINES_PER_FRAME;
        OvrBBufPixc.YModify                 = DMA_BUS_SIZE;
        OvrBBufPixc.CallbackParameter       = NULL;
        OvrBBufPixc.pNext                   = NULL;    
#endif

#if defined(PIXC_OVERLAY_A_ENABLE)       /* both Overlay A and Overlay B enabled? */
#if defined(PIXC_OVERLAY_B_ENABLE)
        OvrABufPixc.pNext                   = &OvrBBufPixc;      /* Chain Overlay B buffer to Overlay A */
#endif
#endif
      
        /****************** Prepare PixC Output Image Buffer **********************/
       
        /* PixC Output buffer */
        OutBufferPixc.Data                  = pOutFrame;
        OutBufferPixc.ElementWidth          = DMA_BUS_SIZE;
        OutBufferPixc.XCount                = (VIDEO_OUT_ACTIVE_DATA_PER_LINE/DMA_BUS_SIZE);
        OutBufferPixc.XModify               = DMA_BUS_SIZE;
        OutBufferPixc.YCount                = VIDEO_OUT_LINES_PER_FRAME;
		OutBufferPixc.YModify           	= DMA_BUS_SIZE;
        OutBufferPixc.CallbackParameter     = &VideoOutBuffer[0];
        OutBufferPixc.pNext                 = NULL;

        /****************** Prepare Overlay Video Frames *******************/

	    OvrAColor	= ADI_COLOR_BLACK;	/* Overlay A frame Color id to start with 	*/
	    OvrBColor	= ADI_COLOR_RED;	/* Overlay B frame Color id to start with 	*/
		
/* IF (Overlay A is enabled) */
#if defined(PIXC_OVERLAY_A_ENABLE)
/* IF (PixC overlay format is selected as RGB888)  */
#if defined(PIXC_OVERLAY_RGB888)

        /* update overlay A buffer with new RGB888 color */
        adi_rgb888_FrameFill(OvrABufPixc.Data,OVRB_PIXELS_PER_LINE,OVRA_LINES_PER_FRAME,OvrAColor);
        
/* ELSE (PixC overlay format is YUV422)  */
#else

        /* update overlay A buffer with new YUV422 color */
        adi_yuv422_FrameFill(OvrABufPixc.Data,OVRA_ACTIVE_DATA_PER_LINE,OVRA_LINES_PER_FRAME,OvrAColor);
        
#endif  /* PIXC_OVERLAY_RGB888 */
#endif  /* PIXC_OVERLAY_B_ENABLE */

/* IF (Overlay B is enabled) */
#if defined(PIXC_OVERLAY_B_ENABLE)
/* IF (PixC overlay format is selected as RGB888)  */
#if defined(PIXC_OVERLAY_RGB888)

        /* update overlay B buffer with new RGB888 color */
        adi_rgb888_FrameFill(OvrBBufPixc.Data,OVRB_PIXELS_PER_LINE,OVRA_LINES_PER_FRAME,OvrBColor);
        
/* ELSE (PixC overlay format is YUV422)  */
#else
        /* update overlay B buffer with new YUV422 color */
        adi_yuv422_FrameFill(OvrBBufPixc.Data,OVRA_ACTIVE_DATA_PER_LINE,OVRA_LINES_PER_FRAME,OvrBColor);
        
#endif  /* PIXC_OVERLAY_RGB888 */
#endif  /* PIXC_OVERLAY_B_ENABLE */

    }while(0);
    
    /* return */
    return (Result);
}

/*****/

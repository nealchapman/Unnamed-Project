/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: PixcVideoOut.h,v $
$Revision: 1.1 $
$Date: 2007/05/14 18:16:13 $

Description:
        Example to show how to operate Pixel Compositor and EPPI 
        in parallel, and how to use Pixel Compositor for color conversion 
        (YUV422 to RGB888 or RGB888 to YUV422) and to handle overlays.
        
        This file holds processor specific macros, global data defines and
        function prototypes
		
        Refer to associsated text file for project information
        
*****************************************************************************/

/*****************************************************************************

Include files

*****************************************************************************/

#include <services/services.h>              	/* system service includes          	            */
#include <drivers/adi_dev.h>                	/* device manager includes          	            */
#include <drivers/encoder/adi_adv717x.h>    	/* ADV717x driver includes          	            */
#include <drivers/twi/adi_twi.h>            	/* TWI driver includes              	            */
#include <drivers/eppi/adi_eppi.h>          	/* EPPI driver includes             	            */
#include <drivers/pixc/adi_pixc.h>          	/* Pixel Compositor driver includes 	            */
#include <drivers/lcd/sharp/adi_lq043t1dg01.h>  /* SHARP LQ043T1DG01 LCD driver include             */
#include "adi_ssl_init.h"                   	/* System services init includes    	            */
#include "DisplayMode.h"                        /* Display mode derived from user configurations    */
#include <stdio.h>                          	/* for console Output               	            */

/*****************************************************************************

Processor specific macros

*****************************************************************************/
/* BF548 EPPI Device Number for Video out */
#define     EPPI_DEV_NUMBER                 0
/* Processor DMA bus size = 4 bytes */
#define     DMA_BUS_SIZE                    4
/* Processor Timer ID used to generate SHARP LQ043T1DG01 LCD DISP signal  */
#define     LCD_DISP_TIMER_ID               ADI_TMR_GP_TIMER_3
/* Processor Flag ID connected to SHARP LQ043T1DG01 LCD DISP signal       */
#define     LCD_DISP_FLAG_ID                ADI_FLAG_PE3
/* Use Pushbutton 4 (PB4) to terminate this program */
#define     TERMINATE_BUTTON                ADI_FLAG_PB11

/*****************************************************************************

List of YUV422/RGB888 color formats used by this program
Colors listed in order of display

*****************************************************************************/

typedef enum {
    ADI_COLOR_BLACK     = 0,
    ADI_COLOR_RED       = 1,
    ADI_COLOR_GREEN     = 2,
    ADI_COLOR_BLUE      = 3,
    ADI_COLOR_YELLOW    = 4,
    ADI_COLOR_CYAN      = 5,
    ADI_COLOR_MAGENTA   = 6,
    ADI_COLOR_WHITE     = 7,
    
    /* Add new colors here */
    
    ADI_COLOR_END,
} ADI_PIXC_COLORS;

/*****************************************************************************

Global data

*****************************************************************************/
/* Pointer to Input,Overlay and Output frames */
extern u8  *pInFrame,*pOvrAFrame,*pOvrBFrame,*pOutFrame;

/* handle to the Video Output driver */
extern ADI_DEV_DEVICE_HANDLE VideoOutDriverHandle;
/* handle to the PixC driver */
extern ADI_DEV_DEVICE_HANDLE PixcDriverHandle;

/* 2D buffers for Video out */
extern ADI_DEV_2D_BUFFER VideoOutBuffer[];

/* 2D buffers for Pixc */
extern ADI_DEV_2D_BUFFER InBufferPixc, OvrABufPixc, OvrBBufPixc, OutBufferPixc;

extern ADI_PIXC_COLORS  OvrAColor;         /* Overlay A frame color     	*/
extern ADI_PIXC_COLORS  OvrBColor;      	/* Overlay B frame color     	*/
extern volatile u8   	 VideoOutEnable;    /* Video Output enable flag    	*/

/* Buffer table - Buffer pair for PixC Inbound DMAs (image,overlay inputs) */   
extern ADI_DEV_BUFFER_PAIR     PixcInputBufs [];

/*****************************************************************************

Function prototypes

*****************************************************************************/

static ADI_INT_HANDLER(ExceptionHandler);   /* exception handler */

static ADI_INT_HANDLER(HWErrorHandler);     /* hardware error handler */

/* Video output Callback function */
void VideoOutCallback(
    void                *AppHandle, 
    u32                 Event,
    void                *pArg
);

/* PixC Callback function */
void PixcCallback(
    void                *AppHandle, 
    u32                 Event,
    void                *pArg
);

/* Opens and configures Sharp LQ043T1DG01 LCD for RGB888/RGB666 Video out */
u32 ConfigureLcdVideoOut(void);

/*Opens and configures ADV7179 device for ITU-R 656 Video out */
u32 ConfigureItuVideoOut(void);

/* Opens and configures Pixel compositor in selected color conversion/overlay mode */
u32 ConfigurePixc(void);

/* Fills PixC Input frame with the RGB888/YUV422 display pattern */
void adi_Pixc_InputImage(void);

/* Fills given buffer with YUV422 color value */
void adi_yuv422_FrameFill(
    u8                  *pDataBuffer,       /* Pointer to YUV422 frame      */
    u32                 DataPerLine,        /* # Data per line              */
    u32                 LinesPerFrame,      /* # lines per frame            */
    ADI_PIXC_COLORS     Color               /* color id to fill with        */
);

/* Fills given buffer with RGB888 color value */
void adi_rgb888_FrameFill(
    u8                  *pDataBuffer,       /* Pointer to RGB888 frame      */
    u32                 PixelsPerLine,      /* # Pixels per line            */
    u32                 LinesPerFrame,      /* # lines per frame            */
    ADI_PIXC_COLORS     Color               /* color id to fill with        */
);

/* Converts the given YUV422 buffer to ITU-R 656 supported format (OR) 
   to Pixel Compositor supported format */
void adi_swap_uv(
    u8                  *pDataBuffer,       /* Pointer to YUV422 buffer */
    u8                  YuvOutFlag,         /* TRUE to format above buffer for ITU-R 656 output, 
                                               FALSE to format above buffer for Pixel Compositor input */
    u32                 LinesPerFrame,      /* Lines per frame */
    u32                 DataPerLine         /* YUV422 data per line */
);

/*****/

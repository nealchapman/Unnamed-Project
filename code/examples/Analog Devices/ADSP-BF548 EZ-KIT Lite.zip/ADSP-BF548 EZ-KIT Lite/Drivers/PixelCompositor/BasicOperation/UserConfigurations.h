/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: UserConfigurations.h,v $
$Revision: 1.1 $
$Date: 2007/05/14 18:16:13 $

Description:
        Example to show how to operate Pixel Compositor and EPPI 
        in parallel, and how to use Pixel Compositor for color conversion 
        (YUV422 to RGB888 or RGB888 to YUV422) and to handle overlays.
        
        This file holds macros to 
        - Select Pixel compositor Input Image pattern
        - Select Pixel compositor operating mode
		- Select video output format
		
        Refer to associsated text file for project information
        
*****************************************************************************/

/*****************************************************************************

Input Image pattern selection macro(s)

*****************************************************************************/

/* Enable macro to set Eight color bars as PixC image input. 
   Disable to fill the frame with single color */
//#define EIGHT_COLOR_BAR_FILL

/*****************************************************************************

Pixel Compositor operating mode selection macros

*****************************************************************************/

/************ Macro(s) to set PixC input,overlay & output format ************/

/* enable macro to set PixC image input as RGB888, disable for YUV422 image input */
//#define     PIXC_INPUT_IMAGE_RGB888
/* enable macro to set PixC color converted output to RGB888, disable for YUV422 output */
#define     PIXC_OUTPUT_IMAGE_RGB888
/* enable macro to set PixC Overlay A/B as RGB888, disable to set Overlay A/B as YUV422 */
//#define     PIXC_OVERLAY_RGB888         /* This Macro is valid only when any one of the PixC overlay is enabled */

/************ Macro(s) to enable PixC overlay ************/
/* enable this macro to enable Pixel Compositor Overlay A */
#define     PIXC_OVERLAY_A_ENABLE
/* enable this macro to enable Pixel Compositor Overlay B */
#define     PIXC_OVERLAY_B_ENABLE

/*****************************************************************************

User configuration macros

*****************************************************************************/

/* enable Macro for RGB888 output. Disable for RGB666 output (macro valid only when PixC output is in RGB888 mode) */
#define		LCD_OUTPUT_RGB888
/* Enable this macro to enable PixC Color conversion workaround so that ITU-R 656 formated YUV422 (UYVY) <-> RGB888 conversion
   is done without any data handling to be done by the software */
#define		ENABLE_PIXC_ITUR656_SUPPORT
/* enable macro to set EPPI for ITU-R 656 PAL output, disable for NTSC output */
//#define     EPPI_OUT_PAL                /* This Macro is valid only when PixC output is set for YUV422 */

/*****/

Project Name: RotaryCounterExample.dpj

Description: Example program for Rotary counter driver
    
Project Type:
=============
    ADSP-BF533 [ ]
    ADSP-BF537 [ ]
    ADSP-BF548 [X]
    ADSP-BF561 [ ]

Hardware/Tools Used:
====================
    ADSP-BF548 EZ-Kit Lite Rev 1.1
    Analog Devices VisualDSP++ 5.0
    ADDS HPUSB-ICE
    
System Services Components Used:
================================
    DMA Manager                         [X]   Deferred Callback Manager   [X]
    Interrupt Manager                   [X]   Timer Module                [ ]
    Power Management Module             [X]   Flag Module                 [ ]
    External Bus Interface Unit Module  [X]   Port Module                 [X]

Overview:
=========

    The program configures Rotary controller in following mode
        - Sets Count UP and Direction (CDG) pin polarity to active low
        - Sets Count Down and Gate (CUD) pin polarity to active low
        - Enables Zero-marker press to clear the counter
        - Sets MAX Count Boundary value and enables interrupt when counter reaches MAX boundary
        - Sets MIN Count Boundary value and enables interrupt when counter reaches MIN boundary

    Any activity on the rotary wheel is reported to the user via a callback function using a
    specific event code and a callback argument (pointer to structure holding rotary counter value). 
    Depending on the event code, the callback function displays a message on VisualDSP console window.
    A clockwise rotation causes an up count event and the program reads the latest counter value
    An anti-clockwise rotation causes down count event and the program reads the latest counter value
    A rotary push event resets the counter to zero.

    The program can be terminated by pressing Pushbutton 4 (PB4) on the Ez-Kit
    
    This example targets ADSP-BF548 and tested on ADSP-BF548 Ez-Kit lite rev 1.1
    
Protocols used:
---------------
    None
    
ADI Drivers and Services used:
------------------------------
    services.h          - system services
    adi_dev.h           - Device manager
    adi_cnt.h           - Rotary Counter driver
            
Dataflow:
---------
    None
    
User Configuration Macros:
==========================
    None
    
Hardware Setup:
===============

	ADSP-BF548 Ez-Kit Lite Settings:
    --------------------------------
	All switches to default position
	Then, 
	SW4:  1(ON), 2(ON),  3(ON), 4(ON)

References:
===========
    ADSP-BF548 Hardware reference
    ADSP-BF548 EZ-Kit Lite Schematic
/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: RotaryCounterExample.c,v $
$Revision: 1.2 $
$Date: 2007/05/15 02:54:20 $

Description:
	This is an example program for Rotary counter driver

	Refer to associated text file for project information

******************************************************************************

Include files

*****************************************************************************/

#include <services/services.h>		/* system service includes          */
#include <drivers/adi_dev.h>		/* device manager includes          */
#include <drivers/rotary/adi_cnt.h>	/* rotary counter driver includes   */
#include "adi_ssl_init.h"		    /* system services init		        */	
#include <stdio.h>

/*****************************************************************************

User Configuration macros

*****************************************************************************/

#define     SET_MAX_COUNT_BOUNDARY      150
#define     SET_MIN_COUNT_BOUNDARY      -75

/*****************************************************************************

Processor specific Macros

*****************************************************************************/

/* Use Pushbutton 4 (PB4) to terminate this program */
#define     TERMINATE_BUTTON        	ADI_FLAG_PB11

/*****************************************************************************

Static data

*****************************************************************************/
/* handle to the driver*/
static ADI_DEV_DEVICE_HANDLE RotaryDriverHandle;
	
/* DCB Manager Data */
static u8 DCBMgrData[ADI_DCB_QUEUE_SIZE + (ADI_DCB_ENTRY_SIZE)*4];
/* handle to the callback service */
static ADI_DCB_HANDLE          DCBManagerHandle;

/*****************************************************************************

	Function:		ExceptionHandler
					HWErrorHandler

	Description:	We should never get an exception or hardware error,
					but just in case - display an error message 
					
*****************************************************************************/

static ADI_INT_HANDLER(ExceptionHandler)	        /* exception handler        */
{
	printf("Exception!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

static ADI_INT_HANDLER(HWErrorHandler)		        /* hardware error handler   */
{
	printf("HWerror!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

/*****************************************************************************

	Function:		ClientCallback

*****************************************************************************/
static void ClientCallback(
	void *AppHandle,
	u32  Event,
	void *pArg)
{

	ADI_CNT_CBSTATUS *pResult;	                /* pointer to Callback buffer   */
	pResult = (ADI_CNT_CBSTATUS *)pArg;         /* Pointer to rotary counter results */
	
	/* CASEOF (Event id) */
	switch (Event)
	{
		/* CASE (Max boundary count interrupt occurred) */
		case ADI_CNT_EVENT_MAXCOUNT_INT:
		    printf("Maximum boundary reached, Counter value = %d\n",pResult->CntCounter);
		    break;
		
		/* CASE (Min boundary count interrupt occurred) */
		case ADI_CNT_EVENT_MINCOUNT_INT:
		    printf("Minimum boundary reached, Counter value = %d\n",pResult->CntCounter);
		    break;
		    	
		/* CASE (Zero Marker interrupt occured) */
		case ADI_CNT_EVENT_CZM_COUNTZERO_INT:   /* counter zeroes by ZM int     */
		    printf("Zero Marker interrupt occurred\n");
		    break;
        		
        /* CASE (Count value - bit 31 overflow interrupt) */
		case ADI_CNT_EVENT_OVERFLOW31_INT:
		    printf("Counter value - bit 31 overflow interrupt occurred, Counter value = %d\n",pResult->CntCounter);
		    break;

        /* CASE (Count value - bit 15 overflow interrupt) */
		case ADI_CNT_EVENT_OVERFLOW15_INT:
		    printf("Counter value - bit 15 overflow interrupt occurred, Counter value = %d\n",pResult->CntCounter);
		    break;
		
		/* CASE (Count value crossed zero) */
		case ADI_CNT_EVENT_COUNT_TO_ZERO_INT:
            printf("Counter value has crossed zero, Counter value = %d\n",pResult->CntCounter);
		    break;
		
		/* CASE (Rotary counter  - Pushbutton interrupt occured) */
		case ADI_CNT_EVENT_CZMPIN_INT:
		    printf("Rotary Counter - Push button interrupt occurred, Counter value = %d\n",pResult->CntCounter);
		    break;

		/* CASE (Upcount interrupt occurred) */
		case ADI_CNT_EVENT_UPCOUNT_INT:
		    printf("Up count,\tCounter value = %d\n",pResult->CntCounter);
		    break;
		    
		/* CASE (Upcount interrupt occurred) */
		case ADI_CNT_EVENT_DOWNCOUNT_INT:
		    printf("Down count,\tCounter value = %d\n",pResult->CntCounter);
		    break;
		    
		/* CASE (Zero Marker error interrupt) */
		case ADI_CNT_EVENT_CZM_ERROR_INT:
		/* CASE (Illegal gray/binary count) */
		case ADI_CNT_EVENT_ILLEGAL_CODE_INT:
		    break;
	}     
}



/*****************************************************************************
*
*	Function:	main
*
*****************************************************************************/

void main(void)
{
	u32 Result;
	u32	ResponseCount;
	u32 Sense;

	printf ("Rotary Counter - Basic operation example for ADSP-BF548 Ez-Kit Lite \n");
	
    /* configure system - terminate configuration process on error */
    do
    {
        	
        /**************** Initialise System Services ****************/
    
        if ((Result = adi_ssl_Init()) != 0)
        {
    	    printf("Initialising System Services Failed! Error code: 0x%08X\n",Result);
    	    break;
        }

        /* hook the exception interrupt*/
	    if((Result = adi_int_CECHook(3, ExceptionHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook exception handler, Error Code: 0x%08X\n",Result);
		    break;
        }
        
        /* hook the hardware error*/
	    if((Result = adi_int_CECHook(5, HWErrorHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook hardware error handler, Error Code: 0x%08X\n",Result);
		    break;
        }

/* if DCB selected, open the DCB manager & setup a queue */
#if defined(USE_DEFERRED_CALLBACKS)
	    if((Result = adi_dcb_Open(14, &DCBMgrData[ADI_DCB_QUEUE_SIZE], 
	                              (ADI_DCB_ENTRY_SIZE)*4, &ResponseCount, &DCBManagerHandle))!=0)
	    {
		    printf("adi_dcb_Open failed, Error Code: 0x%08X\n",Result);
		    break;
	    }
#else	/* else, live callback */
        DCBManagerHandle = NULL;
#endif

        /* Initialise the Pushbutton that is to be used to terminate this program */
        /* Open the Flag pin connected to the Terminate pushbutton */
        if((Result = adi_flag_Open(TERMINATE_BUTTON)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to open Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /* Set this flag as Input */
        if((Result = adi_flag_SetDirection(TERMINATE_BUTTON,ADI_FLAG_DIRECTION_INPUT)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to configure Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }

        /************** Open Rotary counter driver ***************/
    
        if((Result = adi_dev_Open(  adi_dev_ManagerHandle,     		/* Dev manager Handle                       */
                     	            &ADICNTEntryPoint,              /* Device Entry point                       */
                                    0,                              /* Device number                            */
	                                NULL,                           /* No client handle                         */
    	                            &RotaryDriverHandle,	        /* DevMgr handle for this device    */
				                    ADI_DEV_DIRECTION_UNDEFINED,    /* data direction not used          */
            	                    NULL,         	                /* Handle to DMA Manager                    */
                	                DCBManagerHandle,               /* Handle to callback manager               */
                        	        ClientCallback))		        /* Callback Function                        */
	                	!= ADI_DEV_RESULT_SUCCESS) 
        {
         	printf("Open Rotary counter driver Failed!, Error Code: 0x%08X\n",Result);
         	break;
        }
	
	    /************************************************************************
	     Rotary Counter driver default configuration
	 
	 	    CUD and CDG input enabled 
	 	    Boundary compare mode 
	 	    Counter operating mode: QUAD_ENC 
	 	    Polarity for CDG, CUD and CZM : active high 
	 	    Debounce enabled (16*cycles) 
	 	    CNT_COUNTER is reset to 0 once when zero marker is detected 
	 	    Interrupt enabled for Push-button, Upcount and Downcount 
	    *************************************************************************/
    
        /************ Rotary counter Configuration table ************/
        ADI_DEV_CMD_VALUE_PAIR  RotaryConfig[]=
        {
            { ADI_CNT_CMD_SET_CDG_POL_ALOW,     (void *)TRUE                    },  /* set CDG polarity to active low                           */
            { ADI_CNT_CMD_SET_CUD_POL_ALOW,     (void *)TRUE                    },  /* set CUD polarity to active low                           */
            { ADI_CNT_CMD_CZM_COUNTZERO_INT_EN, (void *)TRUE                    },  /* enable Zero-marker-zeroes Counter mode                   */
            { ADI_CNT_CMD_SET_MAX_REG,          (void *)SET_MAX_COUNT_BOUNDARY  },  /* set MAX Count Boundary value                             */
            { ADI_CNT_CMD_SET_MIN_REG,          (void *)SET_MIN_COUNT_BOUNDARY  },  /* set MIN Count Boundary value                             */
            { ADI_CNT_CMD_MAXCOUNT_INT_EN,      (void *)TRUE                    },  /* Enable interrupt when Counter reachs Max boundary value  */
            { ADI_CNT_CMD_MINCOUNT_INT_EN,      (void *)TRUE                    },  /* Enable interrupt when Counter reachs Min boundary value  */
            { ADI_DEV_CMD_END,					NULL                            }   /* Terminate config table                                   */
	    };

        /**************** Configure Rotary counter device ****************/
        if((Result = adi_dev_Control(RotaryDriverHandle, ADI_DEV_CMD_TABLE, (void *)RotaryConfig))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to configure Rotary counter device: 0x%08X\n",Result);
		    break;
        }

        /**************** Enable the Rotary counter device ****************/
        if((Result = adi_dev_Control(RotaryDriverHandle, ADI_CNT_CMD_SET_CNT_ENABLE, (void *)TRUE))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to enable Rotary counter device: 0x%08X\n",Result);
		    break;
        }
        
    } while(0);
	
	/* IF (Rotary counter configuration results in success) */
  	if (Result == ADI_DEV_RESULT_SUCCESS)
    {
        printf("Rotary counter is up and running...\n");
        printf("Press Pushbutton 4 (PB4) to terminate this program\n");
        /* wait for counter activity until user presses terminate button */
        while ((Result = adi_flag_Sense(TERMINATE_BUTTON, &Sense)) == ADI_DEV_RESULT_SUCCESS)
        {
            /* IF (Terminate button pressed) */
            if(Sense)
            {
                break;
            }
        }
  
        /* Disable the Rotary counter device */
        if((Result = adi_dev_Control(RotaryDriverHandle, ADI_CNT_CMD_SET_CNT_ENABLE, (void *)FALSE))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to disable Rotary counter device: 0x%08X\n",Result);
        }
        
    	/* close Rotary counter driver */
    	if((Result = adi_dev_Close(RotaryDriverHandle)) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to close Rotary counter driver, Error Code: 0x%08X\n",Result);
    	}

    	/* Terminate system services */
    	if((Result = adi_ssl_Terminate()) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to terminate system services, Error Code: 0x%08X\n",Result);
    	}    
	}
	else
	{
		printf("Program terminated abnormally with error code: 0x%08X\n",Result);
	}
	printf ("Done!\n");
}

/*****/

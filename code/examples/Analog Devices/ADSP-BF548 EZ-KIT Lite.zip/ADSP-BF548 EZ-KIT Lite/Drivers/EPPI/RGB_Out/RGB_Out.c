/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: RGB_Out.c,v $
$Revision: 1.3 $
$Date: 2007/05/30 16:56:26 $

Description:
	This is an example program for EPPI RGB888/RGB666 transmit modes
	and SHARP LQ043T1DG01 LCD driver

	Refer to associated text file for project information

******************************************************************************

Include files

*****************************************************************************/

#include <services/services.h>				    /* system service includes              */
#include <drivers/adi_dev.h>				    /* device manager includes              */
#include <drivers/lcd/sharp/adi_lq043t1dg01.h>  /* SHARP LQ043T1DG01 LCD driver include */
#include <drivers/eppi/adi_eppi.h>			    /* EPPI driver include                  */
#include "adi_ssl_init.h"                       /* System services init includes        */
#include <stdio.h>

/*****************************************************************************

Display pattern selection macros

*****************************************************************************/

/* Enable only one among the following Display pattern generation macros */

/* Macro to enable single color fill pattern */
//#define     SINGLE_COLOR_FILL
/* Macro to enable Quad color fill pattern */
//#define     QUAD_COLOR_FILL
/* Macro to enable Eight color bar fill pattern */
#define     EIGHT_COLOR_BAR_FILL
/* Macro to enable Full color bar fill pattern */
//#define     FULL_COLOR_BAR_FILL

/*****************************************************************************

User configuration macros

*****************************************************************************/

/* Macro to enable deferred callbacks */
#define     USE_DEFERRED_CALLBACKS
/* Macro to enable chained with loopback */
#define     USE_LOOPBACK
/* Macro to enable LCD boundary display */
//#define     ENABLE_LCD_BOUNDARY
/* Macro to select LCD output format. Disable this macro to select RGB666 output */
#define     LCD_OUTPUT_RGB888

/*****************************************************************************

Processor specific Macros

*****************************************************************************/

/* Processor DMA bus size = 4 bytes */
#define	    DMA_BUS_SIZE			4
/* EPPI Device Number to use - BF548 has 3 EPPI ports */
/*SHARP LQ043T1DG01 LCD is connected to EPPI 0*/
#define     EPPI_DEV_NUMBER         0
/* Use Pushbutton 4 (PB4) to terminate this program */
#define     TERMINATE_BUTTON        ADI_FLAG_PB11

/*****************************************************************************

LCD specific Macros

*****************************************************************************/

#define     LCD_NUM_FRAMES 		    60  	/* update display pattern every # frames    */
#define	    LCD_PIXELS_PER_LINE	    480		/* Pixels per line                          */
#define	    LCD_LINES_PER_FRAME	    272		/* Lines per frame                          */
#define	    LCD_DATA_PER_PIXEL     	3		/* 3bytes per pixel (MSB = B, G, LSB = R    */

/* Processor Timer ID used to generate LCD DISP signal  */
#define     LCD_DISP_TIMER_ID       ADI_TMR_GP_TIMER_3
/* Processor Flag ID connected to LCD DISP signal       */
#define     LCD_DISP_FLAG_ID        ADI_FLAG_PE3

/*****************************************************************************

RGB888 Color defines

*****************************************************************************/
/* list of colors in RGB888 format */
#define	    RGB888_BLACK  		        0x000000
#define	    RGB888_RED 	    	        0xFF0000
#define     RGB888_GREEN 		        0x00FF00
#define     RGB888_BLUE     	        0x0000FF
#define     RGB888_YELLOW 		        0xFFFF00
#define     RGB888_CYAN 		        0x00FFFF
#define     RGB888_MAGENTA  	        0xFF00FF
#define     RGB888_WHITE 		        0xFFFFFF

/* Define LCD Boundary color */
#define     LCD_BOUNDARY_COLOR			RGB888_WHITE

/*****************************************************************************

Static data

*****************************************************************************/
/* Create two RGB888 frames in DDR which will be sent out to the LCD */
section("sdram0_bank1") static u8 PingFrame[LCD_PIXELS_PER_LINE * LCD_DATA_PER_PIXEL * LCD_LINES_PER_FRAME];
section("sdram0_bank2") static u8 PongFrame[LCD_PIXELS_PER_LINE * LCD_DATA_PER_PIXEL * LCD_LINES_PER_FRAME];

/* handle to the LCD driver */
static ADI_DEV_DEVICE_HANDLE    VideoOutDriverHandle;
/* DCB Managed Data */
static u8 DCBMgrData[ADI_DCB_QUEUE_SIZE + (ADI_DCB_ENTRY_SIZE)*4];
/* handle to the callback service */
static ADI_DCB_HANDLE          DCBManagerHandle;

/* Create two buffer chains */
ADI_DEV_2D_BUFFER PingBuffer[LCD_NUM_FRAMES];
ADI_DEV_2D_BUFFER PongBuffer[LCD_NUM_FRAMES];

/* array to hold eight RGB888 color values to be displayed */
u32	DisplayColors[8] =  {   RGB888_BLACK, 
                            RGB888_RED, 
                            RGB888_GREEN, 
                            RGB888_BLUE, 
                            RGB888_YELLOW, 
                            RGB888_CYAN, 
                            RGB888_MAGENTA, 
                            RGB888_WHITE 
                        };

/*********************************************************************

Function prototypes

*********************************************************************/
static ADI_INT_HANDLER(ExceptionHandler);	/* exception handler */
static ADI_INT_HANDLER(HWErrorHandler);		/* hardware error handler */
static void LcdCallback(
    void 	*AppHandle, 
    u32  	Event,
    void 	*pArg
);

/* LCD display pattern generator */
void LcdDisplayPattern(
    u8  *pDataBuffer    /* Pointer to RGB888 frame */
);

/*****************************************************************************

	Function:		ExceptionHandler
					HWErrorHandler

	Description:	We should never get an exception or hardware error,
					but just in case - display an error message 
					
*****************************************************************************/

static ADI_INT_HANDLER(ExceptionHandler)	        /* exception handler        */
{
	printf("Exception!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

static ADI_INT_HANDLER(HWErrorHandler)		        /* hardware error handler   */
{
	printf("HWerror!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

/*********************************************************************
*
*   Function:   main
*
*********************************************************************/
void main (void) 
{    
    u32     ResponseCount;
    u32     i;		
    u32     Result;
	u32     Sense;
	
    ADI_LQ043T1DG01_TIMER_FLAG  Disp;   /* to hold LCD disp flag details */

#if defined (LCD_OUTPUT_RGB888)
	printf("RGB888 (24-bit) output. Set Ez-Kit SW17 to 1(ON), 2(OFF), 3(ON), 4(OFF) \n");
#else
	printf("RGB666 (18-bit) output. Set Ez-Kit SW17 to 1(ON), 2(ON), 3(OFF), 4(OFF) \n");
#endif
	
	/* configure system - terminate configuration process on error */
    do
    {
        /**************** Initialise System Services ****************/
    
         if ((Result = adi_ssl_Init()) != 0)
        {
    	    printf("Initialising System Services Failed! Error code: 0x%8X\n",Result);
    	    break;
        }

        /* hook the exception interrupt*/
	    if((Result = adi_int_CECHook(3, ExceptionHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook exception handler, Error Code: 0x%08X\n",Result);
		    break;
        }
        
        /* hook the hardware error*/
	    if((Result = adi_int_CECHook(5, HWErrorHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook hardware error handler, Error Code: 0x%08X\n",Result);
		    break;
        }
        
/* if DCB selected, open the DCB manager & setup a queue */
#if defined(USE_DEFERRED_CALLBACKS)
	    if((Result = adi_dcb_Open(14, &DCBMgrData[ADI_DCB_QUEUE_SIZE], 
	                              (ADI_DCB_ENTRY_SIZE)*4, &ResponseCount, &DCBManagerHandle))!=0)
	    {
		    printf("adi_dcb_Open failed, Error Code: 0x%08X\n",Result);
		    break;
	    }
#else	/* else, live callback */
        DCBManagerHandle = NULL;
#endif
       
        /* Initialise the Pushbutton that is to be used to terminate this program */
        /* Open the Flag pin connected to the Terminate pushbutton */
        if((Result = adi_flag_Open(TERMINATE_BUTTON)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to open Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /* Set this flag as Input */
        if((Result = adi_flag_SetDirection(TERMINATE_BUTTON,ADI_FLAG_DIRECTION_INPUT)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to configure Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /************** Open Sharp LQ043T1DG01 LCD device ***************/
    
        /* open the LCD driver for video out */
        if((Result = adi_dev_Open(  adi_dev_ManagerHandle,     		/* Dev manager Handle                   */
                     	            &ADILQ043T1DG01EntryPoint,      /* Device Entry point                   */
                                    0,                              /* Device number                        */
	                                NULL,                           /* No client handle                     */
    	                            &VideoOutDriverHandle,          /* Location to store LCD driver handle  */
        	                        ADI_DEV_DIRECTION_OUTBOUND,     /* Data Direction                       */
            	                    adi_dma_ManagerHandle,         	/* Handle to DMA Manager                */
                	                DCBManagerHandle,               /* Handle to callback manager           */
                    	            LcdCallback))			        /* Callback Function                    */
		            != ADI_DEV_RESULT_SUCCESS) 
        {
     	    printf("Failed to open video output device , Error Code: 0x%08X\n",Result);
     	    break;
        }

        /**************** Sharp LQ043T1DG01 LCD driver Configuration ****************/
    
        Disp.DispTimerId = LCD_DISP_TIMER_ID;   /* Timer ID to be used to generate DISP signal requirements */
        Disp.DispFlagId  = LCD_DISP_FLAG_ID;    /* Flag port to with LCD DISP pin is connected to           */
    
	    /* Set DISP Timer & Flag ID */
	    if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_LQ043T1DG01_CMD_SET_DISP_TIMER_FLAG, (void*)&Disp ))!= ADI_DEV_RESULT_SUCCESS)
	    {
		    printf("Failed to set DISP Timer & Flag ID, Error Code: 0x%08X\n",Result);
		    break;
        }
    
	    /* Set EPPI Device number to be used for LCD video out */
	    if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_LQ043T1DG01_CMD_SET_EPPI_DEV_NUMBER, (void*)EPPI_DEV_NUMBER ))!= ADI_DEV_RESULT_SUCCESS)
	    {
		    printf("Failed to set EPPI device number, Error Code: 0x%08X\n",Result);
		    break;
        }
    
        /* Open EPPI Device for LCD out */
	    if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_LQ043T1DG01_CMD_SET_OPEN_EPPI_DEVICE, (void*)TRUE ))!= ADI_DEV_RESULT_SUCCESS)
	    {
		    printf("Failed to open EPPI device for LCD out, Error Code: 0x%08X\n",Result);
		    break;
        }
	
	    /**************** EPPI Configuration ****************/

	    /* EPPI Control register configuration value for RGB out
    	    - EPPI as Output
        	  GP 2 frame sync mode, 
        	  Internal Clock generation disabled, Internal FS generation enabled,
      	      Receives samples on EPPI_CLK raising edge, Transmits samples on EPPI_CLK falling edge,
          	  FS1 & FS2 are active high, 
          	  DLEN = 6 (24 bits for RGB888 out) or 5 (18 bits for RGB666 out)
      	      DMA Unpacking disabled when RGB Formating is enabled, otherwise DMA unpacking enabled
          	  Swapping Disabled, 
          	  One (DMA) Channel Mode,
      	      RGB Formatting Enabled for RGB666 output, disabled for RGB888 output
          	  Regular watermark - when FIFO is 75% full, 
          	  Urgent watermark - when FIFO is 25% full 
	    */

	    /* EPPI Configuration table for Sharp LQ043T1DG01 LCD */
	    ADI_DEV_CMD_VALUE_PAIR EppiLcdConfig[]=
	    {
/* IF (RGB888 output selected) */
#if defined (LCD_OUTPUT_RGB888)	/* set EPPI for RGB888 (24-bit) output */
    		{ ADI_EPPI_CMD_SET_DATA_LENGTH,             (void *)6       },  /* 24 bit out                       */
	    	{ ADI_EPPI_CMD_ENABLE_RGB_FORMATTING,       (void *)FALSE   },  /* Disable RGB formatting           */
#else	/* set EPPI for RGB666 (18-bit) output */
		    { ADI_EPPI_CMD_SET_DATA_LENGTH,             (void *)5       },  /* 18 bit out                       */
    		{ ADI_EPPI_CMD_ENABLE_RGB_FORMATTING,       (void *)TRUE   	},  /* Enable RGB formatting            */
#endif
    	    { ADI_EPPI_CMD_SET_PORT_DIRECTION,          (void *)1       },  /* EPPI in Output mode              */
    	    { ADI_EPPI_CMD_SET_TRANSFER_TYPE,           (void *)3       },  /* GP Transfer mode                 */
        	{ ADI_EPPI_CMD_SET_FRAME_SYNC_CONFIG,       (void *)2       },  /* GP2 mode                         */
        	{ ADI_EPPI_CMD_ENABLE_INTERNAL_CLOCK_GEN,   (void *)TRUE    },  /* Internally generated Clock       */
	        { ADI_EPPI_CMD_ENABLE_INTERNAL_FS_GEN,      (void *)TRUE    },  /* Internally generated Frame sync  */
    	    { ADI_EPPI_CMD_SET_CLOCK_POLARITY,          (void *)1       },  /* Tx raising edge, Rx falling edge */
        	{ ADI_EPPI_CMD_SET_FRAME_SYNC_POLARITY,     (void *)3       },  /* FS1 & FS2 active low	            */
        	{ ADI_EPPI_CMD_SET_SKIP_ENABLE,             (void *)FALSE   },  /* Disable skipping 	            */
	        { ADI_EPPI_CMD_SET_PACK_UNPACK_ENABLE,      (void *)TRUE    },  /* DMA unpacking enabled            */
        	{ ADI_EPPI_CMD_SET_SWAP_ENABLE,             (void *)FALSE   },  /* Swapping disabled 	            */
        	{ ADI_EPPI_CMD_SET_SPLIT_EVEN_ODD,          (void *)FALSE   },  /* Splitting disabled 	            */
    	    { ADI_EPPI_CMD_SET_FIFO_REGULAR_WATERMARK,  (void *)1      	},  /* Regular watermark  	            */
    	    { ADI_EPPI_CMD_SET_FIFO_URGENT_WATERMARK,   (void *)3       },  /* Urgent watermark 	            */
	        { ADI_DEV_CMD_END,                          NULL            }   /* End of command table             */
    	}; 
    
       /* Configure EPPI Control register - can use LCD driver handle, as LCD driver passes unrecognised commands to EPPI */
	    if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_DEV_CMD_TABLE, (void*)EppiLcdConfig ))!= ADI_DEV_RESULT_SUCCESS)
	    {
		    printf("Failed to configure EPPI control register for LCD out, Error Code: 0x%08X\n",Result);
		    break;
        }
    
	    /****************** Prepare Video Frames *******************/
	
	    /* Fill the RGB888 frames with specified color */
	    LcdDisplayPattern(PingFrame);
	    LcdDisplayPattern(PongFrame);

	    /******************Buffer preparation **********************/

	    /*
    	   create a buffer chain that points to the PingFrame.  Each buffer points to the same PingFrame
	       so the PingFrame will be displayed NUM_FRAMES times.  NUM_FRAMES is sized to 
    	   keep the display busy for 1 second.  Place a callback on only the last buffer
	       in the chain.  Make the CallbackParameter (the value that gets passed to the callback
    	   function as the pArg parameter) point to the first buffer in the chain.  This way, when
	       the callback goes off, the callback function can requeue the whole chain if the loopback
    	   mode is off.
	    */

        /* FOR (Number of output 2D buffers) */
        for (i = 0; i < LCD_NUM_FRAMES; i++) 
        {
            PingBuffer[i].Data              = PingFrame;
            PingBuffer[i].ElementWidth      = DMA_BUS_SIZE;
            PingBuffer[i].XCount            = ((LCD_PIXELS_PER_LINE * LCD_DATA_PER_PIXEL)/DMA_BUS_SIZE);
            PingBuffer[i].XModify           = DMA_BUS_SIZE;
            PingBuffer[i].YCount            = LCD_LINES_PER_FRAME;
            PingBuffer[i].YModify           = DMA_BUS_SIZE;
            PingBuffer[i].CallbackParameter = NULL;
            PingBuffer[i].pNext             = &PingBuffer[i + 1];   /* chain to next buffer in the list */
        }

        /* DMA generates Callback when last buffer in the chain is processed
           address of first buffer in the chain is passed as callback parameter */
        PingBuffer[LCD_NUM_FRAMES - 1].CallbackParameter = &PingBuffer[0];
        /* Terminate this buffer chain */
        PingBuffer[LCD_NUM_FRAMES - 1].pNext = NULL;
  
        /* now do the same for the Pong buffers */
        /* FOR (Number of output 2D buffers) */
        for (i = 0; i < LCD_NUM_FRAMES; i++) 
        {
            PongBuffer[i].Data              = PongFrame;
            PongBuffer[i].ElementWidth      = DMA_BUS_SIZE;
            PongBuffer[i].XCount            = ((LCD_PIXELS_PER_LINE*LCD_DATA_PER_PIXEL)/DMA_BUS_SIZE);
            PongBuffer[i].XModify           = DMA_BUS_SIZE;
            PongBuffer[i].YCount            = LCD_LINES_PER_FRAME;
            PongBuffer[i].YModify           = DMA_BUS_SIZE;
            PongBuffer[i].CallbackParameter = NULL;
            PongBuffer[i].pNext             = &PongBuffer[i + 1];   /* chain to next buffer in the list */
        }
    
        /* DMA generates Callback when last buffer in the chain is processed
           address of first buffer in the chain is passed as callback parameter */
        PongBuffer[LCD_NUM_FRAMES - 1].CallbackParameter = &PongBuffer[0];  
        /* Terminate this buffer chain */
        PongBuffer[LCD_NUM_FRAMES - 1].pNext = NULL;
    
/* Set Dataflow method */
#if defined(USE_LOOPBACK)
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW_METHOD, (void *)ADI_DEV_MODE_CHAINED_LOOPBACK ))!= ADI_DEV_RESULT_SUCCESS)
#else
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW_METHOD, (void *)ADI_DEV_MODE_CHAINED ))!= ADI_DEV_RESULT_SUCCESS)
#endif    
        {
            printf("Failed to set dataflow method, Error Code: 0x%08X\n",Result);
            break;
        }

        /* give the ping-pong buffers to the device */
        if((Result = adi_dev_Write(VideoOutDriverHandle, ADI_DEV_2D, (ADI_DEV_BUFFER *)PingBuffer))!= ADI_DEV_RESULT_SUCCESS)
        {
    	    printf("Failed to submit PingBuffer, Error Code: 0x%08X\n",Result);
    	    break;
        }
   
        if((Result = adi_dev_Write(VideoOutDriverHandle, ADI_DEV_2D, (ADI_DEV_BUFFER *)PongBuffer))!= ADI_DEV_RESULT_SUCCESS)
        {
    	    printf("Failed to submit PongBuffer, Error Code: 0x%08X\n",Result);
    	    break;
        }

        /* Enable LCD video data flow */
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW, (void *)TRUE))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to enable dataflow, Error Code: 0x%08X\n",Result);
        }
    
    }while(0);
    
    /* IF (video out configuration results in success) */
  	if (Result == ADI_DEV_RESULT_SUCCESS)
    {
    	printf("EPPI is up and running...\n");
    	printf("Press Pushbutton 4 (PB4) to terminate this program\n");
        /* continue displaying frames to LCD until user presses terminate button */
        while ((Result = adi_flag_Sense(TERMINATE_BUTTON, &Sense)) == ADI_DEV_RESULT_SUCCESS)
        {
            /* IF (Terminate button pressed) */
            if(Sense)
            {
                break;
            }
        }

        /* Disable LCD video data flow */
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW, (void *)FALSE))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to disable dataflow, Error Code: 0x%08X\n",Result);
        }
   
    	/* close the video out driver */
    	if((Result = adi_dev_Close(VideoOutDriverHandle)) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to close video output driver, Error Code: 0x%08X\n",Result);
    	}

    	/* Terminate system services */
    	if((Result = adi_ssl_Terminate()) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to terminate system services, Error Code: 0x%08X\n",Result);
    	}    
	}
	else
	{
		printf("Program terminated abnormally with error code: 0x%08X\n",Result);
	}
	printf ("Done!\n");
}

/*****************************************************************************

    Function:       LcdCallback

    Description:    Each type of callback event has it's own unique ID 
                    so we can use a single callback function for all 
                    callback events.  The switch statement tells us 
                    which event has occurred.
                    
*****************************************************************************/
/* place this part of code in L1 */
section ("L1_code")
static void LcdCallback(
    void 	*AppHandle,
    u32  	Event,
    void 	*pArg
){
    
    ADI_DEV_2D_BUFFER *pBuffer;		/* pointer to the buffer that was processed */
	u32 Result;
	
    /* CASEOF (event type) */
    switch (Event) 
    {    
        /* CASE (buffer processed) */
        case ADI_DEV_EVENT_BUFFER_PROCESSED:

            /* when the buffer chain was created, the CallbackParameter value for the buffer
               that was generating the callback was set to be the address of the first buffer
               in the chain.  So here in the callback that value is passed in as the pArg
               parameter. */
            pBuffer = (ADI_DEV_2D_BUFFER *)pArg;

            /* Update LCD Display pattern */
            LcdDisplayPattern(pBuffer->Data);

#if defined(USE_LOOPBACK)
			/* if loopback is enabled, the driver will continually reuse the buffers. */
#else
			/* if loopback is disabled though, we need to requeue the buffer chain that just finished */
            adi_dev_Write(VideoOutDriverHandle, ADI_DEV_2D, pArg);

#endif
			
            break;

        /* CASE (EPPI Status Error) */
        case ADI_EPPI_EVENT_LUMA_FIFO_ERROR:         
        case ADI_EPPI_EVENT_LINE_TRACK_OVERFLOW_ERROR:         
        case ADI_EPPI_EVENT_LINE_TRACK_UNDERFLOW_ERROR:         
        case ADI_EPPI_EVENT_FRAME_TRACK_OVERFLOW_ERROR:
        case ADI_EPPI_EVENT_FRAME_TRACK_UNDERFLOW_ERROR:
        case ADI_EPPI_EVENT_PREAMBLE_ERROR_NOT_CORRECTED:
        case ADI_EPPI_EVENT_PREAMBLE_ERROR:
			printf("EPPI status error. Event code: 0x%08X\n",Event);		
			break;
			
        /* CASE (DMA Error) */
        case ADI_DEV_EVENT_DMA_ERROR_INTERRUPT:
            printf("DMA error\n");
            break;
            
		default:
			printf("Callback event not supported. Event code: 0x%08X\n",Event);
			break;
    }
    
    /* return */
}

/******************************************************************************
    Function:       LcdDisplayPattern

    Description:    Fills RGB888 frame with the selected display pattern
    
******************************************************************************/
void LcdDisplayPattern(
    u8  *pDataBuffer        /* Pointer to RGB888 frame      */
){
    u32     Line,Pixel,ColorId;
    u8      r,g,b;
    u8		*pTemp;
    u32     ColorCycle,i;
    
    /* store the pointer to RGB888 frame for LCD boundary update */
    pTemp = pDataBuffer;
    
/* Display pattern - Single color fill */
#if defined (SINGLE_COLOR_FILL)
	/* FOR (each line) */ 
	for(Line = 1; Line <= LCD_LINES_PER_FRAME; Line++)
	{
		/* FOR (each pixel) */ 
		for (Pixel = 1; Pixel <= LCD_PIXELS_PER_LINE; Pixel++ )
		{
	        *pDataBuffer++ = (u8) (DisplayColors [0] >> 16);
	        *pDataBuffer++ = (u8) (DisplayColors [0] >> 8);
	        *pDataBuffer++ = (u8) (DisplayColors [0]);
		}
	}
  
/* Display pattern - Quad color fill */
#elif defined (QUAD_COLOR_FILL)
	/* FOR (each line) */ 
	for(Line = 1; Line <= LCD_LINES_PER_FRAME; Line++)
	{
		/* FOR (each pixel) */ 
		for (Pixel = 1; Pixel <= LCD_PIXELS_PER_LINE; Pixel++ )
		{
            /* IF (this pixel falls under Color block Quad 1) */
            if ((Line <= (LCD_LINES_PER_FRAME/2)) && (Pixel <= (LCD_PIXELS_PER_LINE/2)))
            {
	            *pDataBuffer++ = (u8) (DisplayColors [0] >> 16);
	            *pDataBuffer++ = (u8) (DisplayColors [0] >> 8);
	            *pDataBuffer++ = (u8) (DisplayColors [0]);
            }
            /* ELSE (this pixel falls under Color block Quad 2) */
            else if ((Line <= (LCD_LINES_PER_FRAME/2)) && (Pixel >= (LCD_PIXELS_PER_LINE/2)))
            {
	            *pDataBuffer++ = (u8) (DisplayColors [1] >> 16);
	            *pDataBuffer++ = (u8) (DisplayColors [1] >> 8);
	            *pDataBuffer++ = (u8) (DisplayColors [1]);
            }
            /* ELSE (this pixel falls under Color block Quad 3) */
            else if ((Line >= (LCD_LINES_PER_FRAME/2)) && (Pixel <= (LCD_PIXELS_PER_LINE/2)))
            {
	            *pDataBuffer++ = (u8) (DisplayColors [2] >> 16);
	            *pDataBuffer++ = (u8) (DisplayColors [2] >> 8);
	            *pDataBuffer++ = (u8) (DisplayColors [2]);
            }
            /* ELSE (this pixel falls under Color block Quad 4) */
            else if ((Line >= (LCD_LINES_PER_FRAME/2)) && (Pixel >= (LCD_PIXELS_PER_LINE/2)))
            {
	            *pDataBuffer++ = (u8) (DisplayColors [3] >> 16);
	            *pDataBuffer++ = (u8) (DisplayColors [3] >> 8);
	            *pDataBuffer++ = (u8) (DisplayColors [3]);
            }
		}
	}
/* Display pattern - Eight color bar fill */
#elif defined (EIGHT_COLOR_BAR_FILL)

	/* FOR (each line) */ 
	for(Line = 1; Line <= LCD_LINES_PER_FRAME; Line++)
	{	
	    /* fill this line with 8 color bars */
	    for (ColorId = 0; ColorId<=7; ColorId++)
	    {
        	/* Spilt this line as 8 blocks & fill them with different color */ 
			for (Pixel = 1; Pixel <= (LCD_PIXELS_PER_LINE/8); Pixel++ )
			{
            	*pDataBuffer++ = (u8) (DisplayColors [ColorId] >> 16);
            	*pDataBuffer++ = (u8) (DisplayColors [ColorId] >> 8);
            	*pDataBuffer++ = (u8) (DisplayColors [ColorId]);
			}
	    }
    }
    
/* Display pattern - Full color bar fill */
#elif defined(FULL_COLOR_BAR_FILL)
    /* FOR (first half of the display) */
	for(Line = 1; Line <= (LCD_LINES_PER_FRAME/2); Line++)
	{			
		r = 0xff;
		g = 0x00;
		b = 0x00;	
		for( Pixel = 1; Pixel <= (LCD_PIXELS_PER_LINE / 6); Pixel++ )
		{
			*pDataBuffer++ = r;
			*pDataBuffer++ = g;
			*pDataBuffer++ = b;	
			
			g = g + 3;		
		}
		
		r = 0xff;
		g = 0xff;
		b = 0x00;
		for( Pixel = 1; Pixel <= (LCD_PIXELS_PER_LINE / 6); Pixel++ )
		{
			*pDataBuffer++ = r;
			*pDataBuffer++ = g;
			*pDataBuffer++ = b;	
			
			r = r - 3;		
		}
		
		r = 0x00;
		g = 0xff;
		b = 0x00;
		for( Pixel = 1; Pixel <= (LCD_PIXELS_PER_LINE / 6); Pixel++ )
		{
			*pDataBuffer++ = r;
			*pDataBuffer++ = g;
			*pDataBuffer++ = b;	
			
			b = b + 3;		
		}
		
		r = 0x00;
		g = 0xff;
		b = 0xff;
		for( Pixel = 1; Pixel <= (LCD_PIXELS_PER_LINE / 6); Pixel++ )
		{
			*pDataBuffer++ = r;
			*pDataBuffer++ = g;
			*pDataBuffer++ = b;	
			
			g = g - 3;		
		}

		r = 0x00;
		g = 0x00;
		b = 0xff;
		for( Pixel = 1; Pixel <= (LCD_PIXELS_PER_LINE / 6); Pixel++ )
		{
			*pDataBuffer++ = r;
			*pDataBuffer++ = g;
			*pDataBuffer++ = b;	
			
			r = r + 3;		
		}

		r = 0xff;
		g = 0x00;
		b = 0xff;		
		for( Pixel = 1; Pixel <= (LCD_PIXELS_PER_LINE / 6); Pixel++ )
		{
			*pDataBuffer++ = r;
			*pDataBuffer++ = g;
			*pDataBuffer++ = b;	
			
			b = b - 3;		
		}
	}
	
	/* FOR (second half of the display) */
	for(Line = 1; Line <= (LCD_LINES_PER_FRAME/2); Line++)
	{	
		r = 0xff;
		g = 0xff;
		b = 0xff;	
		for( Pixel = 1; Pixel <= LCD_PIXELS_PER_LINE ; Pixel+=2 )
		{
			*pDataBuffer++ = r;
			*pDataBuffer++ = g;
			*pDataBuffer++ = b;	
			*pDataBuffer++ = r;
			*pDataBuffer++ = g;
			*pDataBuffer++ = b;
			
			r = r - 1;		
			g = g - 1;		
			b = b - 1;		
		}
	}	

#endif

/* IF (Enable LCD boundary) */
#if defined (ENABLE_LCD_BOUNDARY)
	/* FOR (each line) */ 
	for(Line = 1; Line <= LCD_LINES_PER_FRAME; Line++)
	{
		/* FOR (each pixel) */ 
		for (Pixel = 1; Pixel <= LCD_PIXELS_PER_LINE; Pixel++ )
		{
		    /* IF (this pixel falls under LCD boundary (B)) */
		    if ((Pixel == 1) || (Pixel == LCD_PIXELS_PER_LINE) || (Pixel == (LCD_PIXELS_PER_LINE/2)) ||
		    	(Line == 1)  || (Line == LCD_LINES_PER_FRAME)  || (Line == (LCD_LINES_PER_FRAME/2)))
		    {
	            *pTemp++ = (u8)(LCD_BOUNDARY_COLOR >> 16);
	            *pTemp++ = (u8)(LCD_BOUNDARY_COLOR >> 8);
	            *pTemp++ = (u8)(LCD_BOUNDARY_COLOR);
            }
            else
            {
                *pTemp++;
                *pTemp++;
                *pTemp++;
            }
        }
    }
#endif

    /* Cycle Display colors array */
	ColorCycle = DisplayColors[0];
	for (i=0;i < (sizeof(DisplayColors)/sizeof(u32));i++)
	{
	    DisplayColors[i] = DisplayColors[i+1];
	}
	DisplayColors[(sizeof(DisplayColors)/sizeof(u32))-1] = ColorCycle;

}

/*****/

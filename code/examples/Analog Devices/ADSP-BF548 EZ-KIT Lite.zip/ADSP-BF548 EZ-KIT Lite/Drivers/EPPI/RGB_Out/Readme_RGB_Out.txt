Project Name: RGB_Out.dpj

Description: Example program for EPPI RGB888/RGB666 transmit modes
			 and SHARP LQ043T1DG01 LCD driver
    
Project Type:
=============
    ADSP-BF533 [ ]
    ADSP-BF537 [ ]
    ADSP-BF548 [X]
    ADSP-BF561 [ ]

Hardware/Tools Used:
====================
    ADSP-BF548 EZ-Kit Lite Rev 1.1
    Analog Devices VisualDSP++ 5.0
    ADDS HPUSB-ICE

System Services Components Used:
================================
    DMA Manager                         [X]   Deferred Callback Manager   [X]
    Interrupt Manager                   [X]   Timer Module                [X]
    Power Management Module             [X]   Flag Module                 [X]
    External Bus Interface Unit Module  [X]   Port Module                 [X]

Overview:
=========

    This is an example program for EPPI RGB888/RGB666 transmit modes and
    SHARP LQ043T1DG01 LCD driver

    The program outputs a seleted display pattern to the LCD.
    Two RGB888 buffers are used to create the selected display pattern. 
    Created display patterns are sent to SHARP LQ043T1DG01 LCD port via EPPI0.

    EPPI 0 is configured in GP2 Output mode.
    
    The program can be terminated by pressing Pushbutton 4 (PB4) on the Ez-Kit
        
    This example targets ADSP-BF548 and tested on ADSP-BF548 Ez-Kit lite rev 1.1

LCD Display pattern:
--------------------
    
    LCD physical boundary defined by #
    LCD display boundary (B) defined by combination of + - and |
    LCD Boundary can be disabled/enabled using a macro - ENABLE_LCD_BOUNDARY
    Sections marked as 'T' will be filled with selected display pattern
    
    #########################################
    #                                       #
    #   +-------B-------+------B-------+    #
    #   |               |              |    #
    #   B       T       B      T       B    #
    #   |               |              |    #
    #   +-------B-------+------B-------+    #
    #   |               |              |    #
    #   B       T       B      T       B    #
    #   |               |              |    #
    #   +-------B-------+------B-------+    #
    #                                       #
    #########################################
    
Display patterns (selected by macros):
--------------------------------------
    1. Single color fill (full frame filled with a single color)
    2. Quad color fill (each 'T' block filled with different color)
    3. Eight color bar
    4. Full color bar
    
Protocols used:
---------------
    EPPI for Video dataflow

ADI Drivers and Services used:
------------------------------
    adi_dev.h           - Device manager
    services.h          - system services
    adi_eppi.h          - EPPI driver
    adi_lq043t1dg01.h   - SHARP LQ043T1DG01 LCD driver
            
Dataflow:
---------
    Video dataflow via EPPI.

** Note: Below macros are defined in project source file "RGB_Out.c"**

Display pattern selection macros:
=================================
**NOTE: Only one Display pattern generation macro must be enabled**

Macro name  : SINGLE_COLOR_FILL
Macro Usage : Macro to enable single color fill pattern. Display buffer filled with a single RGB888 color value.

Macro name  : QUAD_COLOR_FILL
Macro Usage : Macro to enable Quad color fill pattern. 
              This Display pattern spilts display buffer in to four equal parts and 
              fills each section with different color

Macro name  : EIGHT_COLOR_BAR_FILL
Macro Usage : Macro to enable Eight color bar fill pattern. 
              This Display pattern fills the display buffer with eight color bars

Macro name  : FULL_COLOR_BAR_FILL
Macro Usage : Macro to enable Full color bar fill pattern. 
              This Display pattern fills the display buffer with a color bar covering all supported colors

User Configuration Macros:
==========================

Macro name  : USE_DEFERRED_CALLBACKS
Macro Usage : Enable this macro to enable 'Deffered' callbacks. Disable it for callbacks to be 'live'.
              
Macro name  : USE_LOOPBACK
Macro Usage : Enable this macro for chained loopback dataflow method. Disable it for chained dataflow.

Macro name  : ENABLE_LCD_BOUNDARY
Macro Usage : Enable this macro to display LCD boundary with a different color. 
              This macro can be used to test LCD display alignment.

Macro name  : LCD_OUTPUT_RGB888
Macro Usage : Enable this macro for RGB888 (24-bit) output. Disable it for RGB666(18-bit) output.
              Make sure SW17 positions match the selected output mode.

Hardware Setup:
===============

    ADSP-BF548 Ez-Kit Lite Settings:
    --------------------------------
    Set all switches to default position (refer Ez-kit schematic)
    Then,
    SW5:  1(ON), 2(ON), 3(ON), 4(ON)
    SW14: 1(ON), 2(ON), 3(ON), 4(ON)
    For RGB888 (24-bit output), set SW17: 1(ON), 2(OFF), 3(ON),  4(OFF)
    For RGB666 (18-bit output), set SW17: 1(ON), 2(ON),  3(OFF), 4(OFF)
  
References:
===========
    ADSP-BF548 Hardware reference
    ADSP-BF548 EZ-Kit Lite Schematic
    SHARP LQ043T1DG01 LCD driver hardware reference
/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: ItuR656_Out.c,v $
$Revision: 1.3 $
$Date: 2007/05/30 16:55:45 $

Description:
	This is an example program to demonstrate EPPI ITU-R 656 transmit modes

	Refer to associated text file for project information

******************************************************************************

Include files

*****************************************************************************/

#include <services/services.h>	    		/* system service includes      */
#include <drivers/adi_dev.h>				/* device manager includes      */
#include <drivers/encoder/adi_adv717x.h>    /* ADV717x driver includes      */
#include <drivers/twi/adi_twi.h>            /* TWI driver includes          */
#include <drivers/eppi/adi_eppi.h>			/* EPPI driver include          */
#include "adi_ssl_init.h"           		/* System services init includes*/
#include "adi_itu656.h"           			/* ITU-R 656 Video Utilities  	*/
#include <stdio.h>

/*****************************************************************************

User configuration macros

*****************************************************************************/

/* Macro to enable deferred callbacks */
#define     USE_DEFERRED_CALLBACKS
/* Macro to enable chained with loopback */
#define     USE_LOOPBACK
/* Macro to enable internal blank generation. 
   Disable to create and output a complete video frame */
#define     USE_BLANKGEN
/* Enable this macro to build for PAL frame output. Disable for NTSC output */
//#define     EPPI_OUT_PAL_FRAME

/*****************************************************************************

Processor specific Macros

*****************************************************************************/

/* Processor DMA bus size = 4 bytes */
#define	    DMA_BUS_SIZE			4
/* EPPI Device Number to use - BF548 has 3 EPPI ports */
/*SHARP LQ043T1DG01 LCD is connected to EPPI 0*/
#define     EPPI_DEV_NUMBER         0
/* Use Pushbutton 4 (PB4) to terminate this program */
#define     TERMINATE_BUTTON        ADI_FLAG_PB11

/*****************************************************************************

ITU-R 656 specific Macros

*****************************************************************************/

#if defined(EPPI_OUT_PAL_FRAME)                     /* Build for PAL frame output */

#define NUM_FRAMES 		    25                      /* color change rate = every 25 frames */
#define	FRAME_NUM_LINES		PAL_FRAME_LINES         /* # lines per PAL frame */
#define	ITU_DATA_PER_LINE   PAL_DATA_PER_LINE       /* # active data per PAL line   */

#if defined(USE_BLANKGEN)                           /* If Internal Blank generation enabled */
#define	NUM_LINES		    PAL_ACTIVE_LINES        /* # active lines per PAL frame */
#define	DATA_PER_LINE	    ITU_ACTIVE_DATA_PER_LINE/* # active data per line   */
#else                                               /* Internal Blank generation disabled. Build and send an ITU-R 656 PAL frame */
#define	NUM_LINES		    FRAME_NUM_LINES         /* # lines per PAL frame */
#define	DATA_PER_LINE	    ITU_DATA_PER_LINE       /* # active data per PAL line   */
#endif

#else                                               /* Build test for PAL frame */

#define NUM_FRAMES 		    30                      /* color change rate = every 30 frames */
#define	FRAME_NUM_LINES		NTSC_FRAME_LINES        /* # lines per NTSC frame */
#define	ITU_DATA_PER_LINE   NTSC_DATA_PER_LINE      /* # active data per NTSC line   */

#if defined(USE_BLANKGEN)                           /* If Internal Blank generation enabled */
#define	NUM_LINES			NTSC_ACTIVE_LINES     	/* # active lines per NTSC frame */
#define	DATA_PER_LINE		ITU_ACTIVE_DATA_PER_LINE/* # active data per line   */
#else                                               /* Internal Blank generation disabled. Build and send an ITU-R 656 NTSC frame */
#define	NUM_LINES			FRAME_NUM_LINES         /* # lines per NTSC frame */
#define	DATA_PER_LINE		ITU_DATA_PER_LINE       /* # active data per NTSC line   */
#endif

#endif

/*****************************************************************************

YUV422 Color defines

*****************************************************************************/
/* list of YUV422 colors in UYVY format */
#define	    YUV422_BLACK  		        0x80108010
#define	    YUV422_RED 	    	        0x5A51F051
#define     YUV422_GREEN 		        0x36912291
#define     YUV422_BLUE     	        0xF0296E29
#define     YUV422_YELLOW 		        0x10D292D2
#define     YUV422_CYAN 		        0xA6AA10AA
#define     YUV422_MAGENTA  	        0xCA6ADE6A
#define     YUV422_WHITE 		        0x80EB80EB

/*****************************************************************************

Static data

*****************************************************************************/
/* Create two ITU656 frame in DDR which will be sent out to the monitor */
section("sdram0_bank1") static u8 PingFrame[DATA_PER_LINE * NUM_LINES];
section("sdram0_bank2") static u8 PongFrame[DATA_PER_LINE * NUM_LINES];

/* handle to the LCD driver */
static ADI_DEV_DEVICE_HANDLE    VideoOutDriverHandle;
/* DCB Managed Data */
static u8 DCBMgrData[ADI_DCB_QUEUE_SIZE + (ADI_DCB_ENTRY_SIZE)*4];
/* handle to the callback service */
static ADI_DCB_HANDLE          DCBManagerHandle;

/* Create two buffer chains */
ADI_DEV_2D_BUFFER PingBuffer[NUM_FRAMES];
ADI_DEV_2D_BUFFER PongBuffer[NUM_FRAMES];

FRAME_TYPE  Frame;          /* ITU-R 656 Frame type */

/* array to hold eight YUV422 color values to be displayed */
u32	DisplayColors[8] =  {   YUV422_BLACK, 
                            YUV422_RED, 
                            YUV422_GREEN, 
                            YUV422_BLUE, 
                            YUV422_YELLOW, 
                            YUV422_CYAN, 
                            YUV422_MAGENTA, 
                            YUV422_WHITE 
                        };

/*****************************************************************************

TWI Configuration table to access ADV7179 registers

*****************************************************************************/

/* Hardware TWI Configuration table for BF548 to access ADV7179 regs */
/* Run TWI clock at 100MHz & 50% Duty Cycle */
adi_twi_bit_rate rate={100,50};

ADI_DEV_CMD_VALUE_PAIR TWIConfig[]=
{ 
    { ADI_TWI_CMD_SET_HARDWARE, (void *)ADI_INT_TWI0    },  /* use hardware TWI port 0 */
    { ADI_TWI_CMD_SET_FIFO,     (void *)0x0000          },
    { ADI_TWI_CMD_SET_LOSTARB,  (void *)5               },
    { ADI_TWI_CMD_SET_RATE,     (void *)(&rate)         },     
    { ADI_TWI_CMD_SET_ANAK,     (void *)0               },
    { ADI_TWI_CMD_SET_DNAK,     (void *)0               },
    { ADI_DEV_CMD_END,          NULL                    }
};

/*********************************************************************

Function prototypes

*********************************************************************/
static ADI_INT_HANDLER(ExceptionHandler);	/* exception handler */
static ADI_INT_HANDLER(HWErrorHandler);		/* hardware error handler */
static void LcdCallback(
    void 	*AppHandle, 
    u32  	Event,
    void 	*pArg
);

/* ITU-R 656 display pattern generator */
void ItuDisplayPattern(
    u8  *pDataBuffer	/* Pointer to YUV422 frame  */
);

/*****************************************************************************

	Function:		ExceptionHandler
					HWErrorHandler

	Description:	We should never get an exception or hardware error,
					but just in case - display an error message 
					
*****************************************************************************/

static ADI_INT_HANDLER(ExceptionHandler)	        /* exception handler        */
{
	printf("Exception!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

static ADI_INT_HANDLER(HWErrorHandler)		        /* hardware error handler   */
{
	printf("HWerror!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

/*********************************************************************
*
*   Function:   main
*
*********************************************************************/
void main (void) 
{    
    u32     ResponseCount;
    u32     i;		
    u32     Result;
	u32     Sense;	
    ADI_DEV_ACCESS_REGISTER         ADV717x_Cfg;
    ADI_DEV_ACCESS_REGISTER_FIELD   FieldVal;
	
#if defined(EPPI_OUT_PAL_FRAME)
	printf("ITU-R 656 PAL Interlaced Video output");
	Frame = PAL_IL;
#else   
	printf("ITU-R 656 NTSC Interlaced Video output");
	Frame = NTSC_IL;
#endif	

/* IF (Internal Blank generation enabled) */
#if defined(USE_BLANKGEN) 
	printf(", with BLANKGEN Enabled.\n");
#else                                               /* Internal Blank generation disabled. Build and send an ITU-R 656 PAL frame */
	printf(", with BLANKGEN Disabled.\n");
#endif
	printf("Press Pushbutton 4 (PB4) to terminate this program\n");

	/* configure system - terminate configuration process on error */
    do
    {
        /**************** Initialise System Services ****************/
    
         if ((Result = adi_ssl_Init()) != 0)
        {
    	    printf("Initialising System Services Failed! Error code: 0x%8X\n",Result);
    	    break;
        }

        /* hook the exception interrupt*/
	    if((Result = adi_int_CECHook(3, ExceptionHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook exception handler, Error Code: 0x%08X\n",Result);
		    break;
        }
        
        /* hook the hardware error*/
	    if((Result = adi_int_CECHook(5, HWErrorHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook hardware error handler, Error Code: 0x%08X\n",Result);
		    break;
        }
        
/* if DCB selected, open the DCB manager & setup a queue */
#if defined(USE_DEFERRED_CALLBACKS)
	    if((Result = adi_dcb_Open(14, &DCBMgrData[ADI_DCB_QUEUE_SIZE], 
	                              (ADI_DCB_ENTRY_SIZE)*4, &ResponseCount, &DCBManagerHandle))!=0)
	    {
		    printf("adi_dcb_Open failed, Error Code: 0x%08X\n",Result);
		    break;
	    }
#else	/* else, live callback */
        DCBManagerHandle = NULL;
#endif
       
        /* Initialise the Pushbutton that is to be used to terminate this program */
        /* Open the Flag pin connected to the Terminate pushbutton */
        if((Result = adi_flag_Open(TERMINATE_BUTTON)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to open Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /* Set this flag as Input */
        if((Result = adi_flag_SetDirection(TERMINATE_BUTTON,ADI_FLAG_DIRECTION_INPUT)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to configure Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /************** Open ADV7179 device ***************/
    
        /* open the ADV7179 driver for video out */
        if((Result = adi_dev_Open(  adi_dev_ManagerHandle,     		/* Dev manager Handle                   */
                     	            &ADIADV7179EntryPoint,          /* Device Entry point                   */
                                    0,                              /* Device number                        */
	                                NULL,                           /* No client handle                     */
    	                            &VideoOutDriverHandle,          /* Location to store LCD driver handle  */
        	                        ADI_DEV_DIRECTION_OUTBOUND,     /* Data Direction                       */
            	                    adi_dma_ManagerHandle,         	/* Handle to DMA Manager                */
                	                DCBManagerHandle,               /* Handle to callback manager           */
                    	            LcdCallback))			        /* Callback Function                    */
		            != ADI_DEV_RESULT_SUCCESS) 
        {
     	    printf("Failed to open video output device , Error Code: 0x%08X\n",Result);
     	    break;
        }

        /************** Configure ADV7179 driver ***************/

        /* Set EPPI Device number */
        if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_ADV717x_CMD_SET_PPI_DEVICE_NUMBER, (void*)EPPI_DEV_NUMBER ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to set EPPI Device Number for ADV7179, Error Code: 0x%8X\n",Result);
            break;
        }

        /* Open the EPPI for ADV717x video out */
        if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_ADV717x_CMD_SET_PPI_STATUS, (void*)ADI_ADV717x_PPI_OPEN ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to open EPPI Device for ADV7179, Error Code: 0x%8X\n",Result);
            break;
        }
        
        /* Send TWI Configuration table */
        if((Result = adi_dev_Control(VideoOutDriverHandle,ADI_ADV717x_CMD_SET_TWI_CONFIG_TABLE,(void*)TWIConfig))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to set TWI Configuration Table, Error Code: 0x%8X\n",Result);
            break;
        }
        
        /************** Configure ADV7179 registers ***************/
    
        /* ADV717x register address to switch between NTSC & PAL */
        ADV717x_Cfg.Address = ADV717x_MR0;
    
#if defined(EPPI_OUT_PAL_FRAME)  /* Configure ADV717x for PAL video out */

        /* MR0 value to set ADV717x in PAL mode */
        ADV717x_Cfg.Data = 0x05;
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_ADV717x_CMD_SET_SCF_REG, (void *) ADV717x_SCF_VALUE_PAL_BI))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("adi_dev_Control failed to configure ADV717x SCF Regs: 0x%8X\n",Result);
            break;
        }
#else                   /* Configure ADV717x for NTSC video out */

        /* MR0 value to set ADV717x in NTSC mode */
        ADV717x_Cfg.Data = 0x00;
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_ADV717x_CMD_SET_SCF_REG, (void *) ADV717x_SCF_VALUE_NTSC))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("adi_dev_Control failed to configure ADV717x SCF Regs: 0x%8X\n",Result);
            break;
        }
#endif 

        /* configure ADV717x in selected mode */
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_REGISTER_WRITE, (void *)&ADV717x_Cfg))!= ADI_DEV_RESULT_SUCCESS)  
        {
            printf("adi_dev_Control failed to configure ADV717x operating mode: 0x%8X\n",Result);
            break;
        }
	
        /**************** EPPI Configuration for ITU-R 656 out ****************/ 

        /* AD7179 configures EPPI in following mode
           GP0 ITU Interlaced out mode, IFSGEN, ICLKGEN and BLANKGEN disabled, DMA unpacking enabled
           Also configures EPPI Lines per frame and Samples per line for selected ITU mode
        */

#if defined(USE_BLANKGEN)   /* If Internal Blank generation enabled */

        /* Configure EPPI to output ITU-R 656 Video with internally generated blank information (BLANKGEN enabled) */
        /* AD7179 driver handle can be used to configure EPPI registers, as AD7179 passes unrecogonised commands to EPPI */

#if defined(EPPI_OUT_PAL_FRAME)   /* Build for PAL output */

	    ADI_DEV_CMD_VALUE_PAIR EppiItuAVOut[] =                                 	/* ITU-R 656 PAL Active video out with BLANKGEN enabled                 */
        {
            { ADI_EPPI_CMD_ENABLE_BLANKGEN,                     (void *)TRUE    },  /* Enable BLANKGEN                                                      */
            { ADI_EPPI_CMD_SET_FS1_WIDTH,                       (void *)280     },  /* Horizontal blanking samples per line                                 */
            { ADI_EPPI_CMD_SET_FIELD1_PRE_ACTIVE_DATA_VBLANK,   (void *)22      },  /* Vertical blank before start of Field 1 Active Data                   */
            { ADI_EPPI_CMD_SET_FIELD1_POST_ACTIVE_DATA_VBLANK,  (void *)2       },  /* Vertical blank after the end of Field 1 Active Data                  */
            { ADI_EPPI_CMD_SET_FIELD2_PRE_ACTIVE_DATA_VBLANK,   (void *)23      },  /* Vertical blank before start of Field 2 Active Data                   */
            { ADI_EPPI_CMD_SET_FIELD2_POST_ACTIVE_DATA_VBLANK,  (void *)2       },  /* Vertical blank after the end of Field 2 Active Data                  */
            { ADI_EPPI_CMD_SET_FS1_PERIOD,                      (void *)1440    },  /* Active Video samples per line or Vertical blanking samples per line  */
            { ADI_EPPI_CMD_SET_FIELD1_ACTIVE_DATA_LINES,        (void *)288     },  /* # of Active data lines in Field 1                                    */
            { ADI_EPPI_CMD_SET_FIELD2_ACTIVE_DATA_LINES,        (void *)288     },  /* # of Active data lines in Field 2                                    */
            { ADI_DEV_CMD_END,                                  NULL            }
        };
        
#else         /* Build for NTSC output */
 
        ADI_DEV_CMD_VALUE_PAIR EppiItuAVOut[] =                                     /* ITU-R 656 NTSC Active video out with BLANKGEN enabled                */
        {
            { ADI_EPPI_CMD_ENABLE_BLANKGEN,                     (void *)TRUE    },  /* Enable BLANKGEN                                                      */
            { ADI_EPPI_CMD_SET_FS1_WIDTH,                       (void *)268     },  /* Horizontal blanking samples per line                                 */
            { ADI_EPPI_CMD_SET_FIELD1_PRE_ACTIVE_DATA_VBLANK,   (void *)17      },  /* Vertical blank before start of Field 1 Active Data                   */
            { ADI_EPPI_CMD_SET_FIELD1_POST_ACTIVE_DATA_VBLANK,  (void *)2       },  /* Vertical blank after the end of Field 1 Active Data                  */
            { ADI_EPPI_CMD_SET_FIELD2_PRE_ACTIVE_DATA_VBLANK,   (void *)17      },  /* Vertical blank before start of Field 2 Active Data                   */
            { ADI_EPPI_CMD_SET_FIELD2_POST_ACTIVE_DATA_VBLANK,  (void *)3       },  /* Vertical blank after the end of Field 2 Active Data                  */
            { ADI_EPPI_CMD_SET_FS1_PERIOD,                      (void *)1440    },  /* Active Video samples per line or Vertical blanking samples per line  */
            { ADI_EPPI_CMD_SET_FIELD1_ACTIVE_DATA_LINES,        (void *)243     },  /* # of Active data lines in Field 1                                    */
            { ADI_EPPI_CMD_SET_FIELD2_ACTIVE_DATA_LINES,        (void *)243     },  /* # of Active data lines in Field 2                                    */
            { ADI_DEV_CMD_END,                                  NULL            }
        };
    
#endif /* EPPI_OUT_PAL */
    
        /* Configure EPPI registers */
	    if((Result = adi_dev_Control( VideoOutDriverHandle, ADI_DEV_CMD_TABLE, (void*)EppiItuAVOut ))!= ADI_DEV_RESULT_SUCCESS)
	    {
		    printf("Failed to configure EPPI for ITU-R 656 video out, Error Code: 0x%08X\n",Result);
		    break;
        }

#endif  /* USE_BLANKGEN */

	    /****************** Prepare Video Frames *******************/
	
/* IF (Internal Blank generation disabled) */
#if !defined(USE_BLANKGEN)

	    /* Format video out buffers to selected frame type - fill with blank information */
	    adi_video_FrameFormat((char*)PingFrame,Frame);
	    adi_video_FrameFormat((char*)PongFrame,Frame);

#endif 

	    /* Fill the frame with specified display pattern */
	    ItuDisplayPattern(PingFrame);
	    ItuDisplayPattern(PongFrame);
	    
	    /******************Buffer preparation **********************/

	    /*
    	   create a buffer chain that points to the PingFrame.  Each buffer points to the same PingFrame
	       so the PingFrame will be displayed NUM_FRAMES times.  NUM_FRAMES is sized to 
    	   keep the display busy for 1 second.  Place a callback on only the last buffer
	       in the chain.  Make the CallbackParameter (the value that gets passed to the callback
    	   function as the pArg parameter) point to the first buffer in the chain.  This way, when
	       the callback goes off, the callback function can requeue the whole chain if the loopback
    	   mode is off.
	    */

        /* FOR (Number of output 2D buffers) */
        for (i = 0; i < NUM_FRAMES; i++) 
        {
            PingBuffer[i].Data              = PingFrame;
            PingBuffer[i].ElementWidth      = DMA_BUS_SIZE;
            PingBuffer[i].XCount            = (DATA_PER_LINE/DMA_BUS_SIZE);
            PingBuffer[i].XModify           = DMA_BUS_SIZE;
            PingBuffer[i].YCount            = NUM_LINES;
            PingBuffer[i].YModify           = DMA_BUS_SIZE;
            PingBuffer[i].CallbackParameter = NULL;
            PingBuffer[i].pNext             = &PingBuffer[i + 1];   /* chain to next buffer in the list */
        }

        /* DMA generates Callback when last buffer in the chain is processed
           address of first buffer in the chain is passed as callback parameter */
        PingBuffer[NUM_FRAMES - 1].CallbackParameter = &PingBuffer[0];
        /* Terminate this buffer chain */
        PingBuffer[NUM_FRAMES - 1].pNext = NULL;
  
        /* now do the same for the Pong buffers */
        /* FOR (Number of output 2D buffers) */
        for (i = 0; i < NUM_FRAMES; i++) 
        {
            PongBuffer[i].Data              = PongFrame;
            PongBuffer[i].ElementWidth      = DMA_BUS_SIZE;
            PongBuffer[i].XCount            = (DATA_PER_LINE/DMA_BUS_SIZE);
            PongBuffer[i].XModify           = DMA_BUS_SIZE;
            PongBuffer[i].YCount            = NUM_LINES;
            PongBuffer[i].YModify           = DMA_BUS_SIZE;
            PongBuffer[i].CallbackParameter = NULL;
            PongBuffer[i].pNext             = &PongBuffer[i + 1];   /* chain to next buffer in the list */
        }
    
        /* DMA generates Callback when last buffer in the chain is processed
           address of first buffer in the chain is passed as callback parameter */
        PongBuffer[NUM_FRAMES - 1].CallbackParameter = &PongBuffer[0];  
        /* Terminate this buffer chain */
        PongBuffer[NUM_FRAMES - 1].pNext = NULL;
    
/* Set Dataflow method */
#if defined(USE_LOOPBACK)
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW_METHOD, (void *)ADI_DEV_MODE_CHAINED_LOOPBACK ))!= ADI_DEV_RESULT_SUCCESS)
#else
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW_METHOD, (void *)ADI_DEV_MODE_CHAINED ))!= ADI_DEV_RESULT_SUCCESS)
#endif    
        {
            printf("Failed to set dataflow method, Error Code: 0x%08X\n",Result);
            break;
        }

        /* give the ping-pong buffers to the device */
        if((Result = adi_dev_Write(VideoOutDriverHandle, ADI_DEV_2D, (ADI_DEV_BUFFER *)PingBuffer))!= ADI_DEV_RESULT_SUCCESS)
        {
    	    printf("Failed to submit PingBuffer, Error Code: 0x%08X\n",Result);
    	    break;
        }
   
        if((Result = adi_dev_Write(VideoOutDriverHandle, ADI_DEV_2D, (ADI_DEV_BUFFER *)PongBuffer))!= ADI_DEV_RESULT_SUCCESS)
        {
    	    printf("Failed to submit PongBuffer, Error Code: 0x%08X\n",Result);
    	    break;
        }

        /* Enable AD7179 video data flow */
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW, (void *)TRUE))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to enable dataflow, Error Code: 0x%08X\n",Result);
        }
    
    }while(0);
    
    /* IF (video out configuration results in success) */
  	if (Result == ADI_DEV_RESULT_SUCCESS)
    {
        /* continue displaying frames to LCD until the user presses the terminate button */
        while ((Result = adi_flag_Sense(TERMINATE_BUTTON, &Sense)) == ADI_DEV_RESULT_SUCCESS)
        {
            /* IF (Terminate button pressed) */
            if(Sense)
            {
                break;
            }
        }

        /* Disable ADV7179 video data flow */
        if((Result = adi_dev_Control(VideoOutDriverHandle, ADI_DEV_CMD_SET_DATAFLOW, (void *)FALSE))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to disable dataflow, Error Code: 0x%08X\n",Result);
        }
   
    	/* close the video out driver */
    	if((Result = adi_dev_Close(VideoOutDriverHandle)) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to close video output driver, Error Code: 0x%08X\n",Result);
    	}

    	/* Terminate system services */
    	if((Result = adi_ssl_Terminate()) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to terminate system services, Error Code: 0x%08X\n",Result);
    	}    
	}
	else
	{
		printf("Program terminated abnormally with error code: 0x%08X\n",Result);
	}
	printf ("Done!\n");
}

/*****************************************************************************

    Function:       EncoderCallback

    Description:    Each type of callback event has it's own unique ID 
                    so we can use a single callback function for all 
                    callback events.  The switch statement tells us 
                    which event has occurred.
                    
*****************************************************************************/
/* place this part of code in L1 */
section ("L1_code")
static void LcdCallback(
    void 	*AppHandle,
    u32  	Event,
    void 	*pArg
){
    
    ADI_DEV_2D_BUFFER *pBuffer;		/* pointer to the buffer that was processed */
	u32 Result;
	
    /* CASEOF (event type) */
    switch (Event) 
    {    
        /* CASE (buffer processed) */
        case ADI_DEV_EVENT_BUFFER_PROCESSED:

            /* when the buffer chain was created, the CallbackParameter value for the buffer
               that was generating the callback was set to be the address of the first buffer
               in the chain.  So here in the callback that value is passed in as the pArg
               parameter. */
            pBuffer = (ADI_DEV_2D_BUFFER *)pArg;

            /* Update LCD Display pattern */
            ItuDisplayPattern(pBuffer->Data);

#if defined(USE_LOOPBACK)
			/* if loopback is enabled, the driver will continually reuse the buffers. */
#else
			/* if loopback is disabled though, we need to requeue the buffer chain that just finished */
            adi_dev_Write(VideoOutDriverHandle, ADI_DEV_2D, pArg);

#endif
			
            break;

        /* CASE (EPPI Status Error) */
        case ADI_EPPI_EVENT_LUMA_FIFO_ERROR:         
        case ADI_EPPI_EVENT_LINE_TRACK_OVERFLOW_ERROR:         
        case ADI_EPPI_EVENT_LINE_TRACK_UNDERFLOW_ERROR:         
        case ADI_EPPI_EVENT_FRAME_TRACK_OVERFLOW_ERROR:
        case ADI_EPPI_EVENT_FRAME_TRACK_UNDERFLOW_ERROR:
        case ADI_EPPI_EVENT_PREAMBLE_ERROR_NOT_CORRECTED:
        case ADI_EPPI_EVENT_PREAMBLE_ERROR:
			printf("EPPI status error. Event code: 0x%08X\n",Event);		
			break;
			
        /* CASE (DMA Error) */
        case ADI_DEV_EVENT_DMA_ERROR_INTERRUPT:
            printf("DMA error\n");
            break;
            
		default:
			printf("Callback event not supported. Event code: 0x%08X\n",Event);
			break;
    }
    
    /* return */
}

/******************************************************************************
    Function:       LcdDisplayPattern

    Description:    Fills YUV422 frame with the selected display pattern
    
******************************************************************************/
void ItuDisplayPattern(
    u8  *pDataBuffer        /* Pointer to YUV422 frame      */
){
    u32     Line,DataPerLine;
    u8      UYVY[4];
    u8      Y1,U,Y2,V;
    u32     ColorCycle,i;
    
    /* extract UYVY data from first color value in DisplayColors array */
    UYVY[0] = (u8) (DisplayColors[0] >> 24);    /* U  */
    UYVY[1] = (u8) (DisplayColors[0] >> 16);    /* Y1 */
    UYVY[2] = (u8) (DisplayColors[0] >> 8);     /* V  */
    UYVY[3] = (u8) (DisplayColors[0]);          /* Y2 */

/* IF (Internal Blank generation enabled) */
#if defined(USE_BLANKGEN)

    /* FOR (each line) */
    for(Line = 0; Line < NUM_LINES; Line++)
    {
        /* FOR (each pixel) */ 
        for(DataPerLine = 0; DataPerLine < (DATA_PER_LINE / 4); DataPerLine++)
        {
			/* fill with UYVY Data */
            *pDataBuffer++ = UYVY[0];   /* U  */
            *pDataBuffer++ = UYVY[1];   /* Y1 */
            *pDataBuffer++ = UYVY[2];   /* V  */
            *pDataBuffer++ = UYVY[3];   /* Y2 */
        }
    }

#else   /* Internal Blank generation disabled, fill frame with color values in UYVY array */
        adi_video_FrameFill((char*)pDataBuffer,Frame,(char*)&UYVY[0]);
#endif 
   
    /* Cycle Display colors array */
	ColorCycle = DisplayColors[0];
	for (i=0;i < (sizeof(DisplayColors)/sizeof(u32));i++)
	{
	    DisplayColors[i] = DisplayColors[i+1];
	}
	DisplayColors[(sizeof(DisplayColors)/sizeof(u32))-1] = ColorCycle;

}

/*****/

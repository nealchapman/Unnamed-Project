Project Name: ItuR656_Out.dpj

Description: Example program to demonstrate EPPI ITU-R 656 transmit modes
    
Project Type:
=============
    ADSP-BF533 [ ]
    ADSP-BF537 [ ]
    ADSP-BF548 [X]
    ADSP-BF561 [ ]

Hardware/Tools Used:
====================
    ADSP-BF548 EZ-Kit Lite Rev 1.1
    Analog Devices VisualDSP++ 5.0
    ADDS HPUSB-ICE
    Blackfin AV Ez-Extender rev 2.0
    
System Services Components Used:
================================
    DMA Manager                         [X]   Deferred Callback Manager   [X]
    Interrupt Manager                   [X]   Timer Module                [ ]
    Power Management Module             [X]   Flag Module                 [ ]
    External Bus Interface Unit Module  [X]   Port Module                 [X]

Overview:
=========

    This is an example program to demonstrate EPPI ITU-R 656 transmit modes
			
    The program outputs a single colored video frame to the TV screen.
    Two ITU-R 656 frame sized buffers are used to create the selected display pattern. 
    Created display patterns are sent to ADV7179 on Blackfin AV Extender via EPPI0.

	EPPI 0 is configured in GP0 mode to transmit entire video frame (or)
	in GP2 mode to transmit active video only with internally generated Blacnk information
    
    The program can be terminated by pressing Pushbutton 4 (PB4) on the Ez-Kit
        
    This example targets ADSP-BF548 and tested on ADSP-BF548 Ez-Kit lite rev 1.1
    
Protocols used:
---------------
    EPPI for Video dataflow
    TWI to access ADV7179 registers
    
ADI Drivers and Services used:
------------------------------
    services.h          - system services
    adi_dev.h           - Device manager
    adi_eppi.h          - EPPI driver
    adi_twi.h           - TWI driver
    adi_device_access.h - To access ADV7179 device registers
    adi_adv717x.h       - ADV717x device driver
            
Dataflow:
---------
    Video dataflow via EPPI.
    Configure ADV7179 registers via TWI
    
** Note: Below macros are defined in project source file "ItuR656_Out.c"**

User Configuration Macros:
==========================

Macro name  : USE_DEFERRED_CALLBACKS
Macro Usage : Enable this macro to enable 'Deffered' callbacks. Disable it for callbacks to be 'live'.
              
Macro name  : USE_LOOPBACK
Macro Usage : Enable this macro for chained loopback dataflow method. Disable it for chained dataflow.

Macro name  : USE_BLANKGEN
Macro Usage : Enable this macro to transmit active video only with internally generated blank information. 
              Disable to create and output a complete video frame.

Macro name  : EPPI_OUT_PAL_FRAME
Macro Usage : Enable macro for for ITU-R 656 PAL output, disable for NTSC output. 
              This Macro is valid only when PixC output is in YUV422 format.

Hardware Setup:
===============

	Connect Blackfin A-V Extender to ADSP-BF548(Moab) Ez-Kit.

	ADSP-BF548 Ez-Kit Lite Settings:
    --------------------------------
	All switches to default position
	Then, 
	SW5:  1(ON), 2(ON),  3(ON), 4(ON)
	SW14: 1(OFF), 2(OFF), 3(OFF), 4(OFF)
	SW17: 1(OFF), 2(OFF), 3(OFF), 4(OFF)
	
	

	Blackfin A-V Ez-Extender jumper settings:
    -----------------------------------------
	JP1: No Jumpers installed
	JP2: No Jumpers installed
	JP3: 3-5, 4-6 (Connects to BF548 TWI 0)
	JP4: 1-3 (Connects 27MHz clock to EPPI0_CLK)
	JP5: 3-4 (Connects ADV7179 data port to EPPI0)
	JP6: No Jumpers installed
	JP7: No Jumpers installed
	JP8: No Jumpers installed
	JP9: 3-5 (Connects AV extender reset to system reset)
	JP10: No Jumpers installed

	External connections:
	---------------------
        Connect a monitor to the A-V Extender card video-out connector. The video 
        connectors are the bank of 6 RCA-style jacks on the A-V Extender card labeled as J7.
        
         J7 +---------------------------------------------------+
            |          O          O < Video Out  O              |               
            |          O          O              O              |
            +---------------------------------------------------+
  
References:
===========
    ADSP-BF548 Hardware reference
    ADSP-BF548 EZ-Kit Lite Schematic
    Blackfin AV Ez-Extender rev 2.0 schematic
    ADV7179 Hardware reference manual
/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: AD7877Example.c,v $
$Revision: 1.2 $
$Date: 2007/05/15 02:52:30 $

Description:
	This is an example program for AD7877 Touchscreen controller driver

	Refer to associated text file for project information

******************************************************************************

Include files

*****************************************************************************/

#include <services/services.h>				/* system service includes 	*/
#include <drivers/adi_dev.h>				/* device manager includes 	*/
#include <drivers/touchscreen/adi_ad7877.h> /* AD7877 driver includes   */
#include "adi_ssl_init.h"					/* system services init		*/				
#include <stdio.h>

/*****************************************************************************

User configurations:

*****************************************************************************/

/* Enable macro for deferred callbacks. Disable for callbacks to be 'live' */
#define     USE_DEFERRED_CALLBACKS

/*****************************************************************************

Processor specific Macros

*****************************************************************************/
/* Port Info for PENIRQ */
#define     PENIRQ_FLAG_ID              ADI_FLAG_PJ12;  /* PENIRQ signal connected to this Flag */
#define     PENIRQ_FLAG_INTERRUPT_ID    ADI_INT_PINT2;  /* Interrupt ID for PENIRQ Flag         */
/* Port Info for DAV */
#define     DAV_FLAG_ID                 ADI_FLAG_PJ11;  /* DAV signal connected to this Flag    */
#define     DAV_FLAG_INTERRUPT_ID       ADI_INT_PINT2;  /* Interrupt ID for DAV Flag            */

/* SPI Device number connected to AD7877 */
#define     AD7877_SPI_DEV_NUMBER       0
/* SPI Device chipselect used to access AD7877 registers */
#define     AD7877_SPI_CS               2

/* Use Pushbutton 4 (PB4) to terminate this program */
#define     TERMINATE_BUTTON        	ADI_FLAG_PB11

/*****************************************************************************

Static data

*****************************************************************************/

/* handle to the LCD driver */
static ADI_DEV_DEVICE_HANDLE AD7877DriverHandle;
/* DCB Manager Data */
static u8 DCBMgrData[ADI_DCB_QUEUE_SIZE + (ADI_DCB_ENTRY_SIZE)*4];
/* handle to the callback service */
static ADI_DCB_HANDLE          DCBManagerHandle;

/*****************************************************************************

AD7877 device register configuration table(s)

*****************************************************************************/

/* Configuration table for Master Sequencer mode */
ADI_DEV_ACCESS_REGISTER_FIELD	AD7877_MasterSequencer[] =
{   
	{ AD7877_CONTROL_REG1,      AD7877_MODE,        3   },  /* ADC in Master sequencer mode             */
    { AD7877_CONTROL_REG1,      AD7877_SER_DFR,     0   },  /* Differential conversion                  */
	{ AD7877_CONTROL_REG2,      AD7877_TMR,         3   },  /* Convert every 8.19ms						*/
    { AD7877_CONTROL_REG2,      AD7877_REF,         1   },  /* External reference                       */
    { AD7877_CONTROL_REG2,      AD7877_POL,         1   },  /* STOPACQ - Active High                    */
    { AD7877_CONTROL_REG2,      AD7877_FCD,         2   },  /* First Conversion Delay = 1.024ms         */
    { AD7877_CONTROL_REG2,      AD7877_PM,          2   },  /* ADC & reference powered up continuously  */
    { AD7877_CONTROL_REG2,      AD7877_ACQ,         2   },  /* ADC acquisition time = 8us               */
    { AD7877_CONTROL_REG2,      AD7877_AVG,         1   },  /* 4 measurements per channel averaged      */
    { AD7877_SEQUENCER_REG1,    AD7877_YPOS_S,      1   },  /* Enable Y position measurement            */
    { AD7877_SEQUENCER_REG1,    AD7877_XPOS_S,      1   },  /* Enable X position measurement            */
    { AD7877_SEQUENCER_REG1,    AD7877_Z2_S,        1   },  /* Enable Z2 touch pressure measurement     */
    { AD7877_SEQUENCER_REG1,    AD7877_Z1_S,        1   },  /* Enable Z1 touch pressure measurement     */
    { ADI_DEV_REGEND,           0,                  0   }   /* Terminate this configuration table       */            
};            
    
/*********************************************************************

Function prototypes

*********************************************************************/
static ADI_INT_HANDLER(ExceptionHandler);	/* exception handler */
static ADI_INT_HANDLER(HWErrorHandler);		/* hardware error handler */
/* AD7877 callback */
static void Callback(
    void 	*AppHandle, 
    u32  	Event,
    void 	*pArg
);

/*****************************************************************************

	Function:		ExceptionHandler
					HWErrorHandler

	Description:	We should never get an exception or hardware error,
					but just in case - display an error message 
					
*****************************************************************************/

static ADI_INT_HANDLER(ExceptionHandler)	        /* exception handler        */
{
	printf("Exception!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

static ADI_INT_HANDLER(HWErrorHandler)		        /* hardware error handler   */
{
	printf("HWerror!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

/*****************************************************************************

    Function:       AD7877Callback

    Description:    Each type of callback event has it's own unique ID 
                    so we can use a single callback function for all 
                    callback events.  The switch statement tells us 
                    which event has occurred.
                    
*****************************************************************************/
static void AD7877Callback(
    void 	*AppHandle,
    u32  	Event,
    void 	*pArg
){

    /* pointer to AD7877 results location */
    ADI_AD7877_RESULT_REGS	*AD7877Results;
	u32 Result;
	u32 i;
    /* CASEOF (event type) */
    switch (Event) 
    {
        
        /* CASE (PENIRQ occurred) */
        case ADI_AD7877_EVENT_PENIRQ:
            break;
            
        /* CASE (Single Channel DAV occurred) */
        case ADI_AD7877_EVENT_SINGLE_DAV:
            break;
        
        /* CASE (Sequencer DAV occurred) */
        case ADI_AD7877_EVENT_SEQUENCER_DAV:
    		/* AD7877 passes pointer to the results register structure as argument */
        	AD7877Results = (ADI_AD7877_RESULT_REGS *)pArg;
            printf("Co-ordinates   (x,y)   : (0x%04X,0x%04X)\n", AD7877Results->X, AD7877Results->Y);
            printf("Touch pressure (z1,z2) : (0x%04X,0x%04X)\n", AD7877Results->Z1, AD7877Results->Z2);
            break;
            
        /* CASE (ALERT occurred) */
        case ADI_AD7877_EVENT_ALERT:
            printf("ALERT occurred\n");
            break;
            
		default:
			printf("Callback event not recogonised. Event code: 0x%08X\n",Event);
			break;
                
    /* ENDCASE */
    }
    
    /* return */
}

/*********************************************************************
*
*   Function:   main
*
*********************************************************************/
void main (void) 
{    
    u32     ResponseCount;
    u32     i;		
    u32     Result;
    u32     Sense;
    /* structure to hold Port Info for DAV */
    ADI_AD7877_INTERRUPT_PORT   DavIrqPort;
    /* structure to hold Port Info for PENIRQ */
    ADI_AD7877_INTERRUPT_PORT   PenIrqPort;
        
	printf ("AD7877 Touch screen Controller example for ADSP-BF548 Ez-Kit Lite \n");

    /* configure system - terminate configuration process on error */
    do
    {
        /**************** Initialise System Services ****************/
    
        if ((Result = adi_ssl_Init()) != 0)
        {
    	    printf("Initialising System Services Failed! Error code: 0x%08X\n",Result);
    	    break;
        }

        /* hook the exception interrupt*/
	    if((Result = adi_int_CECHook(3, ExceptionHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook exception handler, Error Code: 0x%08X\n",Result);
		    break;
        }
        
        /* hook the hardware error*/
	    if((Result = adi_int_CECHook(5, HWErrorHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook hardware error handler, Error Code: 0x%08X\n",Result);
		    break;
        }
	        
/* if DCB selected, open the DCB manager & setup a queue */
#if defined(USE_DEFERRED_CALLBACKS)
	    if((Result = adi_dcb_Open(14, &DCBMgrData[ADI_DCB_QUEUE_SIZE], 
	                              (ADI_DCB_ENTRY_SIZE)*4, &ResponseCount, &DCBManagerHandle))!=0)
	    {
		    printf("adi_dcb_Open failed, Error Code: 0x%08X\n",Result);
		    break;
	    }
#else	/* else, live callback */
        DCBManagerHandle = NULL;
#endif

        /* Initialise the Pushbutton that is to be used to terminate this program */
        /* Open the Flag pin connected to the Terminate pushbutton */
        if((Result = adi_flag_Open(TERMINATE_BUTTON)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to open Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /* Set this flag as Input */
        if((Result = adi_flag_SetDirection(TERMINATE_BUTTON,ADI_FLAG_DIRECTION_INPUT)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to configure Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /************** Open AD7877 driver ***************/
    
        /* open the AD7877 driver */
        if((Result = adi_dev_Open(  adi_dev_ManagerHandle,     		/* Dev manager Handle                       */
                     	            &ADIAD7877EntryPoint,           /* Device Entry point                       */
                                    0,                              /* Device number                            */
	                                NULL,                           /* No client handle                         */
    	                            &AD7877DriverHandle,            /* Location to store AD7877 driver handle   */
        	                        ADI_DEV_DIRECTION_OUTBOUND,     /* Data Direction                           */
            	                    adi_dma_ManagerHandle,         	/* Handle to DMA Manager                    */
                	                DCBManagerHandle,               /* Handle to callback manager               */
                        	        AD7877Callback))		        /* Callback Function                        */
	                	!= ADI_DEV_RESULT_SUCCESS) 
        {
         	printf("Open AD7877 driver Failed!, Error Code: 0x%08X\n",Result);
         	break;
        }

        /**************** AD7877 Driver Configuration Table ****************/
        /* Port Info for PENIRQ */
        PenIrqPort.FlagId       = PENIRQ_FLAG_ID;
        PenIrqPort.FlagIntId    = PENIRQ_FLAG_INTERRUPT_ID;
        /* Port Info for DAV */
        DavIrqPort.FlagId       = DAV_FLAG_ID;
        DavIrqPort.FlagIntId    = DAV_FLAG_INTERRUPT_ID;

        /* Configuration Table to use AD7877 device on BF548 Ez-Kit Lite */
	    ADI_DEV_CMD_VALUE_PAIR  AD7877_BF548EzKit[]=
	    {
            { ADI_AD7877_CMD_SET_SPI_DEVICE_NUMBER, (void *)AD7877_SPI_DEV_NUMBER   },  /* SPI device to use        */
            { ADI_AD7877_CMD_SET_SPI_CS,            (void *)AD7877_SPI_CS           },  /* SPI CS for AD7877        */
            { ADI_AD877_ENABLE_INTERRUPT_PENIRQ,    (void *)&PenIrqPort             },  /* Enable PENIRQ monitoring */
            { ADI_AD877_ENABLE_INTERRUPT_DAV,       (void *)&DavIrqPort             },  /* Enable DAV Monitoring    */
		    { ADI_DEV_CMD_END,					    NULL                            }   /* Terminate config table   */
	    }; 
	
	    /**************** Configure AD7877 Driver ****************/
        if((Result = adi_dev_Control(AD7877DriverHandle, ADI_DEV_CMD_TABLE, (void *)AD7877_BF548EzKit))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to configure AD7877 driver: 0x%08X\n",Result);
		    break;
        }
        
	    /**************** Configure AD7877 Device registers ****************/
        if((Result = adi_dev_Control(AD7877DriverHandle, ADI_DEV_CMD_REGISTER_FIELD_TABLE_WRITE, (void *)AD7877_MasterSequencer))!= ADI_DEV_RESULT_SUCCESS)
        {
		   	printf("Failed to configure AD7877 device registers: 0x%08X\n",Result);
        }
    }while (0);
    
    /* IF (AD7877 configuration results in success) */
  	if (Result == ADI_DEV_RESULT_SUCCESS)
    {
        printf("AD7877 is up and running...\n");
        printf("Press Pushbutton 4 (PB4) to terminate this program\n");
        /* wait for touchscreen activity until user presses terminate button */
        while ((Result = adi_flag_Sense(TERMINATE_BUTTON, &Sense)) == ADI_DEV_RESULT_SUCCESS)
        {
            /* IF (Terminate button pressed) */
            if(Sense)
            {
                break;
            }
        }
  
    	/* close AD7877 driver */
    	if((Result = adi_dev_Close(AD7877DriverHandle)) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to close AD7877 driver, Error Code: 0x%08X\n",Result);
    	}

    	/* Terminate system services */
    	if((Result = adi_ssl_Terminate()) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to terminate system services, Error Code: 0x%08X\n",Result);
    	}    
	}
	else
	{
		printf("Program terminated abnormally with error code: 0x%08X\n",Result);
	}
	printf ("Done!\n");
}

/*****/

Project Name: AD7877Example.dpj

Description: AD7877 Touchscreen controller driver example
    
Project Type:
=============
    ADSP-BF533 [ ]
    ADSP-BF537 [ ]
    ADSP-BF548 [X]
    ADSP-BF561 [ ]

Hardware/Tools Used:
====================
    ADSP-BF548 EZ-Kit Lite Rev 1.1
    Analog Devices VisualDSP++ 5.0
    ADDS HPUSB-ICE

System Services Components Used:
================================
    DMA Manager                         [X]   Deferred Callback Manager   [X]
    Interrupt Manager                   [X]   Timer Module                [X]
    Power Management Module             [X]   Flag Module                 [X]
    External Bus Interface Unit Module  [X]   Port Module                 [X]

Overview:
=========

    The example program configures AD7877 in Master sequencer mode,
	enables x,y co-ordinates and touch pressure (z1,z2) measurements
	    
	When the touch screen is tapped using a stylus, the program displays
	the x,y co-ordinates corresponding to the touched screen area and
	its touch pressure measurements on to VisualDSP++ console window.

Protocols used:
---------------
    SPI to access AD7877 registers

ADI Drivers and Services used:
------------------------------
    adi_dev.h           - Device manager
    services.h          - system services
    adi_ad7877.h        - AD7877 driver
            
Dataflow:
---------
    Read/Write AD7877 registers via SPI 
    
** Note: Below macros are defined in project source file "Test_AD7877.c"**

User Configuration Macros:
==========================

Macro name  : USE_DEFERRED_CALLBACKS
Macro Usage : Enable this macro to enable 'Deffered' callbacks. Disable it for callbacks to be 'live'.

Hardware Setup:
===============

    ADSP-BF548 Ez-Kit Lite Settings:
    --------------------------------
    Set all switches to default position (refer Ez-kit schematic)
    Then,
    SW14: 1(ON), 2(ON), 3(ON), 4(ON)
    
References:
===========
    ADSP-BF548 Hardware reference
    ADSP-BF548 EZ-Kit Lite Schematic
    AD7877 Device referance manual
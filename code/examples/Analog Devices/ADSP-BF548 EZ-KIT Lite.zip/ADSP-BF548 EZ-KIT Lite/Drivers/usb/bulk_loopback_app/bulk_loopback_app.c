/*********************************************************************************

Copyright(c) 2005 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.

*********************************************************************************/


/*********************************************************************

Include files

*********************************************************************/

#include <services/services.h>		/* system service includes */
#include <drivers/adi_dev.h>		/* device manager includes */

#include <drivers\usb\usb_core\adi_usb_objects.h>
#include <drivers\usb\usb_core\adi_usb_core.h>
#include <drivers\usb\usb_core\adi_usb_ids.h>
#include <drivers\usb\controller\otg\adi\bf54x\adi_usb_bf54x.h>
#include <drivers\usb\class\peripheral\vendor_specific\adi\bulkadi\adi_usb_bulkadi.h>		/* adi bulk driver header file */
#include <..\..\..\..\..\Examples\usb\host\windows\hostapp\hostapp.h>						/* hostapp definitions         */

extern ADI_DEV_PDD_ENTRY_POINT ADI_USBDRC_Entrypoint;

/* firmware version string info */
#pragma align 4
char FwVersionInfo[NUM_VERSION_STRINGS][MAX_VERSION_STRING_LEN] = {
																	__DATE__,		/* build date       */
																	__TIME__,		/* build time       */
																	"03.00.00",		/* version number   */
#ifdef __ADSPBF533__
																	"ADSP-BF533",	/* target processor */
#elif defined(__ADSPBF537__)
																	"ADSP-BF537",	/* target processor */
#elif defined(__ADSPBF561__)
																	"ADSP-BF561",	/* target processor */
#elif defined(__ADSPBF548__)
																	"ADSP-BF548",	/* target processor */
#else
#error *** Processor not supported ***
#endif
																	"loopback"};	/* application name */

volatile bool g_bRxFlag = FALSE;			/* rx flag */
volatile bool g_bTxFlag = FALSE;			/* tx flag */
volatile bool g_bUsbConfigured = FALSE;		/* USB device configured flag */


/*********************************************************************

Prototypes

*********************************************************************/

u32 usb_Read(	ADI_DEV_DEVICE_HANDLE DeviceHandle, ADI_DEV_BUFFER_TYPE BufferType,
				ADI_DEV_BUFFER *pBuffer, bool bWaitForCompletion);
u32 usb_Write(	ADI_DEV_DEVICE_HANDLE DeviceHandle, ADI_DEV_BUFFER_TYPE BufferType,
				ADI_DEV_BUFFER *pBuffer, bool bWaitForCompletion);
u32 QuerySupport( ADI_DEV_DEVICE_HANDLE devhandle, u32 u32Command );
u32 Loopback(ADI_DEV_DEVICE_HANDLE devhandle, u32 u32Count);
u32 ReadMemory( ADI_DEV_DEVICE_HANDLE devhandle, u8 *p8Address, u32 u32Count );
u32 WriteMemory( ADI_DEV_DEVICE_HANDLE devhandle, u8 *p8Address, u32 u32Count );


/*********************************************************************

Static data

*********************************************************************/

static ADI_DEV_DEVICE_HANDLE DevHandle;										/* device handle                 */
static u8 IntMgrData[                      (ADI_INT_SECONDARY_MEMORY * 0)];	/* storage for interrupt manager */
static u8 DMAMgrData[ADI_DMA_BASE_MEMORY + (ADI_DMA_CHANNEL_MEMORY * 4)];	/* storage for DMA manager       */
static u8 DevMgrData[ADI_DEV_BASE_MEMORY + (ADI_DEV_DEVICE_MEMORY * 4)];	/* storage for device manager    */
static ADI_INT_CRITICAL_REGION_DATA	CriticalRegionData;						/* storage for critical region   */
static ADI_DEV_BUFFER usbBuffers[10];
static s32 g_ReadEpID;
static s32 g_WriteEpID;


/*********************************************************************

	Function:		failure

	Description:	In case of failure we toggle LEDs.

*********************************************************************/

void failure(void)
{
	while (1)
	{
		;
	}
}

/*********************************************************************

	Function:		ExceptionHandler
					HWErrorHandler

	Description:	We should never get an exception or hardware error,
					but just in case we'll catch them should one ever occur.

*********************************************************************/

static ADI_INT_HANDLER(ExceptionHandler)	/* exception handler */
{
    return(ADI_INT_RESULT_PROCESSED);
}

static ADI_INT_HANDLER(HWErrorHandler)		/* hardware error handler */
{
	return(ADI_INT_RESULT_PROCESSED);
}

/*********************************************************************

	Function:		ClientCallback

	Description:	Each type of callback event has it's own unique ID
					so we can use a single callback function for all
					callback events.  The switch statement tells us
					which event has occurred.

					Note that in the device driver model, in order to
					generate a callback for buffer completion, the
					CallbackParameter of the buffer must be set to a non-NULL
					value.  That non-NULL value is then passed to the
					callback function as the pArg parameter.

*********************************************************************/

void ClientCallback( void *AppHandle, u32 Event, void *pArg)
{
	static unsigned int TxCtr = 0;				/* number of buffers processed     */
	static unsigned int RxCtr = 0;				/* number of buffers processed     */
	static unsigned int SetConfigCtr = 0;		/* number of SET_CONFIGs           */
	static unsigned int RootPortResetCtr = 0;	/* number of root port resets      */
	static unsigned int VbusFalseCtr = 0;		/* number of VBUS false detections */

	/* note, AppHandle will be handle which was passed into the adi_dev_open() call */
	switch (Event)
	{
	    /* 
		 *   Transmit complete event 
		 */
		case ADI_USB_EVENT_DATA_TX:			
  		    /* pArg holds the address of the data buffer processed */
			g_bTxFlag = TRUE;
			/* set flag and increment counter */
			TxCtr++;
		break;
		
		/* 
		 *  Receive complete event 
		 */
		case ADI_USB_EVENT_DATA_RX:			
			/* pArg holds the address of the data buffer processed */
			g_bRxFlag = TRUE;
			/* set flag and increment counter */
			RxCtr++;
		break;

		/* 
		 *  Host called set configuration 
		 */
		case ADI_USB_EVENT_SET_CONFIG:		
			/* pArg holds the configuration number */
			if (0x1 == (u32)pArg)
				g_bUsbConfigured = TRUE;
			else
				g_bUsbConfigured = FALSE;
            /* set flag and increment counter */
			SetConfigCtr++;
		break;

		/* 
		 *  Reset signaling detected 
		 */
		case ADI_USB_EVENT_ROOT_PORT_RESET: 
			/* pArg is NULL for this event */
			g_bUsbConfigured = FALSE;
			/* set flag and increment counter */
			RootPortResetCtr++;
		break;

		/* 
		 * VBUS is below thershold 
		 */
		case ADI_USB_EVENT_VBUS_FALSE: 		
			/* pArg is NULL for this event */
			g_bUsbConfigured = FALSE;
			/* set flag and increment counter */
			VbusFalseCtr++;
		break;

	    /* 
		 * Resume event
		 */
		case ADI_USB_EVENT_RESUME: 			
			/* pArg is NULL for this event */
		break;
		
	    /* 
		 * Suspend event, if cable is unplugged this event gets trigged.
		 */
		case ADI_USB_EVENT_SUSPEND: 		
			/* pArg is NULL for this event */
			break;
	}
	
}
/*********************************************************************
 *
 * Function: ConfigureEndpoints
 *
 **********************************************************************/
static unsigned int ConfigureEndpoints(void)
{
ADI_ENUM_ENDPOINT_INFO EnumEpInfo;              /* Binded Endpoint information */
static ADI_USB_APP_EP_INFO g_UsbAppEpInfo[2] = {0};
unsigned int Result;

	   /* Get Read and Write Endpoints */
	    EnumEpInfo.pUsbAppEpInfo = &g_UsbAppEpInfo[0];
		EnumEpInfo.dwEpTotalEntries = sizeof(g_UsbAppEpInfo)/sizeof(ADI_USB_APP_EP_INFO);
		EnumEpInfo.dwEpProcessedEntries = 0;

		/* Get the enumerated endpoints */
	    Result = adi_dev_Control( DevHandle, ADI_USB_CMD_CLASS_ENUMERATE_ENDPOINTS, (void*)&EnumEpInfo);

	    if (Result != ADI_DEV_RESULT_SUCCESS)
		       failure();

		if(g_UsbAppEpInfo[0].eDir == USB_EP_IN)
		{
		    g_WriteEpID = g_UsbAppEpInfo[0].dwEndpointID;
		    g_ReadEpID  = g_UsbAppEpInfo[1].dwEndpointID;
		}
		else
		{
            g_ReadEpID = g_UsbAppEpInfo[0].dwEndpointID;
		 	g_WriteEpID = g_UsbAppEpInfo[1].dwEndpointID;
		}

		return(Result);
}


/*********************************************************************
*
*	Function:	main
*
*********************************************************************/

void main(void)
{
	unsigned int Result;							/* result */
	unsigned int i;									/* index   */
	bool bKeepRunning = TRUE;						/* keep running flag */
	u32	ResponseCount;								/* response count    */
	u32 SecondaryCount;								/* secondary count   */
	ADI_DEV_MANAGER_HANDLE DeviceManagerHandle;		/* DevMgr handle     */
	ADI_DMA_MANAGER_HANDLE DMAHandle;				/* DMAMgr handle     */
	ADI_DEV_1D_BUFFER  *pBuf;						/* 1D buffer ptr     */
	ADI_DEV_1D_BUFFER UsbcbBuffer;					/* 1D buffer for processing usbcb */
	USBCB usbcb;									/* USB command block              */
	PDEVICE_DESCRIPTOR pDevDesc;					/* device descriptor ptr          */
	ADI_DEV_PDD_HANDLE PeripheralDevHandle;         /* USB controller driver handle */

	/* Initialize the buffer */
	UsbcbBuffer.Data = &usbcb;
	UsbcbBuffer.ElementCount = sizeof(usbcb);
	UsbcbBuffer.ElementWidth = 1;
	UsbcbBuffer.CallbackParameter = NULL;
	UsbcbBuffer.ProcessedFlag = FALSE;
	UsbcbBuffer.ProcessedElementCount = 0;
	UsbcbBuffer.pNext = NULL;

	/* Initialize interrupt manager */
	Result = adi_int_Init(	IntMgrData,			/* ptr to memory for use by IntMgr */
							sizeof(IntMgrData),	/* size of memory for use by IntMgr */
							&ResponseCount,		/* response count */
							NULL);				/* NULL */
	if (Result != ADI_INT_RESULT_SUCCESS)
		failure();

	/* Initialize DMA  Manager */
	Result = adi_dma_Init(	DMAMgrData,			/* ptr to memory for use by DmaMgr */
							sizeof(DMAMgrData),	/* size of memory for use by DmaMgr */
							&ResponseCount,		/* response count */
							&DMAHandle,			/* ptr to DMA handle */
							NULL);				/* NULL */
	if (Result != ADI_DMA_RESULT_SUCCESS)
		failure();


	/* Initialize Device Manager */
	Result = adi_dev_Init(	DevMgrData,				/* ptr to memory for use by DevMgr */
							sizeof(DevMgrData),		/* size of memory for use by DevMgr */
							&ResponseCount,			/* returns number of devices DevMgr can support */
							&DeviceManagerHandle,	/* ptr to DevMgr handle */
							&CriticalRegionData);	/* ptr to critical region info */

	if (Result != ADI_DEV_RESULT_SUCCESS)
		failure();
		
	/* Initialize USB Core 	*/
    adi_usb_CoreInit((void*)&Result);
    
    /* Open controller driver */
    Result = adi_dev_Open(	DeviceManagerHandle, 			/* DevMgr handle */
							&ADI_USBDRC_Entrypoint,			/* pdd entry point */
							0,                          	/* device instance */
							(void*)1,						/* client handle callback identifier */
							&PeripheralDevHandle,	        /* device handle */
							ADI_DEV_DIRECTION_BIDIRECTIONAL,/* data direction for this device */
							DMAHandle,						/* handle to DmaMgr for this device */
							NULL,							/* handle to deferred callback service */
							ClientCallback);				/* client's callback function */
    if (Result != ADI_DEV_RESULT_SUCCESS)
		failure();
    
	/* Open the vendor specific Bulk USB class driver */
	Result = adi_dev_Open(	DeviceManagerHandle,			/* DevMgr handle */
							&ADI_USB_VSBulk_Entrypoint,		/* pdd entry point  */
							0,								/* device instance */
							(void*)0x1,						/* client handle callback identifier */
							&DevHandle,						/* DevMgr handle for this device */
							ADI_DEV_DIRECTION_BIDIRECTIONAL,/* data direction for this device */
							DMAHandle,						/* handle to DmaMgr for this device */
							NULL,							/* handle to deferred callback service */
							ClientCallback);				/* client's callback function */
	if (Result != ADI_DEV_RESULT_SUCCESS)
		failure();

	/* get a pointer to the device descriptor which is maintained by the usb core */
	pDevDesc = adi_usb_GetDeviceDescriptor();
	if (!pDevDesc)
		failure();

	/* customize the device descriptor for this device */
	pDevDesc->wIdVendor = USB_VID_ADI_TOOLS;
#if defined(__ADSPBF533__)
	pDevDesc->wIdProduct = USB_PID_BF533KIT_NET2272EXT_BULK;
#elif defined(__ADSPBF537__)
	pDevDesc->wIdProduct = USB_PID_BF537KIT_NET2272EXT_BULK;
#elif defined(__ADSPBF561__)
	pDevDesc->wIdProduct = USB_PID_BF561KIT_NET2272EXT_BULK;
#elif defined(__ADSPBF548__)
	pDevDesc->wIdProduct = USB_PID_BF548KIT_BULK;
#else
#error *** Processor not supported ***
#endif

    /* configure the controller mode */
	Result = adi_dev_Control(DevHandle, ADI_USB_CMD_CLASS_SET_CONTROLLER_HANDLE, (void*)PeripheralDevHandle);
	if (Result != ADI_DEV_RESULT_SUCCESS)
		failure();

	/* configure the controller mode */
	Result = adi_dev_Control(DevHandle, ADI_USB_CMD_CLASS_CONFIGURE, (void*)0);
	if (Result != ADI_DEV_RESULT_SUCCESS)
		failure();

	/* configure the controller mode */
	Result = adi_dev_Control(DevHandle, ADI_DEV_CMD_SET_DATAFLOW_METHOD, (void*)ADI_DEV_MODE_CHAINED);
	if (Result != ADI_DEV_RESULT_SUCCESS)
		failure();

	/* enable data flow */
	Result = adi_dev_Control(DevHandle, ADI_DEV_CMD_SET_DATAFLOW, (void*)TRUE);
	if (Result != ADI_DEV_RESULT_SUCCESS)
		failure();

	/* enable USB connection with host */
	Result = adi_dev_Control( PeripheralDevHandle, ADI_USB_CMD_ENABLE_USB, (void*)0);
	if (Result != ADI_DEV_RESULT_SUCCESS)
		failure();

	while (bKeepRunning)
	{
	    /* wait until the USB is configured by the host before continuing */
		while( !g_bUsbConfigured )
			;
        /* Get the endpoint information */
	    ConfigureEndpoints();

		/* wait for a USB command block from the host indicating what function we should perform */
		Result = usb_Read(DevHandle, ADI_DEV_1D, (ADI_DEV_BUFFER *)&UsbcbBuffer, TRUE);

		if ( ADI_DEV_RESULT_SUCCESS == Result )
		{
			/* switch on the command we just received */
			switch( usbcb.u32_Command )
		    {
				/* host is asking if we support a given command */
				case QUERY_SUPPORT:
					Result = QuerySupport( DevHandle, usbcb.u32_Data );
		    		break;

		    	/* get the firmware version */
			    case GET_FW_VERSION:
			    	Result = ReadMemory( DevHandle, (u8*)FwVersionInfo, usbcb.u32_Count );
			        break;

				/* run loopback */
			    case LOOPBACK:
					Result = Loopback( DevHandle, usbcb.u32_Count );
			        break;

				/* read memory */
			    case MEMORY_READ:
					Result = ReadMemory( DevHandle, (u8*)usbcb.u32_Data, usbcb.u32_Count );
			        break;

				/* write memory */
			    case MEMORY_WRITE:
					Result = WriteMemory( DevHandle, (u8*)usbcb.u32_Data, usbcb.u32_Count );
			        break;

				/* unsupported command */
			    default:
			   		failure();
			        break;
	    	}
		}

	}

	/* close the device */
	Result = adi_dev_Close(DevHandle);
	if (Result != ADI_DEV_RESULT_SUCCESS)
		failure();
}


/*********************************************************************

	Function:		usb_Read

	Description:	Wrapper for adi_dev_Read() which lets the user specify if
					they want to wait for completion or not.

	Arguments:		ADI_DEV_DEVICE_HANDLE devhandle -	device handle
					ADI_DEV_BUFFER_TYPE BufferType -	buffer type
					ADI_DEV_BUFFER *pBuffer -			pointer to buffer
					bool bWaitForCompletion -			completion flag

	Return value:	u32 - return status

*********************************************************************/

u32 usb_Read(	ADI_DEV_DEVICE_HANDLE 	DeviceHandle,			/* device handle */
				ADI_DEV_BUFFER_TYPE		BufferType,				/* buffer type   */
				ADI_DEV_BUFFER 			*pBuffer,				/* pointer to buffer */
				bool					bWaitForCompletion)		/* completion flag */
{
    u32 Result = ADI_DEV_RESULT_SUCCESS;
    ADI_DEV_1D_BUFFER			*p1DBuff;

    p1DBuff = (ADI_DEV_1D_BUFFER*)pBuffer;

    /* Place the Read Endpoint ID */
    p1DBuff->Reserved[BUFFER_RSVD_EP_ADDRESS] = g_ReadEpID;

 	/* if the user wants to wait until the operation is complete */
    if (bWaitForCompletion)
    {
        /* clear the rx flag and call read */
   		g_bRxFlag = FALSE;
		Result = adi_dev_Read(DeviceHandle, BufferType, pBuffer);

		/* wait for the rx flag to be set */
		while (!g_bRxFlag)
		{
		    /* make sure we are still configured, if not we should fail */
			if ( !g_bUsbConfigured )
				return ADI_DEV_RESULT_FAILED;
		}

		return Result;
    }
    /* else they do not want to wait for completion */
    else
    {
        return (adi_dev_Read(DeviceHandle, BufferType, pBuffer));
    }
}


/*********************************************************************

	Function:		usb_Write

	Description:	Wrapper for adi_dev_Write() which lets the user specify if
					they want to wait for completion or not.

	Arguments:		ADI_DEV_DEVICE_HANDLE devhandle -	device handle
					ADI_DEV_BUFFER_TYPE BufferType -	buffer type
					ADI_DEV_BUFFER *pBuffer -			pointer to buffer
					bool bWaitForCompletion -			completion flag

	Return value:	u32 - return status

*********************************************************************/

u32 usb_Write(	ADI_DEV_DEVICE_HANDLE 	DeviceHandle,			/* DM handle         */
				ADI_DEV_BUFFER_TYPE		BufferType,				/* buffer type       */
				ADI_DEV_BUFFER			*pBuffer,				/* pointer to buffer */
				bool					bWaitForCompletion)		/* completion flag   */
{
    u32 Result = ADI_DEV_RESULT_SUCCESS;
    ADI_DEV_1D_BUFFER			*p1DBuff;
    p1DBuff = (ADI_DEV_1D_BUFFER*)pBuffer;

    /* Place the Endpoint ID */
    p1DBuff->Reserved[BUFFER_RSVD_EP_ADDRESS] = g_WriteEpID;

 	/* if the user wants to wait until the operation is complete */
    if (bWaitForCompletion)
    {
        /* clear the tx flag and call read */
   		g_bTxFlag = FALSE;
		Result = adi_dev_Write(DeviceHandle, BufferType, pBuffer);

		/* wait for the tx flag to be set */
		while (!g_bTxFlag)
		{
		   /* make sure we are still configured, if not we should fail */
			if ( !g_bUsbConfigured )
				return ADI_DEV_RESULT_FAILED;
		}

		return Result;
    }
    /*else they do not want to wait for completion */
    else
    {
        return (adi_dev_Write(DeviceHandle, BufferType, pBuffer));
    }
}

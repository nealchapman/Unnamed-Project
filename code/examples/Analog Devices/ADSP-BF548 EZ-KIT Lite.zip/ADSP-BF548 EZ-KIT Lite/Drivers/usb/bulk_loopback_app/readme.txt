"ADSP-BF548 EZ-KIT Lite USB Bulk Loopback Demo"

Date Created: 05/08/07 

This directory contains an example ADSP-BF548 Project which demonstrates how to create 
and run the BF548 USB bulk loopback example. 

All the examples ship pre-built but you can rebuild them yourself.The source 
files are included in the directory structure shown below:

+---Blackfin
    +---Examples
    �   +---ADSP-BF548 EZ-KIT Lite
    �       +---Drivers 	
    �           +---USB 	
    �               +---bulk_loopback_app    
    �		           bulk_loopback_app.c
    �		           bulk_loopback_app_bf548.dpj
    �		           usb_ezkit_utils.c
    �		           usb_loopback.c
    |                      Readme.txt	
    +---Examples
    �   +---USB
    �       +---host 	
    �           +---windows    
    |       	    +---drivers
    �		 	   bulkadi.inf
    �		 	   bulkadi.sys
    �               +---hostapp    
    �		 	   adiguid.h
    �		 	   console.cpp
    �		 	   console.h
    �		 	   hostapp.exe
    �		 	   hostapp.vcproj
    �		 	   loopback.cpp
    �		 	   main.cpp
    �		 	   memory.cpp
    �		 	   usbdriver.cpp
    �		 	   usbdriver.h
    �		 	   usbio.cpp

__________________________________________________________

	
CONTENTS

I.    Overview
II.   Hardware Requirements and Setup
III.  Building the Bulk Host Utility
IV.   Building the Bulk Host Driver
V.    Using the Blackfin USB 2.0 Connection
VI.   Using the Bulk Examples


I. Overview

Support is included for USB 2.0 bulk transfers between a Windows host PC and the
BF548 EZ-KIT.All the source code for the utilities and firmware are also included.  


II. Hardware Requirements and Setup

The requirements of the USB software are as follows:

* BF548 EZ-KIT Lite (Board Rev 1.2 and up)
* Windows 2000, Windows XP or Vista operating system
* PC with available USB port

We recommend using a host PC with a built-in USB 2.0 controller otherwise
performance will be greatly reduced.  Even USB 2.0 plug-in controllers will show a
decrease in performance compared to systems with built-in USB 2.0 controllers.

Please also note that using other USB devices simultaneously may slow down the
performance of the BF548 EZ-KIT Example.  Simple input devices such as keyboards and
mice should not cause a problem, but for example using the USB Debug Agent connection
on the EZ-KIT may decrease the performance of both applications.  Shutting down
VisualDSP++ after loading the firmware will allow to operate as fast as possible if 
you are also using the USB Debug Agent connection.

In order to properly enable the USB functionality, certain switch settings on the USB-LAN
and EZ-KIT will need to be changed.  Please make sure your EZ-KIT and USB-LAN have the
following switch settings as described below:

EZ-KIT Lite switch and jumper settings:
	- SW1	1 = ON.
	- SW2	ALL ON.
	- SW4	1 = ON,  2 = ON,  3 = OFF, 4 = OFF.
	- SW5	ALL ON.
	- SW6	1 = OFF, 2 = OFF, 3 = ON,  4 = ON.
	- SW7	1 = ON,  2 = ON,  3 = ON,  4 = OFF.
	- SW8	ALL OFF.
	- SW14	ALL ON.
	- SW15	1 = OFF, 2 = OFF, 3 = ON,  4 = ON.
	- SW16	ALL ON.
	- SW17	1 = ON,  2 = OFF, 3 = ON,  4 = OFF.
	
	- JP1-3,7,8: OFF
	- JP4-6: ON
	- JP11:	ON ON

            

III. Building the Bulk Host Utility

Note, the host application is only used with the bulk firmware examples. 

To build the hostapp Windows utility follow these steps:

1. Double-click on the "<USB>\host\hostapp\hostapp.vcproj" project file to launch Visual C++.
2. Select the "Build->Rebuild hostapp" menu option to rebuild all.  Note, the
   executable (.exe) will be placed in the same folder as the project file (.vcproj).



IV. Building the Bulk Host Driver

Note, the host driver is only used with the bulk firmware examples. 

In order to rebuild the host driver you will need the Microsoft Windows 2003 Server
DDK.  The DDK's bulkusb example was used to create the bulkadi example host driver.
The Windows 2003 Server DDK is available from Microsoft.  For more information on
obtaining the DDK visit: http://www.microsoft.com/whdc/devtools/ddk/default.mspx
[NOTE: Make sure to include the WDM Samples while selecting the Driver Development Kit
Component Groups to include the bulkusb samples]

The following changes were made to bulkusb [WINDDK\3790.1830\src\wdm\usb]in order to 
create the bulkadi driver.
Follow these steps closely in order to create your own custom bulk example.

1. Copy all the files in the bulkusb folder to a new folder named bulkadi and make
   all your changes in the bulkadi folder.
2. In file bulkusb.h, BULKUSB_MAX_TRANSFER_SIZE was changed from 256 to 64k (64*1024).
   Leaving it unchanged greatly reduces the performance.(Also, make sure to use the 
   paranthesis).
3. In file bulkusb.h, the end of the define for BULKUSB_REGISTRY_PARAMETERS_PATH was
   changed from "BULKUSB\\Parameters" to "BULKADI\\Parameters" so that the new driver
   doesn't reference bulkusb's information.
4. In file bulkusb.rc, all three references to bulkusb were changed to bulkadi.  This
   will change the driver detail information such as file description and filename.
5. In file bulkusr.h, the DEFINE_GUID macro is used to define the sample GUID named
   GUID_CLASS_I82930_BULK.  we changed the name to GUID_BULKADI. 
   (i)If creating a custom bulk driver: use the "guidgen.exe" utility to create a new GUID.
   "guidgen.exe" is included in the DDK package [WINDDK\3790.1830\tools\other\i386].
   Each driver must use a unique GUID which can be created with guidgen.exe.
   This newly created GUID should be used by your host application to open a handle to
   the driver.
   (ii)Otherwise: use the GUID that has already been created by adi under:
   [VDSP]\Blackfin\Examples\usb\host\windows\hostapp\adiguid.h
6. In file bulkusb.c, the GUID used in step #5 is referenced in function
   BulkUsb_AddDevice().  If you changed the name of the GUID in step #5 you must also
   change the reference to the GUID in this file to the same name (such as to
   GUID_BULKADI).
7. In file bulkpnp.c, Interface->Pipes[i].MaximumTransferSize is changed to
   BULKUSB_MAX_TRANSFER_SIZE in function SelectInterfaces().
8. In file bulkwmi.c, another GUID is defined named BULKUSB_WMI_STD_DATA_GUID.  We
   once again used guidgen.exe to create a new GUID but left the name unchanged.  This
   is for Windows Management Instrumentation (WMI) support.
9. In file sources, we changed the TARGETNAME from bulkusb to bulkadi.
10. Note, we use our own INF file so the one supplied with bulkusb (bulkusb.inf) is not
    used.  Use the INF located in "host\hostdriver" instead.
11. From the Windows Start menu, select "Programs->Development Kits->Windows DDK 3790.1830->
    Build Environments->Windows XP", then choose the desired build environment,either the 
    "Windows XP Free Build Environment" (release) or the "Windows XP Checked Build Environment"
    (debug).It is generally recommended to rebuild in both the environments.
12. In the console window that appears change directory to the bulkadi folder by
    entering "cd src\wdm\usb\bulkadi" at the command prompt.
13. To build enter "build -cZ" at the command prompt.  Note the lowercase 'c' (delete
    all object files) and the uppercase 'Z' (no dependency checking or scanning of
    source files with three-passes) are case-sensitive.
14. The driver (.sys) will be output to either the free or checked folder depending on
    build environment selected. The driver file is about 18kb in free (release) mode, and 
    about 48k in checked (debug) mode



V. Using the Blackfin USB 2.0 Connection

1. Be sure you have read both the User's Guide and "Hardware Requirements and Setup"
   section of this file and followed their instructions.
2. Connect to your target board with VisualDSP++.  If you need help configuring
   VisualDSP++ please refer to your VisualDSP++ documentation.
3. Select the "File->Load Program" menu and load the example application (.dxe).
4. Select the "Settings->Target Options" menu in order to change the "On Emulator
   Exit" option to "Run from current PC".  Otherwise if have the option set to
   "Stall the DSP" and close down VisualDSP++ it will stall the Blackfin and any
   subsequent USB operation will fail.
5. Select the "Debug->Run" menu to start executing the Blackfin firmware.
6. Connect a USB cable from the host PC to the BF548 EZ-Kit USB connector.
7. The first time you run the firmware on a PC, Windows should detect a new USB device
   and start up the New Hardware Wizard.
8. For bulk examples choose the option to browse for the driver and point the wizard to
   the "<USB>\host\windows\drivers" folder in order to locate the driver files.  
9. Once the driver installation is finished you can check the Windows Device Manger
   and make sure you see the "Blackfin BF548 USB Device" listed under "ADI Development Tools"
   for bulk examples.
10. Your BF548 EZ-KIT is now ready to communicate with a host.

Remember that if you want to shut down VisualDSP++ after loading the firmare, be sure
to change the "Settings->Target Options->On Emulator Exit" menu option to "Run from
current PC" otherwise VisualDSP++ will stall the processor on exit and USB
communication will not be functional.



VI. Using the Bulk Examples

There is one host application "<USB>\host\hostapp\hostapp.exe" and two example bulk
firmware examples provided (loopback and redirect_IO).  hostapp works with both firmware examples
and must be run from a Windows command line.  Use the -h switch for more information.  In
addition to their intended function, both bulk firmware applications support other simple
commands such as dumping memory, filling memory, getting firmware version, etc.

Note, that setting breakpoints in the firmware may cause the host utility to timeout
depending on the method used by the host to open a connection with the device.  The
loopback example uses asynchronous I/O and is capable of timing out while the redirect_IO
example uses synchronous I/O and will not time out.  If you execute an asynchronous
Read() or Write() from the host and hit a breakpoint on the device before completing the
transaction you will timeout.  Just be sure not to place breakpoints in code that
performs the read or write and you should not timeout.

The loopback example sends data from the host to the device and back to the host again.
The host verifies that the data is correct and performs some calculations which it
displays to the user.  The loopback example program flow looks as follows:

         HOST SIDE                                    DEVICE SIDE
==============================================================================
T0)                                                - waits for a command
T1) - establishes communication with device
T2) - sends down command (-l, -c, -r, etc.)
T3)                                                - receives command and waits for data
T4) - sends down data
T5) - waits for data                                - receives data
T6)                                                 - sends back data
T7) - receives data                                 - waits for more data
T8) - verifies and performs calculations


The redirect_IO example allows the device to open files on the host, read and write these files,
and redirects stdio from the device to the host window for viewing by the user.  The redirect_IO
example can be used to allow users to get debug (printf) information from the device
faster and even without VisualDSP++ running.  The redirect_IO example program flow looks as
follows:

         HOST SIDE                                    DEVICE SIDE
==============================================================================
T0)                                                 - waits for a command
T1) - establishes communication with device
T2) - sends down command (-u, etc.)
T3) - wait for I/O requests                         - receives command and starts I/O
T4)                                                 - sends I/O request
T5) - receives I/O request and handles it           - waits for reply
T6) - sends reply
T7) - waits for next I/O request                    - receives reply


INTERPRETATION OF THE OUTPUT DATA
=================================

The table at the bottom probably conveys the most important bandwidth information.

Here's an loopback example table:

                           LAST   AVERAGE    AVERAGE     MAX     MIN
                                  LAST 100
---------------------------------------------------------------------
OUT - from host (MB/s):   19.25    19.42      19.40     20.30   10.52
IN  - to host   (MB/s):   21.93    21.92      21.88     22.79   20.34
Timestamps:               Out Max: 00:00:00:02   Out Min: 00:00:00:00
                          In Max:  00:00:00:00   In Min:  00:00:00:01


LAST: Gives you the bandwidth for the last run of the loopback test.
AVERAGE LAST 100: Calculates the bandwidth for the last 100 runs and displays the average rate.
  This is particluarly useful for tuning.
AVERAGE: This is probably the most useful information that gives you the averge bandwidth the
  device runs at.
MAX: The best case bandwidth 
MIN: The worst case bandwidth
TIMESTAMPS: Time of best case Out, best case In & worst case Out, worst case In.
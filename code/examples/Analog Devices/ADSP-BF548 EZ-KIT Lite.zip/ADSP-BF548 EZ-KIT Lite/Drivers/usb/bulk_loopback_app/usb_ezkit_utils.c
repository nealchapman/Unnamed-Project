/*********************************************************************************

Copyright(c) 2005 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.

Description:	EZ-Kit utility routines.  This file contains a collection
				of functions that automate typical EZ-Kit functionality,
				including control of LEDs and push buttons.

*********************************************************************************/


/*********************************************************************

Include files

*********************************************************************/

#include <services/services.h>		// system service includes
#include <sysreg.h>					// system config definitions
#include "usb_ezkit_utils.h"		// EZ-Kit utility definitions


/*********************************************************************

Enumerations and defines

*********************************************************************/


#define pFlashA_PortA_In	((volatile unsigned char *)0x20270000)	// address of flash A port A input data register
#define pFlashA_PortA_Out	((volatile unsigned char *)0x20270004)	// address of flash A port A output data register
#define pFlashA_PortA_Dir	((volatile unsigned char *)0x20270006)	// address of flash A port A direction register

#define pFlashA_PortB_In	((volatile unsigned char *)0x20270001)	// address of flash A port B input data register
#define pFlashA_PortB_Out	((volatile unsigned char *)0x20270005)	// address of flash A port B output data register
#define pFlashA_PortB_Dir	((volatile unsigned char *)0x20270007)	// address of flash A port B direction register

#define pFlashB_PortA_In	((volatile unsigned char *)0x202E0000)	// address of flash B port A input data register
#define pFlashB_PortA_Out	((volatile unsigned char *)0x202E0004)	// address of flash B port A output data register
#define pFlashB_PortA_Dir	((volatile unsigned char *)0x202E0006)	// address of flash B port A direction register

#define pFlashB_PortB_In	((volatile unsigned char *)0x202E0001)	// address of flash B port B input data register
#define pFlashB_PortB_Out	((volatile unsigned char *)0x202E0005)	// address of flash B port B output data register
#define pFlashB_PortB_Dir	((volatile unsigned char *)0x202E0007)	// address of flash B port B direction register


/*********************************************************************

	Function:		ezConfigurePLL

	Description:	Initializes and sets the PLL to 594 for CCLK and
					118 for SCLCK.

*********************************************************************/

void ezConfigurePLL(void)
{

#ifdef __ADSPBF533__

	// CLKIN on BF533 EZ-KIT is 27 MHz
	// MAX CCLK for BF533 is either 500, 600 or 756 MHz depending on version
	// MAX SCLK for BF533 is 133 MHz

	sysreg_write(reg_SYSCFG, 0x32);
	*pSIC_IWR = 0x1;					// enable PLL wakeup

	*pPLL_CTL = 0x2C00;		// MSEL is 22, which gives:	VCO of 594 MHz (27*22=594)

	*pPLL_DIV = 0x5;		// SSEL is 5, which gives:	SCLK of 118.8 MHz (594/5=118.8)
							// CSEL is 0, which gives:	CCLK of 594 MHz (594/1=594)
	ssync();
	idle();

#elif defined(__ADSPBF537__)

	// CLKIN on BF537 EZ-KIT is 25 MHz
	// MAX SCLK for BF537 is 133 MHz

	sysreg_write(reg_SYSCFG, 0x32);
	*pSIC_IWR = 0x1;					// enable PLL wakeup

	*pPLL_CTL = 0x3000;		// MSEL is 24, which gives:	VCO of 594 MHz (25*24=600)

	*pPLL_DIV = 0x5;		// SSEL is 5, which gives:	SCLK of 120 MHz (600/5=120)
							// CSEL is 0, which gives:	CCLK of 600 MHz (600/1=600)
	ssync();
	idle();

#elif defined(__ADSPBF561__)

	// CLKIN on BF561 EZ-KIT is 30 MHz
	// MAX CCLK for BF561 is either 500, 600 or 756 MHz depending on version
	// MAX SCLK for BF561 is 133 MHz

	// CLKIN is determined by the oscillator on the target board while CCLK and SCLK
	// can be determined by the user but must be within allowable limits of the Blackfin.
	// Read the chapter entitled "Dynamic Power Management" in the Blackfin Hardware
	// Reference for more information.
	#define CLKIN		30000000		// clockin frequency in Hz
	#define CCLK		600000000		// core clock frequency in Hz
	#define SCLK		120000000		// system clock frequency in Hz

	short CCLK_multiplier = (short)(CCLK/CLKIN);
	short SCLK_divider = (short)(CCLK/SCLK);
	short previous_PLL= *pPLL_CTL;
	short previous_SICA_IWR = *pSICA_IWR0;
	short previous_SICB_IWR = *pSICB_IWR0;
	short new_PLL= (previous_PLL & 0x81ff) | ((CCLK_multiplier & 0x3f) <<9);

	// let COREB start fetching instruction
	*pSICA_SYSCR &= 0xffdf;	// clear COREB_SRAM_INIT

	// skip if multiplier has not changed
	if (new_PLL != previous_PLL)
	{
		// do things for Core A
		if ((int)(*pSRAM_BASE_ADDRESS) == 0xFF800000 )
		{
			*pSICB_SYSCR |= 0x0080;					// Raise Core B Supplemental-Int0
			ssync();

			while((*pSICB_SYSCR & 0x080));			// Wait: Core B Acknowledge SUP-B0

			*pSICA_IWR0 = (previous_SICA_IWR | 0x1);// enable PLL Wakeup Interrupt
			*pPLL_CTL = new_PLL;
			ssync();

			idle();							  		// put in idle

 			*pSICA_IWR0 = previous_SICA_IWR;		// continue here after idle, restore previous IWR content
			ssync();
		}

		// do things for Core B
		else
		{
			while(!(*pSICB_SYSCR & 0x0080));		// Wait: For Core A to raise SUP-B0
			*pSICB_SYSCR = 0x0800;					// Acknowledge Supplemental Interrupt
			ssync();

			*pSICB_IWR0 = (previous_SICB_IWR | 0x1);// enable PLL Wakeup Interrupt
			ssync();

			idle();									// put in idle

			*pSICB_IWR0 = previous_SICB_IWR;		// continue here after idle, restore previous IWR content
			ssync();
		}
	}

	*pPLL_DIV = (*pPLL_DIV & 0xFFF0) | SCLK_divider;
	ssync();

#else
#error *** Processor not supported ***
#endif

}



/*********************************************************************

	Function:		ezConfigureSDRAM

	Description:	Initializes and sets SDRAM parameters on the EZ-Kit.

*********************************************************************/

void ezConfigureSDRAM(void)
{
	unsigned short tempReg=0;

	tempReg = *pEBIU_SDSTAT;
	tempReg = tempReg & SDRS;

	// SDRS is bit 8 of EBIU_SDSTAT register. If SDRS (bit 8) is set
	// (tempReg reads value 8), then SDRAM registers haven't been
	// initialized yet and need to be configured.

	if (tempReg == 8)
	{
#ifdef __ADSPBF533__

		// BF533 EZ-KIT has 32 MB of SDRAM from 0x0 to 0x1ffffff

		// these are the optimum settings taken from the BF533 EZ-KIT Lite Evaluation Manual
		// assuming the 118.8 MHz SCLK we are using

		*pEBIU_SDRRC = 0x0397;		// SDRAM Refresh Rate Control Register
		*pEBIU_SDBCTL = 0x0013;		// SDRAM Memory Bank Control Register
		*pEBIU_SDGCTL = 0x0091998d;	// SDRAM Memory Global Control Register

#elif defined(__ADSPBF537__)

		// BF537 EZ-KIT has 64 MB of SDRAM from 0x0 to 0x3ffffff

		*pEBIU_SDRRC = 0x03a3;		// SDRAM Refresh Rate Control Register
		*pEBIU_SDBCTL = 0x0025;		// SDRAM Memory Bank Control Register
		*pEBIU_SDGCTL = 0x0491998d;	// SDRAM Memory Global Control Register

#elif defined(__ADSPBF561__)

		// BF561 EZ-KIT has 64 MB of SDRAM from 0x0 to 0x3ffffff

		// these are the optimum settings taken from the BF561 EZ-KIT Lite Evaluation Manual
		// assuming the 120 MHz SCLK we are using

		*pEBIU_SDBCTL = 0x00000013;		// SDRAM Memory Bank Control Register
		ssync();
		*pEBIU_SDRRC =  0x000003a0;		// SDRAM Refresh Rate Control Register
		ssync();
		*pEBIU_SDGCTL = 0x0091998d;		// SDRAM Memory Global Control Register
		ssync();

#else
#error *** Processor not supported ***
#endif
	}
}


/*********************************************************************

	Function:		ezConfigureAsync

	Description:	Initializes and sets the appropriate wait states for
					the async memories on the EZKit.

*********************************************************************/

void ezConfigureAsync(void)
{
	// *******************************************************
	// NET2272 is on async bank3, leave banks 0-2 as default
	// *******************************************************

	*pEBIU_AMBCTL0	= 0xffc2ffc2;
	*pEBIU_AMBCTL1	= 0x13d0ffc2;
	*pEBIU_AMGCTL	= 0x000f;
}


/*********************************************************************

	Function:		ezConfigureFlashA

	Description:	Sets up the A flash on the board for use.

*********************************************************************/

void ezConfigureFlashA(void)						// sets up the flash
{
#ifdef __ADSPBF533__
	*pFlashA_PortA_Out = 0;			// resets port A to initial value
	*pFlashA_PortA_Dir = 0xFF;		// configure everything on port A as outputs
	*pFlashA_PortB_Out = 0;			// resets port B to initial value
	*pFlashA_PortB_Dir = 0x3f;		// configure everything on port B as outputs
#endif
}


/*********************************************************************

	Function:		ezInitLEDFlags

	Description:	Configures the flags to drive LEDs

*********************************************************************/

void ezInitLEDFlags(void)
{
	#ifdef __ADSPBF537__
		int temp;

		// *******************************************************
		// don't touch PF6 or PF7, they are used by the NET2272!!!
		// *******************************************************

		// enable programmable flags
		temp = *pPORTF_FER;
		ssync();
		temp &= ~( /*PF6 | PF7 |*/ PF8 | PF9 | PF10 | PF11);

		*pPORTF_FER = temp;
		ssync();
		*pPORTF_FER = temp;
		ssync();

		// set the flags connected to the LEDs as output
		*pPORTFIO_DIR |= ( /*PF6 | PF7 |*/ PF8 | PF9 | PF10 | PF11);
	#endif
}


/*********************************************************************

	Function:		ezTurnOnLED

	Description:	Turns an LED on.

*********************************************************************/

void ezTurnOnLED(u32 LEDNumber)
{
#ifdef __ADSPBF533__
	switch(LEDNumber) {
		case 4:
			*pFlashA_PortB_Out |= 0x0001;
			break;
		case 5:
			*pFlashA_PortB_Out |= 0x0002;
			break;
		case 6:
			*pFlashA_PortB_Out |= 0x0004;
			break;
		case 7:
			*pFlashA_PortB_Out |= 0x0008;
			break;
		case 8:
			*pFlashA_PortB_Out |= 0x0010;
			break;
		case 9:
			*pFlashA_PortB_Out |= 0x0020;
			break;
	}
#elif defined(__ADSPBF537__)
	switch(LEDNumber) {
			case 1:
		        *pPORTFIO_SET = PF6;
				break;
			case 2:
		        *pPORTFIO_SET = PF7;
				break;
			case 3:
		        *pPORTFIO_SET = PF8;
				break;
			case 4:
		        *pPORTFIO_SET = PF9;
				break;
			case 5:
		        *pPORTFIO_SET = PF10;
				break;
			case 6:
		        *pPORTFIO_SET = PF11;
				break;
	}
#endif
}



/*********************************************************************

	Function:		ezTurnOffLED

	Description:	Turns an LED off.

*********************************************************************/

void ezTurnOffLED(u32 LEDNumber)
{
#ifdef __ADSPBF533__
	switch(LEDNumber) {
		case 4:
			*pFlashA_PortB_Out &= ~0x0001;
			break;
		case 5:
			*pFlashA_PortB_Out &= ~0x0002;
			break;
		case 6:
			*pFlashA_PortB_Out &= ~0x0004;
			break;
		case 7:
			*pFlashA_PortB_Out &= ~0x0008;
			break;
		case 8:
			*pFlashA_PortB_Out &= ~0x0010;
			break;
		case 9:
			*pFlashA_PortB_Out &= ~0x0020;
			break;
	}
#elif defined(__ADSPBF537__)
	switch(LEDNumber) {
		case 1:
			*pPORTFIO_CLEAR = PF6;
			break;
		case 2:
			*pPORTFIO_CLEAR = PF7;
			break;
		case 3:
			*pPORTFIO_CLEAR = PF8;
			break;
		case 4:
			*pPORTFIO_CLEAR = PF9;
			break;
		case 5:
			*pPORTFIO_CLEAR = PF10;
			break;
		case 6:
			*pPORTFIO_CLEAR = PF11;
			break;
	}
#endif
}


/*********************************************************************

	Function:		ezToggleLED

	Description:	Toggles the state of an LED.

*********************************************************************/

void ezToggleLED(u32 LEDNumber)
{
	if (ezIsLEDOn(LEDNumber)) {
		ezTurnOffLED(LEDNumber);
	} else {
		ezTurnOnLED(LEDNumber);
	}
}




/*********************************************************************

	Function:		ezTurnOnAllLEDs

	Description:	Turns on all LEDs.

*********************************************************************/

void ezTurnOnAllLEDs(void)
{
#ifdef __ADSPBF533__
	*pFlashA_PortB_Out = 0x3f;
#elif defined(__ADSPBF537__)
	// *******************************************************
	// don't touch PF6 or PF7, they are used by the NET2272!!!
	// *******************************************************
	*pPORTFIO_SET = ( /*PF6 | PF7 |*/ PF8 | PF9 | PF10 | PF11);
#endif
}


/*********************************************************************

	Function:		ezTurnOffAllLEDs

	Description:	Turns off all LEDs.

*********************************************************************/

void ezTurnOffAllLEDs(void)
{
#ifdef __ADSPBF533__
	*pFlashA_PortB_Out = 0x0;
#elif defined(__ADSPBF537__)
	// *******************************************************
	// don't touch PF6 or PF7, they are used by the NET2272!!!
	// *******************************************************
	*pPORTFIO_CLEAR = ( /*PF6 | PF7 |*/ PF8 | PF9 | PF10 | PF11);
#endif
}



/*********************************************************************

	Function:		ezCycleLEDs

	Description:	Cycles through each LED in turn.

*********************************************************************/

void ezCycleLEDs(void)
{
#ifdef __ADSPBF533__
	static int LED = 4;
	ezTurnOffLED(LED);
	LED++;
	if (LED > 9) LED = 4;
	ezTurnOnLED(LED);
#elif defined(__ADSPBF537__)
	static int LED = 1;
	ezTurnOffLED(LED);
	LED++;
	if (LED > 6) LED = 4;
	ezTurnOnLED(LED);
#endif
}




/*********************************************************************

	Function:		ezIsLEDOn

	Description:	Returns TRUE if an LED is lit, FALSE otherwise.

*********************************************************************/

u32 ezIsLEDOn(u32 LEDNumber)
{
#ifdef __ADSPBF533__
	switch(LEDNumber) {
		case 4:
			if (*pFlashA_PortB_In & 0x0001) return (TRUE);
			break;
		case 5:
			if (*pFlashA_PortB_In & 0x0002) return (TRUE);
			break;
		case 6:
			if (*pFlashA_PortB_In & 0x0004) return (TRUE);
			break;
		case 7:
			if (*pFlashA_PortB_In & 0x0008) return (TRUE);
			break;
		case 8:
			if (*pFlashA_PortB_In & 0x0010) return (TRUE);
			break;
		case 9:
			if (*pFlashA_PortB_In & 0x0020) return (TRUE);
			break;
	}
	return (FALSE);
#elif defined(__ADSPBF537__)
	switch(LEDNumber) {
		case 1:
			if (*pPORTFIO & PF6) return (TRUE);
			break;
		case 2:
			if (*pPORTFIO & PF7) return (TRUE);
			break;
		case 3:
			if (*pPORTFIO & PF8) return (TRUE);
			break;
		case 4:
			if (*pPORTFIO & PF9) return (TRUE);
			break;
		case 5:
			if (*pPORTFIO & PF10) return (TRUE);
			break;
		case 6:
			if (*pPORTFIO & PF11) return (TRUE);
			break;
	}
	return (FALSE);
#else
	return (FALSE);
#endif
}


/*********************************************************************

	Function:		ezErrorCheck

	Description:	This function is intended to be used as a means to
					quickly determine if a function has returned a non-zero
					(hence an error) return code.  All driver and system
					services functions return a value of zero for success and
					a non-zero value when a failure occurs.  This function
					lights all the LEDs and spins when a non-zero value is
					passed to it.

*********************************************************************/

void ezErrorCheck(u32 Result)
{
	while (Result != 0) {
		ezTurnOnAllLEDs();
	}
}


/*********************************************************************

	Function:		ezInitButtons

	Description:	Initializes the push button as input flags

*********************************************************************/

void ezInitButtons(void)
{
#ifdef __ADSPBF533__
	*pFIO_INEN		= 0x0f00;		// enable flags as inputs
	*pFIO_DIR		= 0x0000;		// set the flag direction as input
	*pFIO_EDGE		= 0x0f00;		// set to edge sensitive (when enabled)
#elif defined(__ADSPBF537__)
	int temp;

	// enable programmable flags
	temp = *pPORTF_FER;
	ssync();
	temp &= ~(PF2 | PF3 | PF8 | PF5 | PF6 | PF7);

	*pPORTF_FER = temp;
	ssync();
	*pPORTF_FER = temp;
	ssync();

	// *******************************************************
	// don't touch PF6 or PF7, they are used by the NET2272!!!
	// *******************************************************

	// set the flags connected to the LEDs as output
	*pPORTFIO_DIR &= ~(PF2 | PF3 | PF8 | PF5 /*| PF6 | PF7*/);

	// enable flags as inputs
	*pPORTFIO_INEN |= (PF2 | PF3 | PF8 | PF5 /*| PF6 | PF7*/);

	// set to edge sensitive (when enabled)
	*pPORTFIO_EDGE |= (PF2 | PF3 | PF8 | PF5 /*| PF6 | PF7*/);
#endif
}




/*********************************************************************

	Function:		ezIsButtonPushed

	Description:	Returns TRUE if a button has been pushed, FALSE otherwise.

*********************************************************************/

u32 ezIsButtonPushed(u32 ButtonNumber)
{
#ifdef __ADSPBF533__
	switch (ButtonNumber) {
		case 4:
			if (*pFIO_FLAG_D & 0x0100) return (TRUE);
			break;
		case 5:
			if (*pFIO_FLAG_D & 0x0200) return (TRUE);
			break;
		case 6:
			if (*pFIO_FLAG_D & 0x0400) return (TRUE);
			break;
		case 7:
			if (*pFIO_FLAG_D & 0x0800) return (TRUE);
			break;
	}
#elif defined(__ADSPBF537__)
	switch (ButtonNumber) {
		case 1:
			if (*pPORTFIO & PF2) return (TRUE);
			break;
		case 2:
			if (*pPORTFIO & PF3) return (TRUE);
			break;
		case 3:
			if (*pPORTFIO & PF4) return (TRUE);
			break;
		case 4:
			if (*pPORTFIO & PF5) return (TRUE);
			break;
	}
#endif
	return (FALSE);
}


/*********************************************************************

	Function:		ezEnableButtonInterrupt

	Description:	Enables generation of an interrupt in response to
					a button being pushed.

*********************************************************************/

void ezEnableButtonInterrupt (u32 ButtonNumber)
{
#ifdef __ADSPBF533__
	switch (ButtonNumber) {
		case 4:
			*pFIO_MASKA_S = 0x0100;
			break;
		case 5:
			*pFIO_MASKA_S = 0x0200;
			break;
		case 6:
			*pFIO_MASKA_S = 0x0400;
			break;
		case 7:
			*pFIO_MASKA_S = 0x0800;
			break;
	}
#elif defined(__ADSPBF537__)
	switch (ButtonNumber) {
		case 1:
			*pPORTFIO_MASKA_SET = PF2;
			break;
		case 2:
			*pPORTFIO_MASKA_SET = PF3;
			break;
		case 3:
			*pPORTFIO_MASKA_SET = PF4;
			break;
		case 4:
			*pPORTFIO_MASKA_SET = PF5;
			break;
	}
#endif
}



/*********************************************************************

	Function:		ezDisableButtonInterrupt

	Description:	Disables generation of an interrupt in response to
					a button being pushed.

*********************************************************************/

void ezDisableButtonInterrupt (u32 ButtonNumber)
{
#ifdef __ADSPBF533__
	switch (ButtonNumber) {
		case 4:
			*pFIO_MASKA_C = 0x0100;
			break;
		case 5:
			*pFIO_MASKA_C = 0x0200;
			break;
		case 6:
			*pFIO_MASKA_C = 0x0400;
			break;
		case 7:
			*pFIO_MASKA_C = 0x0800;
			break;
	}
#elif defined(__ADSPBF537__)
	switch (ButtonNumber) {
		case 1:
			*pPORTFIO_MASKA_CLEAR = PF2;
			break;
		case 2:
			*pPORTFIO_MASKA_CLEAR = PF3;
			break;
		case 3:
			*pPORTFIO_MASKA_CLEAR = PF4;
			break;
		case 4:
			*pPORTFIO_MASKA_CLEAR = PF5;
			break;
	}
#endif
}




/*********************************************************************

	Function:		ezClearButton

	Description:	Clears a push button latch.  This must be called to
					reset the latch for the push button, if a button has
					been pressed.

*********************************************************************/

void ezClearButton(u32 ButtonNumber)
{
#ifdef __ADSPBF533__
	switch (ButtonNumber) {
		case 4:
			*pFIO_FLAG_C = 0x0100;
			break;
		case 5:
			*pFIO_FLAG_C = 0x0200;
			break;
		case 6:
			*pFIO_FLAG_C = 0x0400;
			break;
		case 7:
			*pFIO_FLAG_C = 0x0800;
			break;
	}
#elif defined(__ADSPBF537__)
	switch (ButtonNumber) {
		case 1:
			*pPORTFIO_CLEAR = PF2;
			break;
		case 2:
			*pPORTFIO_CLEAR = PF3;
			break;
		case 3:
			*pPORTFIO_CLEAR = PF4;
			break;
		case 4:
			*pPORTFIO_CLEAR = PF5;
			break;
	}
#endif
}




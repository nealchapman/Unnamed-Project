/*********************************************************************************

Copyright(c) 2005 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.

*********************************************************************************/

#include <services/services.h>											// system service includes
#include <drivers/adi_dev.h>											// device manager includes
#include <..\..\..\..\..\Examples\usb\host\windows\hostapp\hostapp.h>	// hostapp definitions

static ADI_DEV_1D_BUFFER UsbcbBuffer;	// one-dimensional buffer for processing usbcb
static ADI_DEV_1D_BUFFER DataBuffer;	// one-dimensional buffer for processing data
static USBCB usbcb;						// USB command block

#pragma align 4
section ("sdram0")
char USBLoopbackBuffer[MAX_DATA_BYTES_BULKADI];	// loopback buffer in SDRAM

// wrapper prototypes
u32 usb_Read(	ADI_DEV_DEVICE_HANDLE DeviceHandle, ADI_DEV_BUFFER_TYPE BufferType,
				ADI_DEV_BUFFER *pBuffer, bool bWaitForCompletion);
u32 usb_Write(	ADI_DEV_DEVICE_HANDLE DeviceHandle, ADI_DEV_BUFFER_TYPE BufferType,
				ADI_DEV_BUFFER *pBuffer, bool bWaitForCompletion);


/******************************************************************************
Routine Description:

    Performs a loopback by receiving data from the host and sending it back.

Arguments:

	ADI_DEV_DEVICE_HANDLE devhandle -	device handle
	u32 u32Count -						number of bytes to loop first time

Return Value:

    unsigned int - return status

******************************************************************************/

unsigned int Loopback(ADI_DEV_DEVICE_HANDLE devhandle, u32 u32Count)
{
	unsigned int Result;
	u32 KeepRunning = 0x1;				// keep running loopback flag
	u32 NextCount = 0;					// count for next transfer

	DataBuffer.Data = USBLoopbackBuffer;
	DataBuffer.ElementCount = u32Count;
	DataBuffer.ElementWidth = 1;
	DataBuffer.CallbackParameter = USBLoopbackBuffer;
	DataBuffer.pNext = NULL;

	while (KeepRunning)
	{
		// wait for data from the host (pass in TRUE)
		Result = usb_Read(devhandle, ADI_DEV_1D, (ADI_DEV_BUFFER *)&DataBuffer, TRUE);

		if ( ADI_DEV_RESULT_SUCCESS != Result )
			return Result;

		// process received data here...for loopback we just check the header info

		// send the host the data
		Result = usb_Write(devhandle, ADI_DEV_1D, (ADI_DEV_BUFFER *)&DataBuffer, FALSE);

		if ( ADI_DEV_RESULT_SUCCESS != Result )
			return Result;

		// find out what the next transfer size will be, mask off the upper byte (stop flag)
		NextCount = *(u32*)(DataBuffer.Data);
		NextCount &= 0x00ffffff;

		// upper byte indicates if this is our last transfer (host wants to end loopback)
		KeepRunning = *(u32*)(DataBuffer.Data);
		KeepRunning &= 0xff000000;

		// update count for next loop
		DataBuffer.ElementCount = NextCount;
	}

	return Result;
}


/******************************************************************************
Routine Description:

    Reads data from Blackfin memory and sends it back to the host.

Arguments:

	ADI_DEV_DEVICE_HANDLE dh -	device handle
	u8 *p8Address -				Blackfin address to read from
	u32 u32Count -				number of bytes to read

Return Value:

    unsigned int - return status

******************************************************************************/

unsigned int ReadMemory( ADI_DEV_DEVICE_HANDLE devhandle, u8 *p8Address, u32 u32Count )
{
	DataBuffer.Data = p8Address;
	DataBuffer.ElementCount = u32Count;
	DataBuffer.ElementWidth = 1;
	DataBuffer.CallbackParameter = NULL;
	DataBuffer.ProcessedFlag = FALSE;
	DataBuffer.ProcessedElementCount = 0;
	DataBuffer.pNext = NULL;

	// send the data back to the host
	return usb_Write(devhandle, ADI_DEV_1D, (ADI_DEV_BUFFER *)&DataBuffer, FALSE);
}


/******************************************************************************
Routine Description:

    Receives data from the host and writes it to Blackfin memory.

Arguments:

	ADI_DEV_DEVICE_HANDLE dh -	device handle
	u8 *p8Address -				Blackfin address to write to
	u32 u32Count -				number of bytes to write

Return Value:

    unsigned int - return status

******************************************************************************/

unsigned int WriteMemory( ADI_DEV_DEVICE_HANDLE devhandle, u8 *p8Address, u32 u32Count )
{
	DataBuffer.Data = p8Address;
	DataBuffer.ElementCount = u32Count;
	DataBuffer.ElementWidth = 1;
	DataBuffer.CallbackParameter = NULL;
	DataBuffer.ProcessedFlag = FALSE;
	DataBuffer.ProcessedElementCount = 0;
	DataBuffer.pNext = NULL;

	// get the data from the host
	return usb_Read(devhandle, ADI_DEV_1D, (ADI_DEV_BUFFER *)&DataBuffer, FALSE);
}


/******************************************************************************
Routine Description:

    Checks to see if a command is supported by this firmware.  The host can use
    this to verify that a command it wants to execute is supported ahead of time.

Arguments:

	ADI_DEV_DEVICE_HANDLE dh -	device handle
	u32 u32Command -			command we are querying on

Return Value:

    unsigned int - return status

******************************************************************************/

unsigned int QuerySupport( ADI_DEV_DEVICE_HANDLE devhandle, u32 u32Command )
{
	int Result;			// result

	// init buffer
	UsbcbBuffer.Data = &usbcb;
	UsbcbBuffer.ElementCount = sizeof(usbcb);
	UsbcbBuffer.ElementWidth = 1;
	UsbcbBuffer.CallbackParameter = NULL;
	UsbcbBuffer.pNext = NULL;

	// check for a supported command
	if (QUERY_SUPPORT == u32Command || GET_FW_VERSION == u32Command ||
		LOOPBACK == u32Command || MEMORY_READ == u32Command ||
		MEMORY_WRITE == u32Command )
		usbcb.u32_Data = TRUE;
	else
		usbcb.u32_Data = FALSE;

	// send a USBCB to the host with the result
	usbcb.u32_Count = 0x0;
	usbcb.u32_Command = QUERY_REPLY;
	Result = usb_Write(devhandle, ADI_DEV_1D, (ADI_DEV_BUFFER *)&UsbcbBuffer, FALSE);

	// return success
	return Result;
}


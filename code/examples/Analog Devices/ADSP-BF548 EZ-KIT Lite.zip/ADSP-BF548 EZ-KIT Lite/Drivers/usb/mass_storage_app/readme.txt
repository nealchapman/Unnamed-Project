"ADSP-BF548 EZ-KIT Lite USB Mass Storage Device Demo"

Date Created: 07/10/07 

This directory contains an example ADSP-BF548 Project which demonstrates how to create 
and run the BF548 USB Mass Storage Device example. 

All the examples ship pre-built but you can rebuild them yourself.The source 
files are included in the directory structure shown below:

+---Blackfin
    +---Examples
    �   +---ADSP-BF548 EZ-KIT Lite
    �       +---Drivers 	
    �           +---USB 	
    �               +---mass_storage_app    
    �		        adi_ssl_init.c
    �		        adi_ssl_init.h
    �		        formatted_8MB.h
    �		        mass_storage_app.c
    |			mass_storage_app_bf548.dpj			
    |                   Readme.txt	

__________________________________________________________

	
CONTENTS

I.    Overview
II.   Hardware Requirements and Setup
III.  Using the Blackfin USB 2.0 Connection
IV.   Using the Mass Storage Device Example


I. Overview

Support is included for USB 2.0 Mass Storage Device transfers between a Windows host PC and the
BF548 EZ-KIT.All the source code for the utilities and firmware are also included.  

II. Hardware Requirements and Setup

The requirements of the USB software are as follows:

* BF548 EZ-KIT Lite
* Windows 2000, Windows XP or Vista operating system
* PC with available USB port

We recommend using a host PC with a built-in USB 2.0 controller otherwise
performance will be greatly reduced.  Even USB 2.0 plug-in controllers will show a
decrease in performance compared to systems with built-in USB 2.0 controllers.

Please also note that using other USB devices simultaneously may slow down the
performance of the BF548 EZ-KIT Example.  Simple input devices such as keyboards and
mice should not cause a problem, but for example using the USB Debug Agent connection
on the EZ-KIT may decrease the performance of both applications.  Shutting down
VisualDSP++ after loading the firmware will allow to operate as fast as possible if 
you are also using the USB Debug Agent connection.

   
III. Using the Blackfin USB 2.0 Connection

1. Be sure you have read both the User's Guide and "Hardware Requirements and Setup"
   section of this file and followed their instructions.
2. Connect to your target board with VisualDSP++.  If you need help configuring
   VisualDSP++ please refer to your VisualDSP++ documentation.
3. Select the "File->Load Program" menu and load the example application (.dxe).
4. Select the "Settings->Target Options" menu in order to change the "On Emulator
   Exit" option to "Run from current PC".  Otherwise if have the option set to
   "Stall the DSP" and close down VisualDSP++ it will stall the Blackfin and any
   subsequent USB operation will fail.
5. Select the "Debug->Run" menu to start executing the Blackfin firmware.
6. Connect a USB cable from the host PC to the BF548 EZ-Kit USB connector.
7. The first time you run the firmware on a PC, Windows should detect a new USB device
   and start up the New Hardware Wizard.
8. Once the device is enumerated by the PC a new disk drive should appear in device 
   manager.  
10.Your BF548 EZ-KIT is now ready to communicate with a host.

Remember that if you want to shut down VisualDSP++ after loading the firmare, be sure
to change the "Settings->Target Options->On Emulator Exit" menu option to "Run from
current PC" otherwise VisualDSP++ will stall the processor on exit and USB
communication will not be functional.


IV. Using the Mass Storage Device Example

The Mass Storage Device example allows the user to access the Hard Disk on the
ADSP-BF548 EZ-KIT Lite.  This drive should appear in device manager and can be
accessed like any other drive connected to the PC. If while trying to access the
drive a windows message appears saying the drive is not formatted.  Right click
on the drive and select format. Once the drive is fromatted you should be able 
to access it from the PC.	  


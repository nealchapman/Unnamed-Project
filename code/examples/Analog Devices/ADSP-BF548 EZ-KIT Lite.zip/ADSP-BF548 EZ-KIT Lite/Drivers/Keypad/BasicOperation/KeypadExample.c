/**********************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software 
you agree to the terms of the associated Analog Devices License Agreement.  

$RCSfile: KeypadExample.c,v $
$Revision: 1.2 $
$Date: 2007/05/15 02:54:30 $

Description:
	This is an example program for Keypad driver

	Refer to associated text file for project information

******************************************************************************

Include files

*****************************************************************************/

#include <services/services.h>		    /* system service includes  */
#include <drivers/adi_dev.h>		    /* device manager includes  */
#include <drivers/keypad/adi_kpad.h>    /* Keypad driver includes   */
#include "adi_ssl_init.h"		    	/* system services init		*/	
#include <stdio.h>

/*****************************************************************************

Processor specific Macros

*****************************************************************************/

/* Use Pushbutton 4 (PB4) to terminate this program */
#define     TERMINATE_BUTTON        	ADI_FLAG_PB11

/*****************************************************************************

Static data

*****************************************************************************/
/* handle to the driver*/
static ADI_DEV_DEVICE_HANDLE KeypadDriverHandle;
	
/* DCB Managed Data */
static u8 DCBMgrData[ADI_DCB_QUEUE_SIZE + (ADI_DCB_ENTRY_SIZE)*4];
/* handle to the callback service */
static ADI_DCB_HANDLE DCBManagerHandle;

/* Lookup table for the Keypad */
u8 KeyTable[4][4] = 
{
     {  'E','H','0','C'}, 		/* 'ENTER'	, 'HELP' , '0' , 'CLEAR'	*/
     {  'S','9','8','7'}, 		/* '2ND'	, '9'	 , '8' , '7'		*/
     {  'D','6','5','4'}, 		/* 'DOWN'	, '6'	 , '5' , '4'		*/
     {  'U','3','2','1'},       /* 'UP'		, '3'	 , '2' , '1'		*/
};

/*****************************************************************************

Local function prototype

*****************************************************************************/

void MapKey (
	u8 		mode,		/* Keypress mode (single/multiple key press)	*/
	u16 	keycode		/* Rows/Columns pressed							*/
);

/*****************************************************************************

	Function:		ExceptionHandler
					HWErrorHandler

	Description:	We should never get an exception or hardware error,
					but just in case - display an error message 
					
*****************************************************************************/

static ADI_INT_HANDLER(ExceptionHandler)	        /* exception handler        */
{
	printf("Exception!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

static ADI_INT_HANDLER(HWErrorHandler)		        /* hardware error handler   */
{
	printf("HWerror!\n");
	return(ADI_INT_RESULT_PROCESSED);
}

/*****************************************************************************

	Function:		ClientCallback

*****************************************************************************/
static void ClientCallback(
	void *AppHandle,
	u32  Event,
	void *pArg
){

    /* pointer to the key pressed result buffer*/
    ADI_KPAD_KEY_PRESSED_RESULT *pResult;	
	
	/* CASEOF (Event id) */
    switch (Event)
	{
		/* CASE (Key pressed)*/
		case ADI_KPAD_EVENT_KEYPRESSED:
		/* get the address of key pressed results buffer */
		pResult = (ADI_KPAD_KEY_PRESSED_RESULT *)pArg;
		/* Map this key press to the lookup table */
		MapKey(pResult->mrowcol,pResult->rowcolpos);		
		break;
	}

	/* return*/
}

/*****************************************************************************

	Function:		MapKey
	
	Description:    Maps key(s) pressed to the Keypad lookup table

*****************************************************************************/

void MapKey(u8 mode,u16 keycode)
{
    
    u8 Col, Row;
     
    /* IF (single key pressed) */
    if (mode == 1) 
    {     
        /*get the column position*/
        Col = (u8)((keycode & 0x0f00) >> 9);
        if(Col > 3) 
        {
            Col = 3;    /* column limit */
        }
    
        /*get the row position*/
        Row = (u8)((keycode & 0x000f) >> 1);
 	    if(Row > 3)
 	    {
 	        Row = 3;    /* row limit */
 	    }
        printf("'%c' key pressed\n", KeyTable[Col][Row]);
    }
    /* ELSE IF (Multiple keys pressed) */
    else if (mode == 2)
    {
        printf("Keys ");
        
        /* get the column id */
 	    Col = (u8)((keycode & 0x0f00) >> 8);
 	    
	    /* IF (single column pressed?) */
        if((Col == 1)||(Col == 2)||(Col == 4)||(Col == 8))
        { 
            Col = Col >> 1;   
            if(Col > 3)
            {
                Col = 3;    /* column limit */
            }
           
            /* get the multiple key from the row*/
            Row = (u8)(keycode & 0x000f);
           
            if(Row & 0x8)
            {
     	        printf("'%c'  ", KeyTable[Col][3]);
            }
           
            if(Row & 0x4)
     	    {
     	        printf("'%c'  ", KeyTable[Col][2]);
            }
           
     	    if(Row & 0x2)
     	    {
     	        printf("'%c'  ", KeyTable[Col][1]);
            }
           
     	    if(Row & 0x1)
     	    {
     	        printf("'%c'  ", KeyTable[Col][0]);
            }
        }
        /* ELSE (multiple columns pressed) */
        else 
		{
            /*get the row position*/
     		Row = (u8)((keycode & 0x000f) >> 1);
 	 		if(Row > 3)
 	 		{
 	 		    Row = 3;    /* Row limit */
            }
   
		    /* get the multiple key from the column*/
     		Col = (u8)((keycode & 0x0f00) >> 8);
   
            if(Col & 0x8)
            {
     	        printf("'%c'  ", KeyTable[3][Row]);
            }
     	    if(Col & 0x4)
     	    {
     	        printf("'%c'  ", KeyTable[2][Row]);
            }
     	    if(Col & 0x2)
     	    {
     	        printf("'%c'  ", KeyTable[1][Row]);
            }
     	    if(Col & 0x1)
     	    {
     	        printf("'%c'  ", KeyTable[0][Row]);
            }
        }
        printf("pressed\n");	
    } 
    /* ELSE (multiple key in different row/column pressed) */
    else if (mode == 3)
    {
        printf("Invalid key pressed\n");
    }   
}

/*****************************************************************************
*
*	Function:	main
*
*****************************************************************************/
void main(void)
{
	u32 Result;
	u32	ResponseCount;
	u32 Sense;

	printf ("Keypad - Basic operation example for ADSP-BF548 Ez-Kit Lite \n");
	
    /* configure system - terminate configuration process on error */
    do
    {
        	
        /**************** Initialise System Services ****************/
    
        if ((Result = adi_ssl_Init()) != 0)
        {
    	    printf("Initialising System Services Failed! Error code: 0x%08X\n",Result);
    	    break;
        }

        /* hook the exception interrupt*/
	    if((Result = adi_int_CECHook(3, ExceptionHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook exception handler, Error Code: 0x%08X\n",Result);
		    break;
        }
        
        /* hook the hardware error*/
	    if((Result = adi_int_CECHook(5, HWErrorHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
	    {
	        printf("Failed to hook hardware error handler, Error Code: 0x%08X\n",Result);
		    break;
        }

/* if DCB selected, open the DCB manager & setup a queue */
#if defined(USE_DEFERRED_CALLBACKS)
	    if((Result = adi_dcb_Open(14, &DCBMgrData[ADI_DCB_QUEUE_SIZE], 
	                              (ADI_DCB_ENTRY_SIZE)*4, &ResponseCount, &DCBManagerHandle))!=0)
	    {
		    printf("adi_dcb_Open failed, Error Code: 0x%08X\n",Result);
		    break;
	    }
#else	/* else, live callback */
        DCBManagerHandle = NULL;
#endif

        /* Initialise the Pushbutton that is to be used to terminate this program */
        /* Open the Flag pin connected to the Terminate pushbutton */
        if((Result = adi_flag_Open(TERMINATE_BUTTON)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to open Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }
        
        /* Set this flag as Input */
        if((Result = adi_flag_SetDirection(TERMINATE_BUTTON,ADI_FLAG_DIRECTION_INPUT)) != ADI_FLAG_RESULT_SUCCESS)
        {
            printf("Failed to configure Flag pin connected to Terimate pushbutton , Error Code: 0x%08X\n",Result);
            break;
        }

        /************** Open Keypad driver ***************/
    
        if((Result = adi_dev_Open(  adi_dev_ManagerHandle,     		/* Dev manager Handle               */
                     	            &ADIKPADEntryPoint,             /* Device Entry point               */
                                    0,                              /* Device number                    */
	                                NULL,                           /* No client handle                 */
    	                            &KeypadDriverHandle,	        /* DevMgr handle for this device    */
				                    ADI_DEV_DIRECTION_UNDEFINED,    /* data direction not used          */
            	                    NULL,         	                /* Handle to DMA Manager            */
                	                DCBManagerHandle,               /* Handle to callback manager       */
                        	        ClientCallback))		        /* Callback Function                */
	                	!= ADI_DEV_RESULT_SUCCESS) 
        {
         	printf("Open Keypad driver Failed!, Error Code: 0x%08X\n",Result);
         	break;
        }

	    /******************************************************************
	     Keypad driver default configuration:
	     
	        4 rows and 4 columns enabled.(4x4 matrix)
	        Interrupt mode: single and multiple key press interrupt.
	        Kpad-Prescale sets to 0.1ms time base
	        De-bounce and column drive delay set to 1 ms
	    ******************************************************************/
	
        /************ Keypad driver Configuration table ************/
        ADI_DEV_CMD_VALUE_PAIR  KeypadConfig[]=
        {
            { ADI_KPAD_CMD_SET_ROW_NUMBER,      (void *)3                       },  /* Enable Row 0-3                               */
            { ADI_KPAD_CMD_SET_COLUMN_NUMBER,   (void *)3                       },  /* Enable Column 0-3                            */
            { ADI_KPAD_CMD_SET_IRQMODE,         (void *)2                       },  /* Enable single & multiple key press interrupt */
            { ADI_KPAD_CMD_SET_DBON_COLDRV_TIME,(void *)8                       },  /* Set de-bounce time delay as 8ms              */
            { ADI_DEV_CMD_END,					NULL                            }   /* Terminate config table                                   */
	    };

        /**************** Configure Keypad controller registers ****************/
        if((Result = adi_dev_Control(KeypadDriverHandle, ADI_DEV_CMD_TABLE, (void *)KeypadConfig))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to configure Kepad controller registers, Error Code: 0x%08X\n",Result);
		    break;
        }

        /**************** Enable Keypad ****************/
        if((Result = adi_dev_Control(KeypadDriverHandle, ADI_KPAD_CMD_SET_KPAD_ENABLE, (void *)TRUE))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to enable Keypad, Error Code: 0x%08X\n",Result);
		    break;
        }
        
    } while(0);
	
	/* IF (Keypad configuration results in success) */
  	if (Result == ADI_DEV_RESULT_SUCCESS)
    {
        printf("Keypad is up and running...\n");
        printf("Press Pushbutton 4 (PB4) to terminate this program\n");
        /* wait for Keypad activity until user presses terminate button */
        while ((Result = adi_flag_Sense(TERMINATE_BUTTON, &Sense)) == ADI_DEV_RESULT_SUCCESS)
        {
            /* IF (Terminate button pressed) */
            if(Sense)
            {
                break;
            }
        }
  
        /* Disable the Keyapd device */
        if((Result = adi_dev_Control(KeypadDriverHandle, ADI_KPAD_CMD_SET_KPAD_ENABLE, (void *)FALSE))!= ADI_DEV_RESULT_SUCCESS)
        {
		    printf("Failed to disable Keypad, Error Code: 0x%08X\n",Result);
        }
        
    	/* close Rotary counter driver */
    	if((Result = adi_dev_Close(KeypadDriverHandle)) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to close Keypad controller, Error Code: 0x%08X\n",Result);
    	}

    	/* Terminate system services */
    	if((Result = adi_ssl_Terminate()) != ADI_DEV_RESULT_SUCCESS)
    	{
        	printf("Failed to terminate system services, Error Code: 0x%08X\n",Result);
    	}    
	}
	else
	{
		printf("Program terminated abnormally with error code: 0x%08X\n",Result);
	}
	printf ("Done!\n");
}

/*****/



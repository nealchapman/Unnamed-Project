Project Name: KeypadExample.dpj

Description: Example program for Keypad driver
    
Project Type:
=============
    ADSP-BF533 [ ]
    ADSP-BF537 [ ]
    ADSP-BF548 [X]
    ADSP-BF561 [ ]

Hardware/Tools Used:
====================
    ADSP-BF548 EZ-Kit Lite Rev 1.1
    Analog Devices VisualDSP++ 5.0
    ADDS HPUSB-ICE
    
System Services Components Used:
================================
    DMA Manager                         [X]   Deferred Callback Manager   [X]
    Interrupt Manager                   [X]   Timer Module                [ ]
    Power Management Module             [X]   Flag Module                 [ ]
    External Bus Interface Unit Module  [X]   Port Module                 [X]

Overview:
=========

    The program configures Keypad controller in following mode
        - Enable rows 0 to 3
        - Enable columns 0 to 3
        - Enable Single and Multiple key press mode
        - Key debounce delay as 8ms

    When one or more key(s) pressed, the keypad driver posts a callback with specific event code and 
    keypress result (key press mode and row/column position(s)) as callback argument. 
    The callback function in this example decodes the keypress result and displays 
    a character corresponding to the key(s) pressed. 
       
    Key pressed     Display character
        0               '0'
        1               '1'
        2               '2'
        3               '3'
        4               '4'
        5               '5'
        6               '6'
        7               '7'
        8               '8'
        9               '9'
        2ND             'S'
        ENTER           'E'
        HELP            'H'
        CLEAR           'C'

    Supported Key press modes:
        - Single key press
        - Multiple key press (provided the keys pressed are in the same row or column)

    The program can be terminated by pressing Pushbutton 4 (PB4) on the Ez-Kit
    
    This example targets ADSP-BF548 and tested on ADSP-BF548 Ez-Kit lite rev 1.1
    
Protocols used:
---------------
    None
    
ADI Drivers and Services used:
------------------------------
    services.h          - system services
    adi_dev.h           - Device manager
    adi_kpad.h          - Keypad driver
            
Dataflow:
---------
    None
    
User Configuration Macros:
==========================
    None
    
Hardware Setup:
===============

	ADSP-BF548 Ez-Kit Lite Settings:
    --------------------------------
	All switches to default position
	Then, 
	SW2:  1(ON), 2(ON), 3(ON), 4(ON), 5(ON), 6(ON), 7(ON), 8(ON)

References:
===========
    ADSP-BF548 Hardware reference
    ADSP-BF548 EZ-Kit Lite Schematic
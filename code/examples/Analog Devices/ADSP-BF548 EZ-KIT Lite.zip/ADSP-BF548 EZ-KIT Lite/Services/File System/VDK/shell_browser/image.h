/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.

Description:
            Header file for image viewing module
*********************************************************************************/
#ifndef __IMAGE_H__
#define __IMAGE_H__

#ifdef __cplusplus
extern "C"
{
#endif

void ConfigureViewer( char *CWD, u32 RepeatCount, u32 TransitionDelay );
void ViewImages(char *name);

#ifdef __cplusplus
}
#endif

#endif /* __IMAGE_H__ */

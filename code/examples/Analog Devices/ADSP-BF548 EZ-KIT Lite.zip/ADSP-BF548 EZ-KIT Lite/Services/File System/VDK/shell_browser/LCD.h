/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.
*********************************************************************************/

#ifndef _LCD_H_
#define _LCD_H_

#ifdef __cplusplus
extern "C"
{
#endif

u32 InitLCD( void );
void TerminateLCD(void);
u32 DisplayBMP( char* filepath );

#ifdef __cplusplus
}
#endif

#endif /* _LCD_H_ */


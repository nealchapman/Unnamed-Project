/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.  

Description:
				Initializatoion of the File System Service.
				
*********************************************************************************/
#include <services/services.h> 
#include <stdio.h>

/*******************************************************************
* Device Driver headers
*   Add all relevant headers
*******************************************************************/

/* FAT12/16/32 FSD driver */
#define _ADI_FAT_DEFAULT_DEF_
#include <drivers/fsd/fat/adi_fat.h>

/* ATAPI interface */
#define _ADI_ATAPI_DEFAULT_DEF_
#include <drivers/pid/atapi/adi_atapi.h>

/* SDH interface */
#define _ADI_SDH_DEFAULT_DEF_
#include <drivers/pid/sdh/adi_sdh.h>

/*******************************************************************
 Custom memory interface.
 (comment out the following line to prevent their use
*******************************************************************/
#define _DEBUG_ALLOC_
/* Personalized Memory Allocation Routines */
#if defined(_DEBUG_ALLOC_)
#include "adi_dbgmem.h"
#endif

/* DMA and Device Manager Handles */
#include "adi_ssl_init.h"
#include <heapinfo.h>

/* DCB queue handle */
extern ADI_DCB_HANDLE adi_dcb_QueueHandle;                    

/*********************************************************************
*	Function:		InitFileSystem
*	Description:	Intializes the file system service.
*********************************************************************/
void InitFileSystem(void) 
{
    /*******************************************************************
    * Customized heaps for General and driver DMA buffers 
    *******************************************************************/
	int GeneralHeapID   = heap_lookup(1);
	
    /*******************************************************************
    * Configuration table to initialize the FSS
    *******************************************************************/
    ADI_FSS_CMD_VALUE_PAIR adi_fss_Config[] = {
        
#if defined(_DEBUG_ALLOC_)
        { ADI_FSS_CMD_SET_MALLOC_FUNC,      (void*)_adi_dbg_malloc },
        { ADI_FSS_CMD_SET_REALLOC_FUNC,     (void*)_adi_dbg_realloc },
        { ADI_FSS_CMD_SET_FREE_FUNC,        (void*)_adi_dbg_free },
#endif
        /* Assign File cache size and General Heap ID*/
        { ADI_FSS_CMD_SET_NUMBER_CACHE_BLOCKS,      (void*)2 },
        { ADI_FSS_CMD_SET_GENERAL_HEAP_ID,  (void*)GeneralHeapID },
        
        /* Add Media Devices - one command per type of Media Device Present */
        { ADI_FSS_CMD_ADD_DRIVER,           (void*)&ADI_ATAPI_Def },
        { ADI_FSS_CMD_ADD_DRIVER,           (void*)&ADI_SDH_Def },
        
        /* Add File Systems - one command per type of File System Present */
        { ADI_FSS_CMD_ADD_DRIVER,           (void*)&ADI_FAT_Def },
        
        /* DMA and Device Manager Handles */
        { ADI_FSS_CMD_SET_DMA_MGR_HANDLE,   (void*)adi_dma_ManagerHandle },
        { ADI_FSS_CMD_SET_DEV_MGR_HANDLE,   (void*)adi_dev_ManagerHandle },
        { ADI_FSS_CMD_SET_DCB_MGR_HANDLE,   (void*)adi_dcb_QueueHandle },
        
        /* Command Table Terminator */
        { ADI_FSS_CMD_END, (void*)NULL }
    };
    
    /* Initialize the file system service */
    adi_fss_Init ( adi_fss_Config );
    
    /* Add to CRT device table - which will make it the default */
    add_devtab_entry( &adi_fss_entry );
}

/*********************************************************************
*********************************************************************/

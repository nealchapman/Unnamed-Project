/* =============================================================================
 *
 *  Description: Image Viewer Commands etc
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

#ifndef __cplusplus

#include <services/services.h>
#include <drivers/adi_dev.h>
#include <stdio.h>
#include "VDK.h"

#define READ  1
#define WRITE 0

typedef enum {
	ADI_IMAGE_VIEWER_MSG_DISPLAY_FILE,
	ADI_IMAGE_VIEWER_MSG_DISPLAY_TEXT,
	ADI_IMAGE_VIEWER_MSG_EXIT
} ADI_IMAGE_VIEWER_MSG_TYPE;

typedef struct {
    char *pCWD;
    u32  CWDLen;
    char *pFileName;
    u32  FileNameLen;
    u32  RepeatCount;
    u32  ViewDuration;
} ADI_IMAGE_VIEWER_FILE_MSG;

#define ADI_IMAGE_VIEWER_SEM_TIMEOUT 10
#define ADI_IMAGE_VIEWER_MSG_TIMEOUT 1

#define ADI_IMAGE_VIEWER_CHANNEL	VDK_kMsgChannel2


#endif

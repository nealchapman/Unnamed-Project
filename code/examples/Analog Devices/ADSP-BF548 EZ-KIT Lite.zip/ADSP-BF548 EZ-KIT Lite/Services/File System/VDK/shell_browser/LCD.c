/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.  

Description:
        Contains functions to initialize and terminate the LCD attached to the BF548
        EZ-KIT Lite and to read a BMP file and display its contents on the LCD.
				
*********************************************************************************/

#include <stdio.h>
#include <string.h>

#include <services/services.h>                  /* system service includes              */
#include <drivers/adi_dev.h>                    /* device manager includes              */
#include <drivers/lcd/sharp/adi_lq043t1dg01.h>  /* SHARP LQ043T1DG01 LCD driver include */
#include <drivers/eppi/adi_eppi.h>              /* EPPI driver include                  */
#include "adi_ssl_init.h"                       /* DMA and Device Manager Handles       */
 
#include "lcd.h"                                /* Image routines                       */

/*****************************************************************************
    Delayed Call Back (DCB) variables
*****************************************************************************/

extern ADI_DCB_HANDLE adi_dcb_QueueHandle;     

/*****************************************************************************
    LCD specific Macros
*****************************************************************************/

#define LCD_PIXELS_PER_LINE 480                 /* Pixels per line                      */
#define LCD_LINES_PER_FRAME 272                 /* Lines per frame                      */
#define LCD_DATA_PER_PIXEL  3                   /* 3 bytes per pixel (b, g, r)          */

#define LCD_BYTES_PER_FRAME \
              (LCD_PIXELS_PER_LINE * LCD_LINES_PER_FRAME * LCD_DATA_PER_PIXEL)

#define DMA_BUS_SIZE        4                   /* Processor DMA bus size = 4 bytes     */
#define EPPI_DEV_NUMBER     0                   /* LCD connected to EPPI 0              */
#define LCD_DISP_TIMER_ID   ADI_TMR_GP_TIMER_3  /* Timer ID for LCD DISP signal         */
#define LCD_DISP_FLAG_ID    ADI_FLAG_PE3        /* Flag ID connected to LCD DISP signal */

/*****************************************************************************
    BMP header (or at least, the bits we use)
*****************************************************************************/
#pragma pack(2)
typedef struct bmp_s {
    u16    signature;       /* 0x4d42                         */
    u32    file_size;       /* in bytes, unreliable           */
    u16    reserved_1;
    u16    reserved_2;
    u32    data_offset;     /* in bytes, to start of RGB data */
    u32    constant_1;
    u32    pixels_w;        /* image width in pixels          */
    u32    pixels_h;        /* image height in pixels         */
    u16    constant_2;
    u16    bits_per_pixel;  /* we check for 24 (RGB)          */
    u32    compression;
    u32    image_size;      /* in bytes, size of image data   */
    u32    resolution_h;
    u32    resolution_v;
    u32    num_colours_1;
    u32    num_colours_2;
} bmp_t;
#pragma pack()

/* BMP file header area */
static bmp_t bmp_header;

/*****************************************************************************
    Layout of an LCD frame buffer
*****************************************************************************/
typedef u8 frame_line_t[LCD_PIXELS_PER_LINE * LCD_DATA_PER_PIXEL];
typedef frame_line_t frame_t [LCD_LINES_PER_FRAME];

/* Access the two RGB888 frames in DDR which are created in the LDF */
extern "asm" int LCD_frame_0;          /* in sdram0_bank1, uncached */
extern "asm" int LCD_frame_1;          /* in sdram0_bank2, uncached */
static frame_t* DataFrames[2] = {
    (frame_t*)&LCD_frame_0,
    (frame_t*)&LCD_frame_1
};

/* where new frames get built before being displayed */
static frame_t* build_frame;

/* the DMA buffer chains for the two frames */
#define NUM_DMA_BUFFERS 2
section ("L1_data_a")
static ADI_DEV_2D_BUFFER DMABuffers[2][NUM_DMA_BUFFERS];

/* flag to indicate a new image is ready to be displayed */
static volatile int switch_frames;

/* handle for LCD driver  */
static ADI_DEV_DEVICE_HANDLE VideoOutDriverHandle;

/* Callback function for LCD device driver */
static void LcdCallback(
    void    *AppHandle,
    u32     Event,
    void    *pArg
);

/* slideshow function */
static void SlideShow(char *name, char *cwd);

/* delay function (period = millisecs) */
static void delay( u32 period, u32 fcclk );


/****************************************************************************
    Function:      InitLCD

    Description:   Opens a DCB queue for the LCD driver to use and then opens
                   the LCD device and underlying EPPI device. Configures both
                   devices appropriately, sets data buffers to 'black' and
                   starts the data flow to the LCD.

   Return value:   0 if successful, 1 otherwise.
*****************************************************************************/
u32 InitLCD()
{
    u32 Result, ResponseCount;
    int i, k;

    ADI_LQ043T1DG01_TIMER_FLAG  Disp;           /* to hold LCD disp flag details        */

    do {
        /************** Open Sharp LQ043T1DG01 LCD device ***************/

        /* open the LCD driver for video out */
        if((Result = adi_dev_Open(  adi_dev_ManagerHandle,      /* Dev manager Handle                   */
                                    &ADILQ043T1DG01EntryPoint,  /* Device Entry point                   */
                                    0,                          /* Device number                        */
                                    NULL,                       /* No client handle                     */
                                    &VideoOutDriverHandle,      /* Location to store LCD driver handle  */
                                    ADI_DEV_DIRECTION_OUTBOUND, /* Data Direction                       */
                                    adi_dma_ManagerHandle,      /* Handle to DMA Manager                */
                                    adi_dcb_QueueHandle,             /* Handle to callback manager           */
                                    LcdCallback))               /* Callback Function                    */
                    != ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to open video output device , Error Code: 0x%08X\n",Result);
            break;
        }

        /**************** Sharp LQ043T1DG01 LCD driver Configuration ****************/

        Disp.DispTimerId = LCD_DISP_TIMER_ID;   /* Timer ID to be used to generate DISP signal requirements */
        Disp.DispFlagId  = LCD_DISP_FLAG_ID;    /* Flag port to with LCD DISP pin is connected to           */

        /* Set DISP Timer & Flag ID */
        if((Result = adi_dev_Control(
                         VideoOutDriverHandle,
                         ADI_LQ043T1DG01_CMD_SET_DISP_TIMER_FLAG,
                         (void*)&Disp ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to set DISP Timer & Flag ID, Error Code: 0x%08X\n",Result);
            break;
        }

        /* Set EPPI Device number to be used for LCD video out */
        if((Result = adi_dev_Control(
                         VideoOutDriverHandle,
                         ADI_LQ043T1DG01_CMD_SET_EPPI_DEV_NUMBER,
                         (void*)EPPI_DEV_NUMBER ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to set EPPI device number, Error Code: 0x%08X\n",Result);
            break;
        }

        /* Open EPPI Device for LCD out */
        if((Result = adi_dev_Control(
                         VideoOutDriverHandle,
                         ADI_LQ043T1DG01_CMD_SET_OPEN_EPPI_DEVICE,
                         (void*)TRUE ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to open EPPI device for LCD out, Error Code: 0x%08X\n",Result);
            break;
        }

        /* Set DMA streaming mode so that data flow to LCD is not delayed
           during calls to our callback function                            */
        if((Result = adi_dev_Control(
                         VideoOutDriverHandle,
                         ADI_DEV_CMD_SET_STREAMING,
                         (void*)TRUE ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to set EPPI DMA streaming mode, Error Code: 0x%08X\n",Result);
            break;
        }

        /**************** EPPI Configuration ****************/

        /* EPPI Control register configuration value for RGB out
            - EPPI as Output
              GP 2 frame sync mode,
              Internal Clock generation disabled, Internal FS generation enabled,
              Receives samples on EPPI_CLK raising edge,
              Transmits samples on EPPI_CLK falling edge,
              FS1 & FS2 are active high,
              DLEN = 6 (24 bits for RGB888 out)
              DMA unpacking enabled
              Swapping Disabled,
              One (DMA) Channel Mode,
              RGB Formatting disabled for RGB888 output
              Regular watermark - when FIFO is 75% full,
              Urgent watermark - when FIFO is 25% full
        */

        /* EPPI Configuration table for Sharp LQ043T1DG01 LCD */
        /* Note that swapping is enabled because the pixel data read from the file is in
           BGR order but the LCD expects RGB order.                                      */
        ADI_DEV_CMD_VALUE_PAIR EppiLcdConfig[]=
        {
            { ADI_EPPI_CMD_SET_DATA_LENGTH,             (void *)6       },  /* 24 bit out                       */
            { ADI_EPPI_CMD_ENABLE_RGB_FORMATTING,       (void *)FALSE   },  /* Disable RGB formatting           */
            { ADI_EPPI_CMD_SET_PORT_DIRECTION,          (void *)1       },  /* EPPI in Output mode              */
            { ADI_EPPI_CMD_SET_TRANSFER_TYPE,           (void *)3       },  /* GP Transfer mode                 */
            { ADI_EPPI_CMD_SET_FRAME_SYNC_CONFIG,       (void *)2       },  /* GP2 mode                         */
            { ADI_EPPI_CMD_ENABLE_INTERNAL_CLOCK_GEN,   (void *)TRUE    },  /* Internally generated Clock       */
            { ADI_EPPI_CMD_ENABLE_INTERNAL_FS_GEN,      (void *)TRUE    },  /* Internally generated Frame sync  */
            { ADI_EPPI_CMD_SET_CLOCK_POLARITY,          (void *)1       },  /* Tx raising edge, Rx falling edge */
            { ADI_EPPI_CMD_SET_FRAME_SYNC_POLARITY,     (void *)3       },  /* FS1 & FS2 active low             */
            { ADI_EPPI_CMD_SET_SKIP_ENABLE,             (void *)FALSE   },  /* Disable skipping                 */
            { ADI_EPPI_CMD_SET_PACK_UNPACK_ENABLE,      (void *)TRUE    },  /* DMA unpacking enabled            */
            { ADI_EPPI_CMD_SET_SWAP_ENABLE,             (void *)TRUE    },  /* Swapping enabled                 */
            { ADI_EPPI_CMD_SET_SPLIT_EVEN_ODD,          (void *)FALSE   },  /* Splitting disabled               */
            { ADI_EPPI_CMD_SET_FIFO_REGULAR_WATERMARK,  (void *)1       },  /* Regular watermark                */
            { ADI_EPPI_CMD_SET_FIFO_URGENT_WATERMARK,   (void *)3       },  /* Urgent watermark                 */
            { ADI_DEV_CMD_END,                          NULL            }   /* End of command table             */
        };

        /* Configure EPPI Control register - can use LCD driver handle, as LCD driver
         * passes unrecognised commands to EPPI
         */
        if((Result = adi_dev_Control(
                         VideoOutDriverHandle,
                         ADI_DEV_CMD_TABLE,
                         (void*)EppiLcdConfig ))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("Failed to configure EPPI control register for LCD out, Error Code: 0x%08X\n",Result);
            break;
        }

        /****************** Prepare blank video frames ********************/

        memset(DataFrames[0], 0, LCD_BYTES_PER_FRAME);  /* paint it black */
        memset(DataFrames[1], 0, LCD_BYTES_PER_FRAME);  /* paint it black */
        switch_frames = 0;                              /* no new frame   */

        /* the data frame areas are much larger than needed so we build   */
        /* new frames following the displayed portion of DataFrames[1]    */
        build_frame = DataFrames[1] + 1;

        /****************** DMA Buffer preparation ************************/

        /*
           Each data frame has 'NUM_DMA_BUFFERS' DMA buffers set up for it,
           chained with loopback. The last DMA buffer in each chain is set up
           to cause a callback. The two chains are passed to the driver before
           dataflow is enabled, so the sequence of events is
             - DataFrames[0] is sent to the LCD 'NUM_DMA_BUFFERS' times
             - our callback function is called
             - DataFrames[1] is sent to the LCD 'NUM_DMA_BUFFERS' times
             - our callback function is called
             - DataFrames[0] is sent to the LCD 'NUM_DMA_BUFFERS' times again
             - ... and so on ...

           Our callback function checks whether there is a new frame to be displayed
           and if so copies it into the data frame of the chain that has just
           completed. The purpose of having two buffers and two chains is to allow
           filling of one frame while the other is being displayed. The purpose of
           displaying each frame  'NUM_DMA_BUFFERS' times is to allow enough time
           for the frame copying to take place.

           By default the device manager would suspend DMA operations while our callback
           function is active but we enable streaming mode to keep DMA active. This is
           necessary to avoid data starvation at the LCD which results in picture slip
           and color swap.
        */

        for (k = 0; k < 2; k += 1) {
            for (i = 0; i < NUM_DMA_BUFFERS; i++)
            {
                DMABuffers[k][i].Data              = DataFrames[k];
                DMABuffers[k][i].ElementWidth      = DMA_BUS_SIZE;
                DMABuffers[k][i].XCount            = ((LCD_PIXELS_PER_LINE * LCD_DATA_PER_PIXEL)/DMA_BUS_SIZE);
                DMABuffers[k][i].XModify           = DMA_BUS_SIZE;
                DMABuffers[k][i].YCount            = LCD_LINES_PER_FRAME;
                DMABuffers[k][i].YModify           = DMA_BUS_SIZE;
                DMABuffers[k][i].CallbackParameter = NULL;
                DMABuffers[k][i].pNext             = &DMABuffers[k][i+1];
            }
            DMABuffers[k][NUM_DMA_BUFFERS-1].CallbackParameter = &DMABuffers[k][0];
            DMABuffers[k][NUM_DMA_BUFFERS-1].pNext = NULL;
        }

        
        /* Set Dataflow method */
        if((Result = adi_dev_Control(VideoOutDriverHandle,
                                     ADI_DEV_CMD_SET_DATAFLOW_METHOD,
                                     (void *)ADI_DEV_MODE_CHAINED_LOOPBACK))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("EPPI: Failed to set dataflow method, Error Code: 0x%08X\n",Result);
            break;
        }

        /* give the first buffer chain to the device */
        if((Result = adi_dev_Write(VideoOutDriverHandle,
                                   ADI_DEV_2D,
                                   (ADI_DEV_BUFFER *)&DMABuffers[0][0]))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("EPPI: Failed to submit DMABuffers[0][0], Error Code: 0x%08X\n",Result);
            break;
        }

        /* give the second buffer chain to the device */
        if((Result = adi_dev_Write(VideoOutDriverHandle,
                                   ADI_DEV_2D,
                                   (ADI_DEV_BUFFER *)&DMABuffers[1][0]))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("EPPI: Failed to submit DMABuffers[1][0], Error Code: 0x%08X\n",Result);
            break;
        }

        /* Enable LCD video data flow */
        if((Result = adi_dev_Control(VideoOutDriverHandle,
                                     ADI_DEV_CMD_SET_DATAFLOW,
                                     (void *)TRUE))!= ADI_DEV_RESULT_SUCCESS)
        {
            printf("EPPI: Failed to enable dataflow, Error Code: 0x%08X\n",Result);
        }

    } while (0);

    return Result;
}

void TerminateLCD(void)
{
    /* Disable LCD video data flow */
    adi_dev_Control(VideoOutDriverHandle,ADI_DEV_CMD_SET_DATAFLOW,(void *)FALSE);

    /* close the video out driver */
    adi_dev_Close(VideoOutDriverHandle);
}


/****************************************************************************
    Function:      DisplayBMP

    Description:   Open the supplied filepath and read BMP header.  Copy RGB
                   pixel data to build frame and then set flag so that the
                   LCD callback function will copy it to the display frames.

                   Note: this function automatically centers the BMP image on
                   the LCD screen and crops the image top and bottom, left
                   and right if necessary.

   Return value:   0 if successful, 1 otherwise.
*****************************************************************************/

u32 DisplayBMP(char* filepath)
{
    FILE* fp = fopen(filepath, "rb");

    if (!fp) {
        printf("Failed to open BMP file\n");
        return 1;
    }

    /* read the BMP file header */
    if (fread(&bmp_header, sizeof(bmp_t), 1, fp) != 1) {
        printf("Failed to read BMP file header\n");
        fclose(fp);
        return 1;
    }

    /* check the signature */
    if (bmp_header.signature != 0x4D42u) {
        printf("Failed to verify BMP header signature\n");
        fclose(fp);
        return 1;
    }

    /* check the bits-per-pixel (we only do 24 [RGB]) */
    if (bmp_header.bits_per_pixel != (LCD_DATA_PER_PIXEL * 8)) {
        printf("BMP bits-per-pixel not supported: %d\n", bmp_header.bits_per_pixel);
        fclose(fp);
        return 1;
    }

    /* copy image's width and height into properly aligned local variables */
    u32 pixels_w = bmp_header.pixels_w;
    u32 pixels_h = bmp_header.pixels_h;

    /* center the image on the LCD screen                                     */
    /*   calculate number of blank rows above and below image and number of   */
    /*   blank pixels at left and right: negative values mean image needs     */
    /*   cropped                                                              */
    int row_diff    = LCD_LINES_PER_FRAME - pixels_h;
    int row_skip_t  = row_diff / 2;
    int row_skip_b  = row_diff - row_skip_t;
    int col_diff    = LCD_PIXELS_PER_LINE - pixels_w;
    int col_skip_l  = col_diff / 2;
    int col_skip_r  = col_diff - col_skip_l;

    /* calculate number of lines to be read from file */
    int num_file_rows   = (pixels_h < LCD_LINES_PER_FRAME) ? pixels_h : LCD_LINES_PER_FRAME;

    /* calculate number of data bytes per line in file */
    long file_read_bytes = (pixels_w * LCD_DATA_PER_PIXEL);

    /* calculate size of one line's data in file, allowing for padding */
    long file_line_bytes = file_read_bytes +
                             ((file_read_bytes & 3)? (4 - (file_read_bytes & 3)) : 0);

    int r;

    /* set up initial frame data and file data positions         */
    /*    note that frame buffer is filled up from bottom to top */
    /*    since that is the order of data in the file            */
    frame_line_t*
         line_p = &(*build_frame)[LCD_LINES_PER_FRAME];
    long file_p = bmp_header.data_offset;

    /* adjust number of bytes to read from file per line if image cropped */
    /* on left or right                                                   */
    if (col_skip_l < 0) {
        file_read_bytes -= (-col_skip_l) * LCD_DATA_PER_PIXEL;
    }
    if (col_skip_r < 0) {
        file_read_bytes -= (-col_skip_r) * LCD_DATA_PER_PIXEL;
    }

    /* set the frame to black if necessary */
    if (row_diff > 0 || col_diff > 0) {
        memset(build_frame, 0, LCD_BYTES_PER_FRAME);
    }

    /* adjust frame line pointer for unused lines at bottom */
    if (row_skip_b > 0) {
        line_p -= row_skip_b;
    }

    /* adjust file data pointer if necessary to skip cropped rows at bottom */
    if (row_skip_b < 0) {
        file_p += ((-row_skip_b) * file_line_bytes);
    }

    /* adjust file data pointer if necessary to skip cropped cols on left */
    if (col_skip_l < 0) {
        file_p += (-col_skip_l);
    }

    /* for each image row to be displayed read pixel data for line from file */
    /* into appropriate offset in frame area                                 */
    for (r = 0; r < num_file_rows; r += 1) {
        /* get a byte pointer to start of this line's frame data */
        u8* frame_p = (u8*)(--line_p);

        /* adjust data pointer for unused columns on left */
        if (col_skip_l > 0) {
            frame_p += (col_skip_l * LCD_DATA_PER_PIXEL);
        }

        /* move file pointer to start of this line's data */
        if (fseek(fp, file_p, SEEK_SET) != 0) {
            printf("Failed to seek to BMP image data\n");
            fclose(fp);
            return 1;
        }

        /* read in pixel data for this line from file into frame*/
        if (fread(frame_p, file_read_bytes, 1, fp) != 1) {
            printf("Failed to read BMP data line\n");
            fclose(fp);
            return 1;
        }

        /* address start of next line's data in file */
        file_p += file_line_bytes;
    }

    fclose(fp);

    /* signal to LCD callback function that a new frame is available */
    switch_frames = 2;

    return 0;
}


/*****************************************************************************

    Function:       LcdCallback

    Description:    Called at the end of each DMA buffer chain or if there
                    is an error detected by the device driver or DMA service.
                    Each type of callback event has its own unique ID
                    so we can use a single callback function for all
                    callback events.  The switch statement tells us
                    which event has occurred.

*****************************************************************************/
/* place this part of code in L1 */
section ("L1_code")
static void LcdCallback(
    void    *AppHandle,
    u32     Event,
    void    *pArg
){

    ADI_DEV_2D_BUFFER* pBuffer;

    /* CASEOF (event type) */
    switch (Event)
    {
        /* CASE (buffer processed) */
        case ADI_DEV_EVENT_BUFFER_PROCESSED:
            /* if a new frame has been prepared then copy its frame data  */
            /* into this DMA buffer chain's data area                     */
            if (switch_frames > 0) {
                pBuffer = (ADI_DEV_2D_BUFFER*)pArg;
                memcpy(pBuffer->Data, build_frame, LCD_BYTES_PER_FRAME);
                switch_frames -= 1;
            }
            break;

        /* CASE (EPPI Status Error) */
        case ADI_EPPI_EVENT_LUMA_FIFO_ERROR:
        case ADI_EPPI_EVENT_LINE_TRACK_OVERFLOW_ERROR:
        case ADI_EPPI_EVENT_LINE_TRACK_UNDERFLOW_ERROR:
        case ADI_EPPI_EVENT_FRAME_TRACK_OVERFLOW_ERROR:
        case ADI_EPPI_EVENT_FRAME_TRACK_UNDERFLOW_ERROR:
        case ADI_EPPI_EVENT_PREAMBLE_ERROR_NOT_CORRECTED:
        case ADI_EPPI_EVENT_PREAMBLE_ERROR:
            printf("EPPI status error. Event code: 0x%08X\n",Event);
            break;

        /* CASE (DMA Error) */
        case ADI_DEV_EVENT_DMA_ERROR_INTERRUPT:
            printf("EPPI DMA error\n");
            break;

        default:
            printf("EPPI callback event not supported. Event code: 0x%08X\n",Event);
            break;
    }

    /* return */
}




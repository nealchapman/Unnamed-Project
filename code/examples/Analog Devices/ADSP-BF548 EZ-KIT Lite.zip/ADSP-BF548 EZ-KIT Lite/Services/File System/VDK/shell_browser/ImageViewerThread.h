/* =============================================================================
 *
 *  Description: This is a C++ to C Thread Header file for Thread ImageViewerThread
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

#ifndef _ImageViewerThread_H_
#define _ImageViewerThread_H_

#ifndef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress: 177,401,451,826,831,1462)
#endif

#include "VDK.h"
#ifndef _MISRA_RULES
#pragma diag(pop)
#endif

#ifdef __ECC__	/* for C/C++ access */
#ifdef __cplusplus
extern "C" void ImageViewerThread_InitFunction(void**, VDK::Thread::ThreadCreationBlock const *);
#else
extern "C" void ImageViewerThread_InitFunction(void** inPtr, VDK_ThreadCreationBlock const * pTCB);
#endif
extern "C" void ImageViewerThread_DestroyFunction(void** inPtr);
extern "C" int  ImageViewerThread_ErrorFunction(void** inPtr);
extern "C" void ImageViewerThread_RunFunction(void** inPtr);
#endif /* __ECC__ */

#ifdef __cplusplus
#include <new>

class ImageViewerThread_Wrapper : public VDK::Thread
{
public:
    ImageViewerThread_Wrapper(VDK::ThreadCreationBlock &t)
        : VDK::Thread(t)
    { ImageViewerThread_InitFunction(&m_DataPtr, &t); }

    ~ImageViewerThread_Wrapper()
    { ImageViewerThread_DestroyFunction(&m_DataPtr); }

    int ErrorHandler()
    { 
      return ImageViewerThread_ErrorFunction(&m_DataPtr);
     }

    void Run()
    { ImageViewerThread_RunFunction(&m_DataPtr); }

    static VDK::Thread* Create(VDK::Thread::ThreadCreationBlock &t)
    { return new (t) ImageViewerThread_Wrapper(t); }
};

#endif /* __cplusplus */
#endif /* _ImageViewerThread_H_ */

/* ========================================================================== */

/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.  

Description:
				Contains function to initialize the UART console I/O driver.
				
*********************************************************************************/
#include <services/services.h> 
#include <services/fss/adi_fss.h>
#include <drivers/uart/adi_uart.h>
#include <stdio.h>
#include <string.h>
#include <device.h>
#include <device_int.h>


#define _ADI_CONSOLEIO_DEFAULT_DEF_
#include "adi_uart_consoleIO.h"

/* The Deferred Callback, DMA and Device Manager Handles 
 * are only ever assigned once for all device drivers
*/
extern ADI_DCB_HANDLE         adi_dcb_QueueHandle;     /*  handle to DCB Queue          */
extern ADI_DMA_MANAGER_HANDLE adi_dma_ManagerHandle;   /*  handle to the DMA manager    */
extern ADI_DEV_MANAGER_HANDLE adi_dev_ManagerHandle;   /*  handle to the device manager */

/*********************************************************************
*	Function:		InitUARTDriver
*	Description:	opens and configures the UART driver
*********************************************************************/

u32 InitUARTDriver(ADI_DEV_DEVICE_HANDLE *pDeviceHandle, ADI_DCB_CALLBACK_FN CallbackFn )
{
	u32 Result;
	
	Result = adi_dev_Open(
					adi_dev_ManagerHandle,
					ADI_UART_ConsoleIO_Def.pEntryPoint,
					ADI_UART_ConsoleIO_Def.DeviceNumber,
					NULL,
					pDeviceHandle,
					ADI_UART_ConsoleIO_Def.Direction,
					adi_dma_ManagerHandle,
					adi_dcb_QueueHandle,
					CallbackFn
				);
				
	/* configure the Driver */				
	if (Result==ADI_DEV_RESULT_SUCCESS && ADI_UART_ConsoleIO_Def.pConfigTable) 
	{	
		Result = adi_dev_Control( *pDeviceHandle, ADI_DEV_CMD_TABLE, ADI_UART_ConsoleIO_Def.pConfigTable );
	}

	/* Enable dataflow once for all time */
	if (Result==ADI_DEV_RESULT_SUCCESS) 
	{
		Result = adi_dev_Control(*pDeviceHandle, ADI_DEV_CMD_SET_DATAFLOW, (void *)TRUE);
	}
		
	return Result;
	
}



/* =============================================================================
 *
 *  Description: This is a C++ to C Thread Header file for Thread ConsoleIOThread
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

#ifndef _ConsoleIOThread_H_
#define _ConsoleIOThread_H_

#ifndef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress: 177,401,451,826,831,1462)
#endif

#include "VDK.h"
#ifndef _MISRA_RULES
#pragma diag(pop)
#endif

#ifdef __ECC__	/* for C/C++ access */
#ifdef __cplusplus
extern "C" void ConsoleIOThread_InitFunction(void**, VDK::Thread::ThreadCreationBlock const *);
#else
extern "C" void ConsoleIOThread_InitFunction(void** inPtr, VDK_ThreadCreationBlock const * pTCB);
#endif
extern "C" void ConsoleIOThread_DestroyFunction(void** inPtr);
extern "C" int  ConsoleIOThread_ErrorFunction(void** inPtr);
extern "C" void ConsoleIOThread_RunFunction(void** inPtr);
#endif /* __ECC__ */

#ifdef __cplusplus
#include <new>

class ConsoleIOThread_Wrapper : public VDK::Thread
{
public:
    ConsoleIOThread_Wrapper(VDK::ThreadCreationBlock &t)
        : VDK::Thread(t)
    { ConsoleIOThread_InitFunction(&m_DataPtr, &t); }

    ~ConsoleIOThread_Wrapper()
    { ConsoleIOThread_DestroyFunction(&m_DataPtr); }

    int ErrorHandler()
    { 
      return ConsoleIOThread_ErrorFunction(&m_DataPtr);
     }

    void Run()
    { ConsoleIOThread_RunFunction(&m_DataPtr); }

    static VDK::Thread* Create(VDK::Thread::ThreadCreationBlock &t)
    { return new (t) ConsoleIOThread_Wrapper(t); }
};

#endif /* __cplusplus */
#endif /* _ConsoleIOThread_H_ */

/* ========================================================================== */

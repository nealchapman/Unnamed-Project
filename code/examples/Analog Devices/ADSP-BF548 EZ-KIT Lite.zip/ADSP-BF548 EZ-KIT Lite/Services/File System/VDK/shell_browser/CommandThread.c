/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.  

Description:
            Central Command (boot) thread for shell browser application.
				
*********************************************************************************/

/* Get access to any of the VDK features & datatypes used */
#include "CommandThread.h"

#include <services/services.h>
#include <string.h>
#include "cli.h"
#include "lcd.h"
#include "file_ops.h"
#include "consoleio.h"
#include "ImageViewer.h"

/* CRT Device Driver definitions for Console I/0 */
extern DevEntry adi_console_entry;

/* external Services & FSS initialization routines */
extern void InitServices(void);
extern void InitFileSystem(void);

/* Command processing */
extern void ProcessCommand(char *command);

/* Buffer to store the current command line */
static char CommandBuffer[81];
/* Current index within command line buffer */
static u32  CommandBufferIndex=0;

/* current character read from console */
static char ConsoleCharacter;

/* Thread IDs for the Console I/O and Image Viewer threads */
VDK_ThreadID ConsoleIOThread;
VDK_ThreadID ImageViewerThread;

/* static functions */
static void Init(void);
static void Terminate(void);
static s32 ProcessConsoleCharacter(void);

#pragma file_attr("OS_Component=Threads")
#pragma file_attr("Threads")

/* message ID and structure to queue read request */
static VDK_MessageID msgID_CommandRead;
static ADI_CONSOLEIO_INPUT_MSG ConsoleInputData;


/*********************************************************************
*	Function:		CommandThread_RunFunction
*	Description:	Main thread execution function
*********************************************************************/
void
CommandThread_RunFunction(void **inPtr)
{
    u32 cclk,sclk,vco;
    
	/* Set up the application */
	Init();       

    /* Get PLL frequencies */
    adi_pwr_GetFreq(&cclk,&sclk,&vco);
    
    /* Write Welcome Banner to stdout */
    printf("\nWelcome to System Services' Blackfin File System Shell Browser\n");
    printf("ADSP-BF548 running at CCLK = %d Hz, SCLK=%d Hz\n",cclk,sclk);
    ShowDate(stdout);
    ShowVolumes(stdout);
	print_prompt();

    while (1)
    {
        /* queue the comannd read buffer */
    	VDK_PostMessage( ConsoleIOThread, msgID_CommandRead, ADI_CONSOLEIO_CHANNEL );
    	/* receive it back */
        VDK_PendMessage ( ADI_CONSOLEIO_CHANNEL, 0 );
        
        /* Await Console I/O */
        VDK_MessageID cmd = VDK_PendMessage ( ADI_CONSOLEIO_CHANNEL, 0 );
        if (cmd!=UINT_MAX)
        {
        	int type;
        	unsigned int size;
        	void *pBuffer = NULL;
        	VDK_GetMessagePayload(cmd, &type, &size, &pBuffer);
        	if (type==ADI_CONSOLEIO_MSG_QUEUE_READ)
        	{
        	    ADI_CONSOLEIO_INPUT_MSG *pCommand = (ADI_CONSOLEIO_INPUT_MSG*)pBuffer;
                
        	    /* copy aside character obtained from Console */
        	    ConsoleCharacter = pCommand->pInput[0];
            	
        	    /* Return message to Console Thread */
                VDK_PostMessage( ConsoleIOThread, cmd, ADI_CONSOLEIO_CHANNEL );
                
                /* Process the character and execute command when available (on <CR>) */
                if ( ProcessConsoleCharacter() ) 
                {
                    /* Exit application */
                	if (!strncmp("exit", &CommandBuffer[0], 4)) {
                	    break;
                	}
                	
                	/* Poll for media insertion/removal */
                	adi_fss_PollMedia();

            		ProcessCommand(&CommandBuffer[0]);
    				print_prompt();
                }        
        	}        	
        	
        }

    }
    Terminate();

}

int
CommandThread_ErrorFunction(void **inPtr)
{

    /* TODO - Put this thread's error handling code HERE */

      /* The default ErrorHandler goes to KernelPanic */

	VDK_CThread_Error(VDK_GetThreadID());
	return 0;
}

void
CommandThread_InitFunction(void **inPtr, VDK_ThreadCreationBlock const *pTCB)
{
    /* Put code to be executed when this thread has just been created HERE */

    /* This routine does NOT run in new thread's context.  Any non-static thread
     *   initialization should be performed at the beginning of "Run()."
     */
}

void
CommandThread_DestroyFunction(void **inPtr)
{
    /* Put code to be executed when this thread is destroyed HERE */

    /* This routine does NOT run in the thread's context.  Any VDK API calls
     *   should be performed at the end of "Run()."
     */
}

 /****************************************************************
 * Init 
 *      Initializes application.
 *****************************************************************
 */
static void Init(void)
{
    /* Initialize services */
    InitServices();
    
    adi_pwr_SetFreq(400000000,133333333, ADI_PWR_DF_NONE);
    
    /* Initialize the file system */
    InitFileSystem();
    
    /* Create ConsoleIO thread */
	ConsoleIOThread = VDK_CreateThread( kConsoleIOThread );
	
    /* And add the UART console I/O driver to the device table */
	adi_console_entry.data = (void*)&ConsoleIOThread;
    add_devtab_entry( &adi_console_entry );
    
    /* wait for Console I/0 thread */
    VDK_PendSemaphore( kReadyToGo, 0);
    
    /* set stdout as a line buffer */
	setvbuf(stdout,NULL,_IOLBF,BUFSIZ);
	
	/* Create Image Viewer Thread */
    ImageViewerThread = VDK_CreateThread( kImageViewerThread );
    
	/* Instruct Console thread to start receiving input */
	ConsoleInputData.pInput = NULL;
	msgID_CommandRead = VDK_CreateMessage( ADI_CONSOLEIO_MSG_QUEUE_READ, sizeof(ADI_CONSOLEIO_INPUT_MSG), (void*)&ConsoleInputData );
}


 /****************************************************************
 * Terminate 
 *      Terminates application.
 *****************************************************************
 */
static void Terminate(void)
{
	VDK_MessageID msgID;

	msgID = VDK_CreateMessage( ADI_IMAGE_VIEWER_MSG_EXIT, 0, NULL );
	VDK_PostMessage( ImageViewerThread, msgID, ADI_IMAGE_VIEWER_CHANNEL );
	VDK_PendMessage( ADI_IMAGE_VIEWER_CHANNEL, 0 );
	VDK_DestroyMessageAndFreePayload( msgID );

	msgID = VDK_CreateMessage( ADI_CONSOLEIO_MSG_EXIT, 0, NULL );
	VDK_PostMessage( ConsoleIOThread, msgID, ADI_CONSOLEIO_CHANNEL );
	VDK_PendMessage( ADI_IMAGE_VIEWER_CHANNEL, 0 );
	VDK_DestroyMessageAndFreePayload( msgID );
	
    exit(1);
}

/*********************************************************************
*	Function:		ProcessReadBuffer
*	Description:	Processes the Console input buffer to form command 
*                   string. Returns 1 hen command is ready.
*********************************************************************/
static s32 ProcessConsoleCharacter(void)
{
    s32 Result = 0;
    
	switch(ConsoleCharacter) 
	{
		/* CASE ( BACKSPACE key ) - deletes previous character in CommandBuffer buffer */
		case 0x08:
			if (CommandBufferIndex) {
				CommandBuffer[CommandBufferIndex-1] = '\0';
				if (CommandBufferIndex) CommandBufferIndex--;
			}
			break;
			
		/* CASE ( carriage return character ) - processes CommandBuffer */
		case '\r':
			/* finalize CommandBuffer string */
			CommandBuffer[CommandBufferIndex]='\0';
		    Result = 1;
			CommandBufferIndex=0;
			break;
			
		/* CASE (default) - store character in buffer */
		default:
			CommandBuffer[CommandBufferIndex++]=(char)ConsoleCharacter;
			break;
	}
	
	return Result;
}

/* ========================================================================== */

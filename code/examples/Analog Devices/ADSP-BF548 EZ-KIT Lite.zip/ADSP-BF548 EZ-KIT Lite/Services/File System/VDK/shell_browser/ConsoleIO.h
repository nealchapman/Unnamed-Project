/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.

Description:
       Console I/O header file, defing message types.s
 * *************************************************************************************
*/
#ifndef __cplusplus

#include <services/services.h>
#include <drivers/adi_dev.h>
#include <stdio.h>
#include "VDK.h"

/* coonvenience macros */
#define READ  1
#define WRITE 0

/* Console I/I O message types */
typedef enum {
	ADI_CONSOLEIO_MSG_XFER_REQUEST,     /* Request to read/write a number of bytes */
	ADI_CONSOLEIO_MSG_INPUT_READY,      /* Return message containing character read from Console */
	ADI_CONSOLEIO_MSG_QUEUE_READ,       /* Request to queue read for the next character */
	ADI_CONSOLEIO_MSG_EXIT              /* Request to exit thread */
} ADI_CONSOLEIO_MSG_TYPE;

/* Structure containing data for ADI_CONSOLEIO_MSG_INPUT_READY message type */
typedef struct {
    char *pInput;
    u32  InputLen;
} ADI_CONSOLEIO_INPUT_MSG;

/* Structure containing data for ADI_CONSOLEIO_MSG_XFER_REQUEST message type */
typedef struct {
	ADI_DEV_1D_BUFFER Buffer;
	u32 ReadFlag;	
	ADI_SEM_HANDLE SemaphoreHandle;
} ADI_CONSOLEIO_XFER_MSG;

/* time out values */
#define ADI_CONSOLEIO_SEM_TIMEOUT 10    /* Input character ready semaphore */
#define ADI_CONSOLEIO_MSG_TIMEOUT 1     /* Console message */

/* Console I/O Message Channel */
#define ADI_CONSOLEIO_CHANNEL	VDK_kMsgChannel1

#endif

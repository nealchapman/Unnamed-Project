/* MANAGED-BY-SYSTEM-BUILDER                                    */

/*
** User heap source file generated on Aug 24, 2007 at 15:20:55.
**
** Copyright (C) 2000-2007 Analog Devices Inc., All Rights Reserved.
**
** This file is generated automatically based upon the options selected
** in the LDF Wizard. Changes to the LDF configuration should be made by
** changing the appropriate options rather than editing this file.
**
** Configuration:-
**     crt_doj:                                .\Debug\shell_browser_basiccrt.doj
**     processor:                              ADSP-BF548
**     si_revision:                            automatic
**     cplb_init_cplb_ctrl:                    127
**     cplb_init_dcache_ctrl:                  dcache_wt
**     cplb_init_cplb_src_file:                C:\Build Tools\nightly_build\cvsStage\_5.0ExportBlackfinReGen\Examples\Blackfin\Examples\ADSP-BF548 EZ-KIT Lite\Services\File System\VDK\shell_browser\shell_browser_cplbtab.c
**     cplb_init_cplb_obj_file:                .\Debug\shell_browser_cplbtab.doj
**     using_cplusplus:                        true
**     mem_init:                               false
**     use_vdk:                                true
**     use_eh:                                 true
**     use_argv:                               false
**     running_from_internal_memory:           true
**     user_heap_src_file:                     C:\Build Tools\nightly_build\cvsStage\_5.0ExportBlackfinReGen\Examples\Blackfin\Examples\ADSP-BF548 EZ-KIT Lite\Services\File System\VDK\shell_browser\shell_browser_heaptab.c
**     libraries_use_stdlib:                   true
**     libraries_use_fileio_libs:              false
**     libraries_use_ieeefp_emulation_libs:    false
**     libraries_use_eh_enabled_libs:          false
**     system_heap:                            L3
**     system_heap_min_size:                   11K
**     system_stack:                           L3
**     system_stack_min_size:                  2K
**     use_sdram:                              true
**     use_sdram_size:                         64M
**     use_sdram_partitioned:                  default
**     num_user_heaps:                         2
**     user_heap0:                             L3
**     user_heap0_size:                        4M
**     user_heap0_heap_name:                   FSSGeneralHeap
**     user_heap1:                             L2
**     user_heap1_size:                        128K
**     user_heap1_heap_name:                   FSSCacheHeap
**
*/

#ifdef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress:misra_rule_2_2)
#pragma diag(suppress:misra_rule_8_10)
#pragma diag(suppress:misra_rule_10_1_a)
#pragma diag(suppress:misra_rule_11_3)
#pragma diag(suppress:misra_rule_12_7)
#endif /* _MISRA_RULES */


extern "asm" int ldf_heap_space;
extern "asm" int ldf_heap_length;
extern "asm" int FSSGeneralHeap_space;
extern "asm" int FSSGeneralHeap_length;
extern "asm" int FSSCacheHeap_space;
extern "asm" int FSSCacheHeap_length;


struct heap_table_t
{
  void          *base;
  unsigned long  length;
  long int       userid;
};

#pragma file_attr("libData=HeapTable")
#pragma section("constdata")
struct heap_table_t heap_table[4] =
{


  { &ldf_heap_space, (int) &ldf_heap_length, 0 },
  { &FSSGeneralHeap_space, (int) &FSSGeneralHeap_length, 1 },
  { &FSSCacheHeap_space, (int) &FSSCacheHeap_length, 2 },


  { 0, 0, 0 }
};


#ifdef _MISRA_RULES
#pragma diag(pop)
#endif /* _MISRA_RULES */


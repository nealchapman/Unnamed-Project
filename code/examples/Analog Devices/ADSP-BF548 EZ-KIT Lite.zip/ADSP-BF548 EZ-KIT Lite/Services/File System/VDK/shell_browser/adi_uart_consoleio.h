/*********************************************************************************

Copyright(c) 2006 Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.  

Description:
			This is the header file defining Console driver

*********************************************************************************/

#ifndef __ADI_UART_CONSOLEIO_H__
#define __ADI_UART_CONSOLEIO_H__

#include <services/services.h>
#include <drivers/adi_dev.h>
#include <drivers/uart/adi_uart.h>
#include <services/fss/adi_fss.h>

#if !defined(__ADI_UART_CONSOLEIO_C__)
extern ADI_FSS_DEVICE_DEF ADI_UART_ConsoleIO_Def;
extern u8 RawUARTAccess;
#endif

#define BAUD_RATE 57600

/* The following is omitted when included in the driver source module */
#if !defined(__ADI_CONSOLEIO_C__)

/*******************************************************************
* The following is the default configuration for the ATAPI IDE
* driver. To use, define the _ADI_ATAPI_ATAPI_DEFAULT_DEF_
* macro in the enclosing file
*******************************************************************/

#if defined(_ADI_CONSOLEIO_DEFAULT_DEF_)
/*******************************************************************
* command table for the UART driver for Console I/O
*******************************************************************/
static 	ADI_DEV_CMD_VALUE_PAIR UART_ConfigurationTable [] = {	
		{ ADI_DEV_CMD_SET_DATAFLOW_METHOD, 				(void *)ADI_DEV_MODE_CHAINED	},
		{ ADI_UART_CMD_SET_DATA_BITS, 					(void *)8						},
		{ ADI_UART_CMD_ENABLE_PARITY, 					(void *)FALSE					},
		{ ADI_UART_CMD_SET_STOP_BITS, 					(void *)1						},
		{ ADI_UART_CMD_SET_BAUD_RATE, 					(void *)BAUD_RATE				},
		{ ADI_UART_CMD_SET_LINE_STATUS_EVENTS, 			(void *)TRUE					},
		{ ADI_DEV_CMD_END,								NULL							},
};

/*******************************************************************
* definition structure for Console I/O driver
* This is exported to the ConsoleIO Device Driver (C/C++) file & its 
* address used as the stdinfd, stdoutfd & stderrfd values in the 
* DevEntry structure.
*******************************************************************/
ADI_FSS_DEVICE_DEF ADI_UART_ConsoleIO_Def = {
	1,                                      /* Use UART1 for console                    */
	&ADIUARTEntryPoint,						/* Entry Points for UART Driver             */
	UART_ConfigurationTable,				/* Command Table to configure UART driver   */
	NULL,									/* Critical region data                     */
	ADI_DEV_DIRECTION_BIDIRECTIONAL,		/* Direction                                */
	NULL
};

#endif /* _ADI_CONSOLEIO_DEFAULT_DEF_ */

#endif /* __ADI_CONSOLEIO_C__ */

u32 InitUARTDriver(ADI_DEV_DEVICE_HANDLE *pDeviceHandle, ADI_DCB_CALLBACK_FN CallbackFn );


#endif /* __ADI_UART_CONSOLEIO_H__ */


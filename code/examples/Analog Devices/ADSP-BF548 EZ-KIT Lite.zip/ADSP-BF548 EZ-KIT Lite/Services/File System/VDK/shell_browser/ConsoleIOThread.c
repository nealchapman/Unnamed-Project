/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.

Description:
       Console I/O thread source file. This thread receives requests either to 
       collect a character from the console attached to the UART interface or to 
       write to the console.
       
       Communication with the thread is via the ADI_CONSOLEIO_CHANNEL message 
       channel, using the message types defined in consoleIO.h.
       
       Upon startup the thread posts the kReadyToGo semaphore to indicate it is
       ready to receive messaages.
   
*********************************************************************************/

/* Get access to any of the VDK features & datatypes used */
#include "ConsoleIOThread.h"

#include "consoleio.h"
#include "adi_uart_consoleio.h"
#include <string.h>

#pragma file_attr("OS_Component=Threads")
#pragma file_attr("Threads")

/* static functions */
static void Init(void);
static void doTransferRequest( ADI_CONSOLEIO_XFER_MSG *pRequest );
static void doQueueRead( ADI_CONSOLEIO_XFER_MSG *pRequest );
static void Console_Callback(void *hArg, u32 Event, void *pArg);
static void echo(char *pString, u32 StringLen);
static void SendData(char *data, s32 data_len);
static void EchoInputCharacter(char ch);

/* Global device handle for the UART driver */
static ADI_DEV_DEVICE_HANDLE UART_DeviceHandle;

/* Current Read Buffer message structure */
static ADI_CONSOLEIO_XFER_MSG CurrentReadBuffer;
/* which is a wrapper around an ADI_DEV_1D_BUFFER strcuture */
static ADI_DEV_1D_BUFFER *pCurrentReadBuffer=(ADI_DEV_1D_BUFFER*)&CurrentReadBuffer;

/* Current Write Buffer message structure */
static ADI_CONSOLEIO_XFER_MSG CurrentWriteBuffer;
/* which is also a wrapper around an ADI_DEV_1D_BUFFER strcuture */
static ADI_DEV_1D_BUFFER *pCurrentWriteBuffer=(ADI_DEV_1D_BUFFER*)&CurrentWriteBuffer;

/* current input character */
static char uart_inchar_buf;

/* index of character on line */
static u32  PositionInLine=0;

/* Message ID and structure for the input character message */
static VDK_MessageID msgID_Input;
static ADI_CONSOLEIO_INPUT_MSG ConsoleInputData;

/* convenience definitions */
static char crlf[] = { 0x0D, 0x0A, 0x00 };
static char sp = 0x20;

/* Thread ID of thread requesting input data */
VDK_ThreadID RequesterThread;


/*********************************************************************
*	Function:		ConsoleIOThread_RunFunction
*	Description:	Main thread execution function
*********************************************************************/
void
ConsoleIOThread_RunFunction(void **inPtr)
{
	ADI_SEM_RESULT SemResult;
    VDK_MessageID cmd;
    ADI_CONSOLEIO_INPUT_MSG *pMsgBuffer;
    u32 EndOfSession = FALSE;
    
    /* Initialization the Console */
    Init();

    /* Indicate to other boot thread that the Console I/O thread is ready */
    VDK_PostSemaphore( kReadyToGo );
	
    while (!EndOfSession)
    {
		/* Pend on input from console */
        SemResult=adi_sem_Pend (CurrentReadBuffer.SemaphoreHandle, (ADI_CONSOLEIO_SEM_TIMEOUT|VDK_kNoTimeoutError) );
        if (SemResult==ADI_SEM_RESULT_SUCCESS)
        {
            /* echo character */
            EchoInputCharacter (uart_inchar_buf);
            /* send character to requesting thread */
            SendData(&uart_inchar_buf, 1);
        }

        /* Await instructions */
        cmd = VDK_PendMessage ( ADI_CONSOLEIO_CHANNEL, (ADI_CONSOLEIO_MSG_TIMEOUT|VDK_kNoTimeoutError) );
        if (cmd!=UINT_MAX)
        {
        	int type;
        	unsigned int size;
        	void *pBuffer = NULL;
            VDK_MsgChannel channel;
            
            /* Obtain information about message */
            VDK_GetMessageReceiveInfo(cmd, &channel, &RequesterThread);
            VDK_GetMessagePayload(cmd, &type, &size, &pBuffer);

        	/* dispatch command */
        	switch (type)
        	{
        	    /* CASE ( submit read/write request ) */
				case ADI_CONSOLEIO_MSG_XFER_REQUEST:
					doTransferRequest( (ADI_CONSOLEIO_XFER_MSG*)pBuffer );
                	/* Destroy the message */
                	VDK_DestroyMessageAndFreePayload( cmd );
					break;
        	    /* CASE ( Queue read request ) */
				case ADI_CONSOLEIO_MSG_QUEUE_READ:
                	/* queue up read buffer */
                	pMsgBuffer = pBuffer;
                	adi_dev_Read( UART_DeviceHandle, ADI_DEV_1D, (ADI_DEV_BUFFER*)pCurrentReadBuffer );
                	VDK_PostMessage (RequesterThread, cmd, ADI_CONSOLEIO_CHANNEL );
					break;
        	    /* CASE ( Exit Thread Command ) */
        	    case ADI_CONSOLEIO_MSG_EXIT:
            	    EndOfSession = TRUE;
                    echo("Goodbye!\n\r",10);
                	VDK_PostMessage( RequesterThread, cmd, ADI_CONSOLEIO_CHANNEL );
            	    break;
        	}
	
        }

    }

}

int
ConsoleIOThread_ErrorFunction(void **inPtr)
{

    /* TODO - Put this thread's error handling code HERE */

      /* The default ErrorHandler goes to KernelPanic */

	VDK_CThread_Error(VDK_GetThreadID());
	return 0;
}

void
ConsoleIOThread_InitFunction(void **inPtr, VDK_ThreadCreationBlock const *pTCB)
{
    /* Put code to be executed when this thread has just been created HERE */

    /* This routine does NOT run in new thread's context.  Any non-static thread
     *   initialization should be performed at the beginning of "Run()."
     */
}

void
ConsoleIOThread_DestroyFunction(void **inPtr)
{
    /* Put code to be executed when this thread is destroyed HERE */

    /* This routine does NOT run in the thread's context.  Any VDK API calls
     *   should be performed at the end of "Run()."
     */
}

/*********************************************************************
*	Function:		Init
*	Description:	Initializes buffers, semaphores and messages
*********************************************************************/
static void Init(void)
{
	u32 Result;
	
	/* open and initialize the UART device driver */
	Result = InitUARTDriver(&UART_DeviceHandle,Console_Callback);
		
	/* set up read buffer */
	adi_sem_Create(0, &CurrentReadBuffer.SemaphoreHandle, NULL);
	pCurrentReadBuffer->Data = (void*)&uart_inchar_buf;
	pCurrentReadBuffer->ElementWidth = sizeof(char);
	pCurrentReadBuffer->ElementCount = 1;
	pCurrentReadBuffer->ProcessedFlag = FALSE;
	pCurrentReadBuffer->CallbackParameter = pCurrentReadBuffer;
	pCurrentReadBuffer->pNext = NULL;
	
	/* set up write buffer */
	adi_sem_Create(0, &CurrentWriteBuffer.SemaphoreHandle, NULL);
	pCurrentWriteBuffer->Data = NULL;
	pCurrentWriteBuffer->ElementWidth = sizeof(char);
	pCurrentWriteBuffer->ElementCount = 1;
	pCurrentWriteBuffer->ProcessedFlag = FALSE;
	pCurrentWriteBuffer->CallbackParameter = pCurrentWriteBuffer;
	pCurrentWriteBuffer->pNext = NULL;

	/* Create 'send input' message once for all */
	msgID_Input = VDK_CreateMessage( ADI_CONSOLEIO_MSG_QUEUE_READ, sizeof(ADI_CONSOLEIO_INPUT_MSG), (void*)&ConsoleInputData );
		
}

/*********************************************************************
*	Function:		doTransferRequest
*	Description:	Queues buffer with UART driver
*********************************************************************/
static void doTransferRequest( ADI_CONSOLEIO_XFER_MSG *pRequest )
{
	ADI_DEV_1D_BUFFER Buffer;
	
	/* Queue the request with the UART device driver - requestor is responsible for
	  * semaphore
	*/
	if (pRequest->ReadFlag) {
		adi_dev_Read( UART_DeviceHandle, ADI_DEV_1D, (ADI_DEV_BUFFER*)&pRequest->Buffer );
	} else {
		adi_dev_Write( UART_DeviceHandle, ADI_DEV_1D, (ADI_DEV_BUFFER*)&pRequest->Buffer );
	}	
		
}

/*********************************************************************
*	Function:		echo
*	Description:	Writes string to UART console
*********************************************************************/
static void echo(char *pString, u32 StringLen)
{
	ADI_DEV_1D_BUFFER *pBuffer = (ADI_DEV_1D_BUFFER*)&CurrentWriteBuffer;

	pBuffer->Data = (void*)pString;
	pBuffer->ElementCount = StringLen;
	adi_dev_Write( UART_DeviceHandle, ADI_DEV_1D, (ADI_DEV_BUFFER*)pBuffer );	
	adi_sem_Pend ( CurrentWriteBuffer.SemaphoreHandle, ADI_SEM_TIMEOUT_FOREVER);
	
}

/*********************************************************************
*	Function:		SendData
*	Description:	Sends data message to Requestor Thread
*********************************************************************/
static void SendData(char *data, s32 data_len)
{

    /* set up message structure */
    ConsoleInputData.pInput = data;
    ConsoleInputData.InputLen = data_len;
    
    /* Send Message */
	VDK_PostMessage( RequesterThread, msgID_Input, ADI_CONSOLEIO_CHANNEL );
	VDK_PendMessage( ADI_CONSOLEIO_CHANNEL, 0 );
	    
}

/*********************************************************************
*	Function:		Console_Callback
*	Description:	Callback from UART device driver.
*********************************************************************/
static void Console_Callback(void *hArg, u32 Event, void *pArg)
{
	/* Cast the pArg pointer to the buffer data */
	ADI_CONSOLEIO_XFER_MSG *pRequest = (ADI_CONSOLEIO_XFER_MSG *)pArg;
	
	/* CASEOF (event type) */
	switch (Event) {
		
		/* CASE (buffer processed) */
		case ADI_DEV_EVENT_BUFFER_PROCESSED:
		case ADI_DEV_EVENT_SUB_BUFFER_PROCESSED:
			{
				/* Post Semaphore */
				adi_sem_Post(pRequest->SemaphoreHandle);
			}	
			break;
			
		/* CASE (an error) */
		default: /* Raise user exception */
			break;		
	/* ENDCASE */
	}
}

/*********************************************************************
*	Function:		EchoInputCharacter
*	Description:	Proceses input char to obtain correct echo
*********************************************************************/
static void EchoInputCharacter(char ch)
{
	switch(ch) 
	{
		/* CASE ( BACKSPACE key ) - deletes previous character in current line */
		case 0x08:
			if (PositionInLine) {
			    PositionInLine--;
			    /* back space */
				echo(&ch,1);
				/* overwrite space */
				echo(&sp,1);
			    /* back space again */
				echo(&ch,1);
			}
			break;
			
		/* CASE ( carriage return character ) - echos CR+LL & resets line position */
		case '\r':
			echo(crlf,2);
			PositionInLine=0;
			break;
			
		/* CASE (default) - store character in buffer and echo */
		default:
		    PositionInLine++;
			if (ch!=0x7e) {
			    echo(&ch,1);
			}
			break;
	}
}

/* ========================================================================== */

/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.

Description:
            Module containing the image viewing functions
*********************************************************************************/


#include <services/services.h>
#include <services/fss/adi_fss.h>
#include "file_ops.h"
#include "lcd.h"
#include <stdio.h>
#include <string.h>

#include "image.h"

/* Image viewing Parameters */
static u32 gRepeatCount     = 1;
static u32 gViewDuration = 2; /* seconds */
static char *gCWD           = NULL;
static u32 gFcclk           = 250000000;
               
static char fullpath[256];
static void SlideShow(char *name);
static void delay( u32 period, u32 fcclk );

/*********************************************************************
*   Function:       ViewImages
*   Description:    Displays a single image or shows a slide show
*                   from a list of images.
*********************************************************************/
void ViewImages(char *name)
{
    /* find length of file name */
    u32 slen = strlen(name);

    /* IF (file extension is  BMP, display to LCD) */
    if (!strncmp("bmp",&name[slen-3],3) || !strncmp("BMP",&name[slen-3],3) )
    {
        DisplayBMP( FormFullPathName(gCWD,name,fullpath) );
    }
    /* ELSE IF (file extension is LST, run slideshow */
    else if (!strncmp("lst",&name[slen-3],3) || !strncmp("LST",&name[slen-3],3) )
    {
        SlideShow( FormFullPathName(gCWD,name,fullpath) );
    }
    /* Ignore Unknown file ) */

}

/*********************************************************************
*   Function:       SlideShow
*   Description:    Processes a list of image files and displays each
*                   one with a delay of 2s between iamges
*********************************************************************/
static void SlideShow(char *name     )
{
    char ifile[80];
    u32 i;
    /* repeat count - set to 1 for once through */
    u32 repeat = gRepeatCount;

    /* open the list file */
    FILE *fp = fopen(name,"r");
    while (repeat--)
    {
        while(!feof(fp))
        {
            /* read file name and display image */
            fscanf(fp,"%s",ifile);
            ViewImages(ifile);
            /* delay for 2 seconds */
            delay(gViewDuration*1000,gFcclk);
        }
        /* seek to start of list file */
        fseek(fp, 0, SEEK_SET);
    }
    /* close list file */
    fclose(fp);
}

/*********************************************************************
*   Function:       ConfigureViewer
*   Description:    Sets Repeat count and transition delay
*********************************************************************/
void ConfigureViewer( char *CWD, u32 RepeatCount, u32 ViewDuration )
{
    /* Get Core clock frequency */
    u32 sclk, vco;
    adi_pwr_GetFreq( &gFcclk, &sclk, &vco);
    
    /* Assign Current working directory */
    gCWD = CWD;
    
    /* Assign number of times to repeat slideshow */
    gRepeatCount = RepeatCount;
    
    /* assign length of time to display each image */
    gViewDuration = ViewDuration;
}

/*********************************************************************

    Function:       delay

    Description:    Delays for at least the given period in millisecs

*********************************************************************/
#pragma optimize_off
static void delay( u32 period, u32 fcclk )
{
    u32 delay_count, for_loop_cycles, function_call_overhead;

    /* unoptimised for loop takes 11 CCLK cycles each iteration */
    for_loop_cycles = 10;
    /* the overhead in calling this function is 1153 CCLK cycles */
    function_call_overhead = 1153;
    /* calculate the number of CCLK cycles of overall delay */
    delay_count = period*(fcclk/1000);
    /* if the overhead of this function is sufficient then there is
     * no need to sit in a for loop
    */
    if (delay_count > function_call_overhead)
    {
        /* calculate the number of for loop iterations to ensure delay */
        delay_count = (delay_count - function_call_overhead)/for_loop_cycles;
        for ( ; delay_count>0; delay_count--);
    }
}

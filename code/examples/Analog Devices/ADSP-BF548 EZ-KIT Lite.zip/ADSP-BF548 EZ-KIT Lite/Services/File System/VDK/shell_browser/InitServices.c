/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved. 

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.  

Description:
            Set up peripheral priorites, initialize System Services and the 
            Device Manager and open a DCB queue.
				
*********************************************************************************/

#include <services/services.h>

/* DCB queue size for 4 entries */
#define SIZE_DCB ((ADI_DCB_ENTRY_SIZE)*4)

/* DCB queue data */
static u8 DCBMgrQueue1[SIZE_DCB];     

/* DCB queue handle */
ADI_DCB_HANDLE adi_dcb_QueueHandle;                    

/* interrupt priorities for peripherals in system */
typedef struct {
	ADI_INT_PERIPHERAL_ID Peripheral;
	u32 IVG;
} ADI_INIT_SSL_INTERRUPT_DEF;

static ADI_INIT_SSL_INTERRUPT_DEF Interrupts[] = {
	/* EPPI */
	{ ADI_INT_EPPI0_ERROR,		10 },
	{ ADI_INT_DMA12_EPPI0,		11 },
	
	/* ATAPI Interface */
	{ ADI_INT_DMA10_ATAPI_RX, 	10 },
	{ ADI_INT_DMA11_ATAPI_TX, 	10 },
	{ ADI_INT_ATAPI_ERROR, 		12 },
	
	/* SDH Interface */
	{ ADI_INT_SDH_INT0, 		8 },
	{ ADI_INT_SDH_INT1, 		13 },
	
	/* UART Console */
	{ ADI_INT_DMA8_UART1_RX, 	11 },
	{ ADI_INT_DMA9_UART1_TX, 	11 },
	{ ADI_INT_UART0_STATUS, 	11 },

	/* RTC */
	{ ADI_INT_RTC, 		 		9 }
};

/* SSL initialization routine */
extern adi_ssl_Init(void);

/*********************************************************************
*	Function:		InitServices
*	Description:	Initializes the peripheral interrupts, the system 
*                   services library, device manager and DCB queue.
*********************************************************************/
void InitServices(void)
{
    u32 result, ResponseCount, i=0;

#ifdef _USE_HEAP_FOR_SSL_DM_DATA
    DCBMgrQueue1 = (u8*)_adi_dbg_malloc( SSL_HEAPID, ((ADI_DCB_ENTRY_SIZE)*8) );
#endif
        
	/* Set interrupt priorities for peripherals in system */
	for (i=0; i<sizeof(Interrupts)/sizeof(ADI_INIT_SSL_INTERRUPT_DEF); i++)
	{
		adi_int_SICSetIVG(
				Interrupts[i].Peripheral,
				Interrupts[i].IVG
				);
		i++;
				 
	}
	
    /* Initialize all services */
	adi_ssl_Init();
	
	/* Open a DCB queue for Audio Callbacks */
    adi_dcb_Open(
					14, 
    				DCBMgrQueue1, 
					SIZE_DCB, 
					&ResponseCount, 
					&adi_dcb_QueueHandle
					);
}

/*********************************************************************
*********************************************************************/

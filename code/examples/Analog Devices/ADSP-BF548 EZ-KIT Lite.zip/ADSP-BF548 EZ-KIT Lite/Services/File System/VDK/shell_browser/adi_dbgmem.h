/*********************************************************************************

Copyright(c) Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.

$RCSfile: adi_dbgmem.h,v $
$Revision: 1.1 $
$Date: 2007/07/31 10:05:43 $

Description:
            This is the header file for the simple debug memory allocation and 
            reporting interface to use with the File System Service.

*********************************************************************************/


void *_adi_dbg_malloc( int, size_t size );
void *_adi_dbg_realloc( int, void *p, size_t size );
void _adi_dbg_free( int, void *p );
void adi_dbg_MemUsage(void);

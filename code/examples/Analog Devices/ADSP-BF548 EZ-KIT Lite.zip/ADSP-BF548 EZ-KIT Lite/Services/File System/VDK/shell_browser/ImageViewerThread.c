/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.

Description:
            Thread to view images to LCD display.
            
*********************************************************************************/

/* Get access to any of the VDK features & datatypes used */
#include "ImageViewerThread.h"
#include "ImageViewer.h"

#include <services/services.h>
#include <services/fss/adi_fss.h>
#include <string.h>
#include "image.h" 
#include "lcd.h" 

/* Current Image (list) file */
static char ImageFile[81];

/* Current Working directory - for relative paths */
static char CWD[256];

#pragma file_attr("OS_Component=Threads")
#pragma file_attr("Threads")


/*********************************************************************
*	Function:		ImageViewerThread_RunFunction
*	Description:	Main thread execution function
*********************************************************************/
void
ImageViewerThread_RunFunction(void **inPtr)
{
    VDK_ThreadID sender;
    VDK_MessageID cmd;
    VDK_MsgChannel channel;
    
    /* Initialize the LCD driver */
    InitLCD();

    while (1)
    {
        /* Pend on message to view file */
        cmd = VDK_PendMessage ( ADI_IMAGE_VIEWER_CHANNEL, 0 );
        if (cmd!=UINT_MAX)
        {
        	int type;
        	unsigned int size;
        	void *pBuffer = NULL;

        	/* Obtain information about message */        	
            VDK_GetMessageReceiveInfo(cmd, &channel, &sender);
        	VDK_GetMessagePayload(cmd, &type, &size, &pBuffer);
        	
        	/* IF ( Display Image File Command ) */
        	if (type==ADI_IMAGE_VIEWER_MSG_DISPLAY_FILE)
        	{
        	    ADI_IMAGE_VIEWER_FILE_MSG *pCommand = (ADI_IMAGE_VIEWER_FILE_MSG*)pBuffer;
        	    
                
                /* Store the Current Working Directory to ensure the corrrect 
                 * resolution of relative paths if CSWD is changed by an other
                 * thread.
                */
                strncpy( CWD, pCommand->pCWD, pCommand->CWDLen );
                
        	    /* Copy aside the file name */
                strncpy( ImageFile, pCommand->pFileName, pCommand->FileNameLen );
                ImageFile[pCommand->FileNameLen] = '\0';
 
            	/* Set Viewer parameters */
            	ConfigureViewer( CWD, pCommand->RepeatCount, pCommand->ViewDuration);
            	
                /* Message finished with - so return it */
            	VDK_PostMessage( sender, cmd, ADI_IMAGE_VIEWER_CHANNEL );
            	
            	/* Display the file (or list of files) on the LCD screen */
            	ViewImages(ImageFile);
        	}     
        	/* ELSE IF ( Exit Thread Command ) */
        	else if ( type==ADI_IMAGE_VIEWER_MSG_EXIT)
        	{   
        	    TerminateLCD();
            	VDK_PostMessage( sender, cmd, ADI_IMAGE_VIEWER_CHANNEL );
        	    break;
        	}
        	/* ENDIF */   	
        	
        }

    }

}

int
ImageViewerThread_ErrorFunction(void **inPtr)
{

    /* TODO - Put this thread's error handling code HERE */

      /* The default ErrorHandler goes to KernelPanic */

	VDK_CThread_Error(VDK_GetThreadID());
	return 0;
}

void
ImageViewerThread_InitFunction(void **inPtr, VDK_ThreadCreationBlock const *pTCB)
{
    /* Put code to be executed when this thread has just been created HERE */

    /* This routine does NOT run in new thread's context.  Any non-static thread
     *   initialization should be performed at the beginning of "Run()."
     */
}

void
ImageViewerThread_DestroyFunction(void **inPtr)
{
    /* Put code to be executed when this thread is destroyed HERE */

    /* This routine does NOT run in the thread's context.  Any VDK API calls
     *   should be performed at the end of "Run()."
     */
}

/* ========================================================================== */

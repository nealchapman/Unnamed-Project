/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.

Description:
            Command Line interface Module.
            
*********************************************************************************/

#include <services/services.h>
#include "file_ops.h"
#include <stdio.h>
#include <string.h>
#include "md5.h"
#include "cli.h"
#include "adi_dbgmem.h"

/* static function protoypes */
static void DisplayHelpText( u32 index );

/* Command index enumeration values */
enum {
    CLI_CMD_MD5,
    CLI_CMD_CD  ,
    CLI_CMD_PWD  ,
    CLI_CMD_LS  ,
    CLI_CMD_DATE  ,
    CLI_CMD_DF  ,
    CLI_CMD_CAT  ,
    CLI_CMD_MKDIR  ,
    CLI_CMD_RMDIR  ,
    CLI_CMD_VIEW  ,
    CLI_CMD_PLAY  ,
    CLI_CMD_DIFF  ,
    CLI_CMD_CP  ,
    CLI_CMD_RM  ,
    CLI_CMD_MV  ,
    CLI_CMD_FORMAT  ,
    CLI_CMD_MEM  
};

/*********************************************************************

    Function:       ProcessCommand

    Description:    Processes a single command line

*********************************************************************/
void ProcessCommand(char *command)
{	
	/* help command */
    if ( !strncmp("?",command,1) || !strncmp("help",command,4) ) 
    {
        printf("\nHelp\n");
        printf("----\n");
        printf("cd      - Changes the current working directory.\n");
        printf("pwd     - Displays the current working directory.\n");
        printf("ls      - Lists contents of named directory.\n");
        printf("date    - Displays/changes date.\n");
        printf("df      - Lists mounted volumes.\n");
        printf("format  - Formats a volume.\n");
        printf("md5     - Performs MD5 Checksum on a file.\n");
        printf("cat     - Lists a text file to the console.\n");
        printf("mkdir   - Creates a new directory.\n");
        printf("rmdir   - Removes a directory.\n");
        printf("view    - Displays Image file(s) to LCD.\n");
#if 0	
        printf("play    - Plays audio file(s).\n");
#endif        
        printf("diff    - Lists differences between 2 files.\n");
        printf("cp      - Copies files.\n");
        printf("rm      - Deletes a file.\n");
        printf("mv      - Renames a file.\n");
        printf("mem     - Displays memory usage summary to console.\n");
        printf("\nType <cmd> -h to display help on each command.\n");
    
	/* md5 (calculate checksum) command */
	} else if (!strncmp("md5",command,3)) { 
	    if (!strncmp(&command[4], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_MD5 );
	    }
		else if (command[4]) {
			char *pSum = md5_ComputeSumForFile(&command[4]);
			if (pSum)
			    printf("MD5 Checksum of %s = %s\n", &command[4], pSum);
		}
	}

	/* cd (change directory) command */
	if (!strncmp("cd",command,2)) {
	    if (!strncmp(&command[3], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_CD );
	    } 
	    else if (strlen(command)==2)
			chdir("/");
		else
			chdir(&command[3]);
		printf("\n");
	}
			
	/* cd (change directory) command */
	else if (!strncmp("pwd",command,3)) {
	    if (!strncmp(&command[3], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_PWD );
	    } 
	    else {
    		char path[80];
    		getcwd(path, 80);
    		printf("\n%s\n",path);
	    }
	}
			
	/* ls (list directory) command */
	else if (!strncmp("ls",command,2)) {
	    if (!strncmp(&command[3], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_LS );
	    } 
	    else if (strlen(command)==2)
	        ListDir(".");
	    else
		    ListDir(&command[3]);
	}
	
	/* ls (list directory) command */
	else if (!strncmp("date",command,4)) {
    	    if (!strncmp(&command[5], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_DATE );
	    } 
	    else if ( command[5] ) {
    		SetDate(&command[5]);
    		ShowDate(stdout);
	    }
	    else {
    		ShowDate(stdout);
	    }
	}

	/* df (show mounted partitions) command */
	else if (!strncmp("df",command,2)) {
	    if (!strncmp(&command[3], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_DF );
	    } 
		ShowVolumes(stdout);
	}
	
	/* cat (write contents of file to stdout) command */
	else if (!strncmp("cat",command,3) && command[4]) {
	    if (!strncmp(&command[4], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_CAT );
	    } 
		CatFile(&command[4]);
	}
	
	/* mkdir (create directory) command */
	else if (!strncmp("mkdir",command,5) && command[6]) {
	    if (!strncmp(&command[6], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_MKDIR );
	    } 
	    else {
    	    printf("\n");
    		if (mkdir(&command[6],0)==-1) {
                printf("Failed to create directory, %s\n",&command[6]);
    		}
	    }
	}
	
	/* rmdir (remove directory) command */
	else if (!strncmp("rmdir",command,5) && command[6]) {
	    if (!strncmp(&command[6], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_RMDIR );
	    } 
	    else {
	        printf("\n");
		    if (rmdir(&command[6])==-1) {
                printf("Failed to remove directory, %s\n",&command[6]);
		    }
	    }
	}
	
	/*view (displays Image file(s) on LCD) command */
	else if (!strncmp("view",command,4) && command[5]) {
	    if (!strncmp(&command[5], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_VIEW );
	    } else {
            DisplayImageFile(&command[5]);
	    }
	}

#if 0	
	/* play (play audio file(s)) command */
	else if (!strncmp("play",command,4) && command[5]) {
	    if (!strncmp(&command[5], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_PLAY );
	    } else {
    		PlayAudioFile(&command[5],1);
	    }
	}
#endif

	/* diff file command */
	else if (!strncmp("diff",command,4)) {
	    if (!strncmp(&command[3], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_DIFF );
	    } else {
    		DiffFile(command+5);
	    }
	}
	
	/* copy file command */
	else if (!strncmp("cp",command,2) && command[3]) {
	    if (!strncmp(&command[3], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_CP );
	    } else {
		    CopyFile(&command[3]);
	    }
	}
	
	/* remove file command */
	else if (!strncmp("rm",command,2) && command[3]) {
	    if (!strncmp(&command[3], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_RM );
	    } else {
		    RemoveFile(&command[3]);
	    }
	}
	
	/* rename file command */
	else if (!strncmp("mv",command,2) && command[3]) {
	    if (!strncmp(&command[3], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_MV );
	    } else {
    		RenameFile(&command[3]);
	    }
	}
	
	/* remove file command */
	else if (!strncmp("format",command,6) && command[7]) {
	    if (!command[7] || !strncmp(&command[7], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_FORMAT );
	    } else {
    		FormatVolume(&command[7]);
    		ShowVolumes(stdout);
	    }
	}

	/* Show memory usage */
	else if (!strncmp("mem",command,3)) {
	    if (!strncmp(&command[4], "-h", 2) ) {
	        DisplayHelpText( CLI_CMD_MEM );
	    } else {
            printf("\n"); 
	        adi_dbg_MemUsage();
	    }
	}

}



/*********************************************************************

    Function:       DisplayHelpText

    Description:    Displays the help text for the command index

*********************************************************************/
static void DisplayHelpText( u32 index )
{
    switch (index) {
        case CLI_CMD_MD5:
            printf("Usage: md5 <file>\n");
            printf("       Displays MD5 checksum for <file>\n");
            break;
        case CLI_CMD_CD :
            printf("Usage: cd [<dir>]\n");
            printf("       Change Current Working Directory to <dir>.\n");
            printf("       Changes to root directory of current volume if <dir> omitted.\n");
            break;
        case CLI_CMD_PWD :
            printf("Usage: pwd\n");
            printf("       Displays Current Working Directory.\n");
            break;
        case CLI_CMD_LS :
            printf("Usage: ls [<dir>]\n");
            printf("       Lists contents of directory <dir>.\n");
            printf("       Lists Current Working Directory if <dir> omitted.\n");
            break;
        case CLI_CMD_DATE :
            printf("Usage: date [dow MMDDhhmmYYYY]\n");
            printf("       Sets the RTC to the specified date; nomenclature is:\n");
            printf("            dow:  Day of week: 3 letters, lower case\n");
            printf("            MM:   Month: 2 digits\n");
            printf("            DD:   Day of Month: 2 digits\n");
            printf("            hh:   Hour: 2 digits; 24 hour clock\n");
            printf("            mm:   Minutes: 2 digits\n");
            printf("            YYYY: Year: 4 digits\n");
            break;
        case CLI_CMD_DF :
            printf("Usage: df\n");
            printf("       Lists the mounted volumes in format:\n");
            printf("       drive letter, label, type, size, mount status\n");
            break;
        case CLI_CMD_CAT :
            printf("Usage: cat <file>\n");
            printf("       Lists the contents of <file> to console\n");
            break;
        case CLI_CMD_MKDIR:
            printf("Usage: mkdir <dir>\n");
            printf("       Creates the specified directory.\n");
            break;
        case CLI_CMD_RMDIR:
            printf("Usage: rmdir <dir>\n");
            printf("       Deletes the specified directory.\n");
            break;
        case CLI_CMD_VIEW:
            printf("Usage: view [-r=<repeat-count> [-d=<duration>]] <img> | <list>\n");
            printf("       Views either the <img> file or the files listed in <list>.\n");
            printf("       Supports file extensions: .BMP for bitmaps and .LST for lists.\n");
            printf("       For a list of files, each image is displayed for <duration> secs., and\n");
            printf("       the list repeated <repeat-count> times.\n");
            break;
        case CLI_CMD_PLAY:
            printf("Usage: view [<audio> | <list>]\n");
            printf("       Views either the <audio> file or the files listed in <list>.\n");
            printf("       Supports file extensions: .WAV for wave files and .M3U for lists.\n");
            break;
        case CLI_CMD_DIFF:
            printf("Usage: diff <file1> <file2>\n");
            printf("       Displays differences between two files\n");
            break;
        case CLI_CMD_CP:
            printf("Usage: cp <file1> <file2>\n");
            printf("       Copies contents of <file1> to <file2>.\n");
            break;
        case CLI_CMD_RM:
            printf("Usage: rm <file>\n");
            printf("       Deletes <file>.\n");
            break;
        case CLI_CMD_MV:
            printf("Usage: mv <old> <new>\n");
            printf("       renames a file form <old> to <new>\n");
            break;
        case CLI_CMD_FORMAT :
            printf("Usage: format <drive> -t=<type> [-l=<label> [-s=<size>]] \n");
            printf("       Formats the volume with drive letter <drive>\n");
            printf("            <type>:  =16 for FAT16, =32 for FAT32\n");
            printf("            <label>: 11 character label (optional)\n");
            printf("            <size>: Size in MB (optional)\n");
            break;
        case CLI_CMD_MEM:
            printf("Usage: mem\n");
            printf("       Displays FSS heap usage, both current and peak.\n");
            break;
    }
}

/*********************************************************************
*	Function:		print_prompt
*	Description:	writes a command line prompt to the console
*********************************************************************/
void print_prompt(void)
{
	char path[80];
	getcwd(path, 80);
	if (path[0])
		printf("%s%% ",path);
	else
		printf("blackfin%% ");
	
	fflush(stdout);
}


/*********************************************************************
*********************************************************************/

/* =============================================================================
 *
 *  Description: This is a C++ to C Thread Header file for Thread CommandThread
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

#ifndef _CommandThread_H_
#define _CommandThread_H_

#ifndef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress: 177,401,451,826,831,1462)
#endif

#include "VDK.h"
#ifndef _MISRA_RULES
#pragma diag(pop)
#endif

#ifdef __ECC__	/* for C/C++ access */
#ifdef __cplusplus
extern "C" void CommandThread_InitFunction(void**, VDK::Thread::ThreadCreationBlock const *);
#else
extern "C" void CommandThread_InitFunction(void** inPtr, VDK_ThreadCreationBlock const * pTCB);
#endif
extern "C" void CommandThread_DestroyFunction(void** inPtr);
extern "C" int  CommandThread_ErrorFunction(void** inPtr);
extern "C" void CommandThread_RunFunction(void** inPtr);
#endif /* __ECC__ */

#ifdef __cplusplus
#include <new>

class CommandThread_Wrapper : public VDK::Thread
{
public:
    CommandThread_Wrapper(VDK::ThreadCreationBlock &t)
        : VDK::Thread(t)
    { CommandThread_InitFunction(&m_DataPtr, &t); }

    ~CommandThread_Wrapper()
    { CommandThread_DestroyFunction(&m_DataPtr); }

    int ErrorHandler()
    { 
      return CommandThread_ErrorFunction(&m_DataPtr);
     }

    void Run()
    { CommandThread_RunFunction(&m_DataPtr); }

    static VDK::Thread* Create(VDK::Thread::ThreadCreationBlock &t)
    { return new (t) CommandThread_Wrapper(t); }
};

#endif /* __cplusplus */
#endif /* _CommandThread_H_ */

/* ========================================================================== */

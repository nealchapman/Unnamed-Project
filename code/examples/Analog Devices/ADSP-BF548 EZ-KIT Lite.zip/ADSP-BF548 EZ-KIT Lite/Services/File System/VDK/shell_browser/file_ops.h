/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.

Description:
       Header file for file_ops.c.
   
*********************************************************************************/

#ifndef __FILE_OPS_H__
#define __FILE_OPS_H__

#include <services/services.h>
#include <services/fss/adi_fss.h>
#include <stdio.h>

void CatFile(char *name);
void DisplayImageFile(char* filepath);
void CopyFile(char *arg);
void DiffFile(char *arg);
void SetDate(char *arg);
void ShowDate(FILE *fp);
void RemoveFile(char *arg);
void RenameFile(char *arg);
void FormatVolume(char *arg);
char *FormFullPathName( char *path, char *fname, char *fullpath);
void printVolumeInfo(FILE *fp, ADI_FSS_VOLUME_INFO *pPartition);
void ListDir(char *name);
void ShowVolumes(FILE *fp);

#endif /*__FILE_OPS_H__*/

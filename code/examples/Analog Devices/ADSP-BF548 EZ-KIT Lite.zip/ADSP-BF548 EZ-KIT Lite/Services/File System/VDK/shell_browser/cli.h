/*********************************************************************************

Copyright(c) 2007 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.

Description:
            Header file for Command Line interface Module 
            
*********************************************************************************/

#ifndef __CLI_H__
#define __CLI_H__

#ifdef __cplusplus
extern "C"
{
#endif

/* API function */
void ProcessCommand(char *command);
void print_prompt(void);

#ifdef __cplusplus
}
#endif

#endif /* __CLI_H__ */

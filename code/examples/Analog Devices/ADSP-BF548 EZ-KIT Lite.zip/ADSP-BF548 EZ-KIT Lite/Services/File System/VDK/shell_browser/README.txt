Project Name: shell_browser

Project Type:
	ADSP-BF533 [ ]
	ADSP-BF537 [ ]
	ADSP-BF539 [ ]
	ADSP-BF561 [ ]
	ADSP-BF548 [X]
	
Hardware Used:
	EZ-Kit Hard Disk Drive, 
	EZ-KIT SD Card slot,
	UART interface
	LCD panel
	
System Services Components Used:
	DMA Manager                         [X]   Deferred Callback Manager   [X]
	Interrupt Manager                   [X]   Timer Module                [ ]
	Power Management Module             [X]   Flag Module                 [X]
	External Bus Interface Unit Module  [X]   Port Module                 [X]
	File System Service                 [X]   RTC Module                  [X]
	

Example Overview:

This application demonstrates the configuration and use of the File System 
Service available with VisualDSP++ 5.0 within the context of the VDK real time
operating system.

The application uses three threads, one to interface with an I/O console connected
to the UART interface; one to view images on the LCD panel; and one to control
the application and perform non image file tasks.

It is envisaged that all but the simplest of applications will require the 
use of external memory and to this end this example is configured accordingly
such that Instruction and Data Cache are turned on, with both the System Stack
and Heap located in external (L3) memory.

The use of Instruction and Data Cache presents the device driver model with a 
challenge as the Blackfin architecture does not provide for coherency between 
the data cache and the DMA controller. Currently, the device driver model, on which 
the File System Service is built, assumes nothing about the location of DMA 
buffers and thus it is necessary to allocate DMA buffers from a location in either 
L2 or L3 memory for which cacheing is disabled.

This is achieved in this example, by specifying a 16MB section of L3 memory from which
the FSS is to resource its memory requirements. To this end a User Heap, 
FSSGeneralHeap, is defined starting at 0x03000000. The custom CPLB table disables 
cache for this page as follows:

   /* ---------------------------------------------------------------
    * The following pages are set aside for the FSS Heap and since it 
    * will be used for DMA buffers, the cache is disabled.
    */
   {0x03000000, (PAGE_SIZE_4MB | CPLB_DNOCACHE)},
   {0x03400000, (PAGE_SIZE_4MB | CPLB_DNOCACHE)},
   {0x03800000, (PAGE_SIZE_4MB | CPLB_DNOCACHE)},
   {0x03c00000, (PAGE_SIZE_4MB | CPLB_DNOCACHE)},
   /* --------------------------------------------------------------- 
   */

The User heap has index 1 in the custom Heap table file, and is identified in
the InitFileSystem.c file with 

	int GeneralHeapID = heap_lookup(1);

The heap is assigned to the FSS wiht the following entry in its configuration 
table:

        { ADI_FSS_CMD_SET_GENERAL_HEAP_ID,  	(void*)GeneralHeapID },


A "File Cache" Buffer is defined consisting of two cluster blocks. For a 32GB 
FAT32 partition on the hard disk, this results in a requirement of 16KB per
cluster. The following entry can be adjusted to increase the size of the File 
Cache:

        { ADI_FSS_CMD_SET_NUMBER_CACHE_BLOCKS, 	(void*)2 },

The application also uses two 4MB frame buffers in L3 memory for which data cache
is also disabled.
        
Memory Requirements:

Once initialized the FSS consumes 20K of dynamic memory. Each open file requires
requires an extra 70KB of memory when opened for read access. For write access this 
requirement increased by a further 17KB.


Performance:

With the Release mode libraries (default) and with the DMA buffers located in L3, 
the File System Service can achieve a read transfer rate of 9MB/s and a write 
transfer rate of 19MB/s when the processor is run at 400MHz Core Clock and 133MHz
System Clock. With these frequencies Ultra DMA mode 5 is achieved.


File  Structure:

	Main project File:      
				shell_browser.dpj

	Source Files:           
				CommandThread.c
				ConsoleIOThread.c
				ImageViewerThread.c
				adi_consoleIO_deventry.c
				InitFileSystem.c
				InitServices.c
				InitConsoleIO.c
				adi_ssl_init.c
				adi_dbgmem.c
				cli.c
				file_ops.c
				image.c
				lcd.c
				md5.c
				primiolib.c
				..\..\..\..\..\..\lib\src\drivers\fsd\fat\adi_fat.c
				..\..\..\..\..\..\lib\src\drivers\lcd\sharp\adi_lq043t1dg01.c
				..\..\..\..\..\..\lib\src\services\fss\adi_fss.c
				ExceptionHandler-BF548.asm
				
	Header Files:
				adi_ssl_init.h
				adi_uart_consoleIO.h
				CommandThread.h
				ConsoleIOThread.h
				ImageViewerThread.h
				ConsoleIO.h
				adi_dbgmem.h
				cli.h
				file_ops.h
				image.h
				lcd.h
				md5.h

	Generated Files:
				shell_browser.ldf
				shell_browser_basiccrt.s
				shell_browser_cplbtab.c
				shell_browser_heaptab.c

	

Getting Started:

	1) 	Connect a UART serial cable form the EZ-KIT to a PC. Open a terminal emulator application 
	    and set the following:
	    	BAUD RATE: 57600
	    	PARITY:	   None
	    	Stop bits: 1
	    	Data bits: 8
	    	
	2)  The hard disk may require formatting. This can be achieved by using the simple 
	    example application in 
	    
	    <VDSP5.0>\Blackfin\Examples\ADSP-BF548 EZ-KIT Lite\Services\File System\HardDisk\HardDiskFormat
	    
	    This will format the hard disk with a single 32GB FAT32 partition.

	3) Load Project file "shell_browser.dpj"
	4) Build Project by selecting "Rebuild Project"
	5) Run. Yopu should see the following welcome banner on the console (for the HDD only):
	
	   Welcome to System Services' Blackfin File System Shell Browser
	   ADSP-BF548 running at CCLK = 400000000 Hz, SCLK=133333333 Hz
	   Monday 30 July 2007 06:44:05 PM
	   c:      FAT32DATA       FAT32            32768 MB       Mounted
	   c:%
	   
	6) Please note that the shell is very basic: you can delete back along a line but 
	   cannot insert. There is no command history or wild cards.
	
	7) Type help followed by carriage-return to display a list of commands. <command> -h 
	   will display help for <command>.
	   
	8) if you insert an SD Card and type df followed by carriage-return you will see an 
	   additional drive letter for the SD card.
	   
	9) To exit, enter 'exit' at the prompt. This ensures that the LCD driver is properly 
	   terminated. Otherwise it may not function as intended on the next execution of 
	   the application. You will also need to halt the application once "Goodbye!" is 
	   displayed on the console.
	   


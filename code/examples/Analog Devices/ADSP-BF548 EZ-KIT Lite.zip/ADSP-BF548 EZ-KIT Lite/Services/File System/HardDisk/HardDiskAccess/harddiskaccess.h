#include <services/services.h>
#include <services/fss/adi_fss.h>
#include <stdio.h>

/* Exernal Initialization functions */
extern u32 InitServices( void );
extern u32 InitFileSystem( void );

/* external file operation functions */
extern u32 ListDirectory( char *dirname );
extern u32 CreateFile( char *filename );
extern u32 CheckFile( char *filename );
extern void ShowVolumes(FILE *fp);

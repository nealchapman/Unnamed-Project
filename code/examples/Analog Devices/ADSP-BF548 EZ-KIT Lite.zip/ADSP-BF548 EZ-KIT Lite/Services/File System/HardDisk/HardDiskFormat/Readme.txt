Project Name: HardDiskFormat

Project Type:
	ADSP-BF533 [ ]
	ADSP-BF537 [ ]
	ADSP-BF561 [ ]
	ADSP-BF548 [X]
	
Hardware Used:
	EZ-Kit Hard Disk Drive
	
System Services Components Used:
	DMA Manager                         [X]   Deferred Callback Manager   [X]
	Interrupt Manager                   [X]   Timer Module                [ ]
	Power Management Module             [X]   Flag Module                 [ ]
	External Bus Interface Unit Module  [X]   Port Module                 [X]
	File System Service                 [X]   RTC Module                  [ ]
	
Example Overview:
	This project provides both a simple format utility to format the hard disk on 
	the ADSP_BF548 EZ-KIT and an example of how to access the FAT file system driver
	and the ATAPI physical interface driver directly outside of the file system 
	service. 
	
	However, direct access should be reserved to utility applications such as 
	this one where such access is necessary. 
	
	The application simply initializes both the FAT and ATAPI drivers and formats the 
	hard disk to a single FAT32 partition of 32GB.
	
	Output from the application is to the "Output Window" and simply states 
		
		Formatting (this may take a few minutes)...
	
	to indicate that formatting has begun and 
	
		Disk formatted as 32 GB FAT 32

	when the job is done. Please allow a minute or so to perform the format.
	
	*****************************************************************************
	IMPORTANT: 	Please remember that the formatting process renders existing data 
				inaccessible.
	*****************************************************************************
	
	You will now be in a position to use other Hard Disk examples.
	
File  Structure:

	Main project File:      
				./HardDiskFormat.dpj

	Source Files:           
				./HardDiskFormat.c
				./adi_ssl_init.c
				./InitServices.c
				../../../../../../lib/src/drivers/fsd/fat/adi_fat.c
				
	Header Files:
				./adi_ssl_init.h

	Please note, that whilst the FAT driver is available with the device driver 
	library, it is added to the project so as to enable the formatting 
	fucntionality to be available since it is omitted in the library to 
	preserve memory.


System Configuration:
	None
	
Getting Started:

	1) Load Project file "HardDiskFormat.dpj"
	2) Build Project by selecting "Rebuild Project"
	3) Run 
	4) Wait for message to indicate successful formatting
	5) The application automatically halts

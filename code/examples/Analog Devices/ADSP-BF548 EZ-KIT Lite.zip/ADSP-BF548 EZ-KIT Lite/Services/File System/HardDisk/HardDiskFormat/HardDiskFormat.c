/*****************************************************************************
 * HardDiskFormat.c
 *
 * A Sample Application to format the Hard Disk on the Moab EZ-KIT as a single
 * 32GB FAT 32 partition.
 *
 *****************************************************************************/

/* header files */
#include <services/services.h>
#include <services/fss/adi_fss.h>
#include "adi_ssl_init.h"
#include <stdio.h>

/* ATAPI PID definition */
#define  _ADI_ATAPI_DEFAULT_DEF_
#include <drivers/pid/atapi/adi_atapi.h>

/* FAT FSD definition */
#include <drivers/fsd/fat/adi_fat.h>

/* Abstraction layer for direct PID Access */
#include <drivers/pid/adi_rawpid.h>

/* External References */
extern void InitServices(void);
extern ADI_DCB_HANDLE 	adi_dcb_QueueHandle;                    

/* static functions */
static void Init(void);
static u32 QuickFormat(ADI_DEV_DEVICE_HANDLE PID_Handle);
static void CreatePartition( ADI_DEV_DEVICE_HANDLE PID_Handle, ADI_FSS_VOLUME_DEF  *pVolumeDef );
static u32 InitDevice( ADI_FSS_DEVICE_DEF *pDevice,  ADI_DCB_CALLBACK_FN Callback );
static void SetPartitionDef(ADI_ATA_PARTITION_ENTRY *pPartitionTable, ADI_FSS_VOLUME_DEF *pVolumeDef);
static u32 FormatPartition(ADI_DEV_DEVICE_HANDLE PID_Handle,ADI_FSS_VOLUME_DEF *pVolumeDef,char *label, u32 FATType);

/* global for Volume Definition structure */
static ADI_FSS_VOLUME_DEF VolumeDef;

/* global handles for the PID device handle and its semaphore */
ADI_DEV_DEVICE_HANDLE   PID_DeviceHandle;
ADI_SEM_HANDLE          RAW_PID_SemaphoreHandle;

/* This is set in the application to QuickFormatCallback so that this function is
 * executed from the Raw PID callback function.
*/
extern ADI_DCB_CALLBACK_FN adi_rawpid_ClientCallbackFn;
static void QuickFormatCallback(void *hArg, u32 event, void *pArg);

/* Place program arguments in the following string, or delete the definition
   if arguments will be passed from the command line. */
const char __argv_string[] = "-abc -xyz";

/* Macros for legibility */

#define _WRITE_ 0
#define _READ_ 1
 
/* FAT32 */
#define FAT_TYPE 2 

/* Max size of FAT32 partition is 32GB. Size value is given in 512 byte sectors */
#define MAX_SIZE_FAT32_PARTITION ( 0x04000000 )

/* Hard Disk Identifier (drive letter) */
#define HDD_IDENT 'c'


/*********************************************************************

	Function:		main
	
	Description:	main entry point to the application
	
*********************************************************************/
int main( int argc, char *argv[] )
{
	u32 Result=ADI_FSS_RESULT_SUCCESS;
	
	/* Initialize application */
	Init();

	/* Assign Raw PID callback function */
    adi_rawpid_ClientCallbackFn = QuickFormatCallback;
    
    /* Initialize Raw PID module */
    Result = adi_rawpid_Init ( 
                                &ADI_ATAPI_Def,             /* From adi_atapi.h */
                                adi_dev_ManagerHandle,          /* from adi_ssl_init.h */
                                adi_dma_ManagerHandle,          /* from adi_ssl_init.h */
                                adi_dcb_QueueHandle,            
                                &PID_DeviceHandle,
                                &RAW_PID_SemaphoreHandle
                              );
                    
    /* Create single (FAT) partition */
    if ( Result==ADI_FSS_RESULT_SUCCESS )
	{
	    Result = QuickFormat( PID_DeviceHandle );
        if ( Result!=ADI_FSS_RESULT_SUCCESS) {
	        printf ("Format failed with Result Code %08X\n", Result);
        }
        	
	}
    else {
        printf ("Format failed - can't activate disk\n");
	}

	return 0;
}

/*********************************************************************

	Function:		Init
	
	Description:	Initialize the application
	
*********************************************************************/
static void Init(void)
{
	/* initialize System Services */
    InitServices();
    
    /* Set FSS General Heap ID */
    ADI_FSS_CMD_VALUE_PAIR FSS_ConfigTable [] = {	
		    { ADI_FSS_CMD_SET_GENERAL_HEAP_ID, (void*)1 },
            { ADI_DEV_CMD_END,                 NULL	   },
    };
    
    adi_fss_Init ( FSS_ConfigTable );

    /* set SCLK to max */
    adi_pwr_SetFreq(400000000, 133333333, ADI_PWR_DF_NONE);
    
}

/*********************************************************************

	Function:		QuickFormat
	
	Description:	Application main work routine.
	
*********************************************************************/
u32 QuickFormat(ADI_DEV_DEVICE_HANDLE PID_Handle)
{
	ADI_RAWPID_MEDIA_INFO   MediaInfo;
	u32 StartSector;
	unsigned long long disksize;
	u32 Result;
	static u16 mbr[256],fat_bpb[256];

	/* Get Global Information about the Hard Disk */
	adi_dev_Control( PID_Handle, ADI_PID_CMD_GET_GLOBAL_MEDIA_DEF, &VolumeDef);
	
	/* and limit partition size to largest FAT 32 Partition */
	if ( VolumeDef.VolumeSize > MAX_SIZE_FAT32_PARTITION ){
		 VolumeDef.VolumeSize = MAX_SIZE_FAT32_PARTITION - VolumeDef.StartAddress;
	}
	
	/* Create a single partition */
	memset (mbr, 0, 512);
	memset (fat_bpb, 0, 512);
    adi_rawpid_TransferSectors( PID_Handle, 0, 0, 1, 512, mbr, _WRITE_, RAW_PID_SemaphoreHandle );
    adi_rawpid_TransferSectors( PID_Handle, 0, 0x3f, 1, 512, fat_bpb, _WRITE_, RAW_PID_SemaphoreHandle  );
	CreatePartition( PID_Handle, &VolumeDef  );
	
	/* Perform Format */
	printf("Formatting (this may take a few minutes)...\n");
	Result = FormatPartition( PID_Handle, &VolumeDef, "FAT32DATA", FAT_TYPE );
	
	/* If successfull, write summary details */
	if (Result==ADI_FSS_RESULT_SUCCESS) {
		disksize = ((unsigned long long)VolumeDef.VolumeSize) * ((unsigned long long)VolumeDef.SectorSize);
		disksize /= (1024*1024); /* MB */

		if ((u32)disksize > 1024) { 
			printf("Disk formatted as %d GB FAT %d\n",(u32)disksize/1024,FAT_TYPE*16);
		} else {
			printf("Disk formatted as %d MB FAT %d\n",(u32)disksize,FAT_TYPE*16);
		}
	}
	
    return Result; 
}


/*********************************************************************

	Function:		InitDevice
	
	Description:	Opens and configures a device driver
	
*********************************************************************/

static u32 InitDevice( ADI_FSS_DEVICE_DEF *pDevice,  ADI_DCB_CALLBACK_FN Callback )
{
	u32 result;
	/* Open the Device Driver */
	result = adi_dev_Open(
						adi_dev_ManagerHandle,
						pDevice->pEntryPoint,
						0,
						pDevice,
						&pDevice->DeviceHandle,
						ADI_DEV_DIRECTION_BIDIRECTIONAL,
						adi_dma_ManagerHandle,
						NULL,
						Callback
						);

	if (result) 
		return result;

	/* Configure the Device Driver */
	if (pDevice->pConfigTable) {
		ADI_DEV_CMD_VALUE_PAIR *pair = &pDevice->pConfigTable[0];
		while (pair->CommandID!=ADI_DEV_CMD_END)
		{
			result = adi_dev_Control(
							pDevice->DeviceHandle,
							pair->CommandID,
							(void *)pair->Value
							);
			pair++;
		}
	}
	if (result) 
		return result;

	return ADI_DEV_RESULT_SUCCESS;

}


/*********************************************************************

	Function:		SetPartitionDef
	
	Description:	Sets up primary partition table for writing.
	                Can be rewritten to define up to 4 primary partitions 
	                once the overall drive size is ascertained.
	
*********************************************************************/

static void SetPartitionDef(ADI_ATA_PARTITION_ENTRY *pPartitionTable, ADI_FSS_VOLUME_DEF *pVolumeDef)
{
	memset ( pPartitionTable, 0, 4*sizeof(ADI_ATA_PARTITION_ENTRY) );
	
	pPartitionTable[0].type      = ADI_ATA_VOLUME_TYPE_PRI_FAT32_LBA;
	pPartitionTable[0].lba_start = pVolumeDef->StartAddress;
	
	if ( pVolumeDef->VolumeSize > MAX_SIZE_FAT32_PARTITION ){
		pVolumeDef->VolumeSize = 
	    pPartitionTable[0].size = MAX_SIZE_FAT32_PARTITION - pVolumeDef->StartAddress;
	} else {
	    pPartitionTable[0].size = pVolumeDef->VolumeSize;
	}
}


/*********************************************************************

	Function:		CreatePartition
	
	Description:	Creates a single FAT32 partition to fill the 
	                whole drive.
	
*********************************************************************/

static void CreatePartition( ADI_DEV_DEVICE_HANDLE PID_Handle, ADI_FSS_VOLUME_DEF  *pVolumeDef )
{
	u16 MasterBootRecord[256];

	ADI_ATA_PARTITION_ENTRY PartitionTable[4];
	u32                     Pending;

	/* initialize MBR with zeros */
	memset( &MasterBootRecord[0], 0, 512 );
	MasterBootRecord[255] = 0xAA55;

	/* construct partition table */
	SetPartitionDef(PartitionTable, pVolumeDef);
	
	/* Copy to MBR */
	memcpy ( &MasterBootRecord[223], PartitionTable, 4*sizeof(ADI_ATA_PARTITION_ENTRY) );
	
	/* write to disk */
    adi_rawpid_TransferSectors( PID_Handle, 0, 0, 1, 512, &MasterBootRecord[0], _WRITE_, RAW_PID_SemaphoreHandle );
	    	
}

/*********************************************************************

	Function:		FormatPartition
	
	Description:	Formats the single HDD volume as FAT32
	
*********************************************************************/
static u32 FormatPartition( 
                    ADI_DEV_DEVICE_HANDLE PID_Handle,
                    ADI_FSS_VOLUME_DEF *pVolumeDef,
                    char *label, 
                    u32 FATType
                    )
{
	ADI_FSS_FORMAT_DEF FormatDef;
	ADI_FSS_WCHAR label_text[11];
	u32 i, label_len = 11;
	u32 Result;

	/* Copy label to ADI_FSS_WCHAR array */
	for (i=0;i<(label_len);i++)
	    label_text[i] =label[i]; 
	
	/* Copy volume definition */
	FormatDef.VolumeDef = *pVolumeDef;
	
    /* Copy Options' Mask */
    FormatDef.OptionMask = ADI_FSS_FMT_OPTION_VALUE(ADI_FSS_FSD_TYPE_FAT,FATType);
    FormatDef.VolumeDef.FileSystemType = ADI_FSS_FSD_TYPE_FAT;
    
    /* Copy address of label array and its length */
    FormatDef.label = &label_text[0];
    FormatDef.label_len = label_len;
	
    /*******************************************************************
    * command table for the FAT driver
    *******************************************************************/
    ADI_DEV_CMD_VALUE_PAIR FAT_ConfigTable [] = {	
            { ADI_DEV_CMD_SET_DATAFLOW_METHOD, (void *)ADI_DEV_MODE_CHAINED	},
            { ADI_FSD_CMD_SET_PID_HANDLE,      (void*)PID_Handle            },
            { ADI_DEV_CMD_END,                 NULL							},
    };

    /*******************************************************************
    * definition structure for FAT driver - exported to application 
    *******************************************************************/
    ADI_FSS_DEVICE_DEF FAT_Def = {
    	0,                                      /* N/A for FSD drivers                    */
        &ADI_FAT_EntryPoint,                    /* Entry Points for FAT Driver            */
        FAT_ConfigTable,                        /* Command Table to configure FAT driver  */
        NULL,                                   /* Critical region data                   */
        ADI_DEV_DIRECTION_BIDIRECTIONAL,        /* Direction (RW file system)             */
        NULL
    };
   
	InitDevice( &FAT_Def, QuickFormatCallback);

    if (FAT_Def.DeviceHandle) 
    {
    	/* format the partition */
        Result = adi_dev_Control(FAT_Def.DeviceHandle, ADI_FSD_CMD_FORMAT_VOLUME, (void*)&FormatDef );

		/* Copy back volume definition */
		 *pVolumeDef = FormatDef.VolumeDef;
        /* and close device driver as it is no longer required */     
        adi_dev_Close(FAT_Def.DeviceHandle);
    }
    	  
    return Result;  
}

/*********************************************************************

	Function:		QuickFormatCallback
	
	Description:	Callback Function for the application
	
*********************************************************************/
static void QuickFormatCallback(void *hArg, u32 Event, void *pArg)
{
    ADI_FSS_SUPER_BUFFER *pSuperBuffer = (ADI_FSS_SUPER_BUFFER *)pArg;

    /* CASEOF ( Event flag ) */
    switch (Event)
    {
        /* CASE (Device Interrupt Event) */
        case (ADI_PID_EVENT_DEVICE_INTERRUPT):
        case (ADI_DEV_EVENT_BUFFER_PROCESSED):
            /* Call FSD callback function */
            if (pSuperBuffer->FSDCallbackFunction) {
            	(pSuperBuffer->FSDCallbackFunction)( pSuperBuffer->FSDCallbackHandle, Event, pArg );
            }
            break;

        /* CASE (Media removal event) */
        case (ADI_FSS_EVENT_VOLUME_DETECTED):
			VolumeDef = *(ADI_FSS_VOLUME_DEF *)pArg;
            break;

        /* END CASEOF */
    }
}

Project Name: HardDiskAccess

Project Type:
	ADSP-BF533 [ ]
	ADSP-BF537 [ ]
	ADSP-BF539 [ ]
	ADSP-BF561 [ ]
	ADSP-BF548 [X]
	
Hardware Used:
	EZ-Kit Hard Disk Drive
	
System Services Components Used:
	DMA Manager                         [X]   Deferred Callback Manager   [X]
	Interrupt Manager                   [X]   Timer Module                [ ]
	Power Management Module             [X]   Flag Module                 [X]
	External Bus Interface Unit Module  [X]   Port Module                 [X]
	

Example Overview:

This application demonstrates the configuration and use of the File System 
Service available with VisualDSP++ 5.0.

It is envisaged that all but the simplest of applications will require the 
use of external memory and to this end this example is configured accordingly
such that Instruction and Data Cache are turned on, with both the System Stack
and Heap located in external (L3) memory.

The use of Instruction and Data Cache presents the device driver model with a 
challenge as the Blackfin architecture does not provide for coherency between 
the data cache and the DMA controller. Currently, the device driver model, on which 
the File System Service is built on, assumes nothing about the location of DMA 
buffers and thus it is necessary to allocate DMA buffers from a location in either 
L2 or L3 memory for which cacheing is disabled.

This is achieved in this example, by specifying a 4MB page of L3 memory from which
the FSS is to resource its memory requirements. To this end a User Heap, 
FSSGeneralHeap, is defined starting at 03000000h. The custom CPLB table disables 
cache for this page as follows:

   /* ---------------------------------------------------------------
    * The following page is set aside for the FSS Heap and since it 
    * will be used for DMA buffers, the cache is disabled.
    */
   {0x03000000, (PAGE_SIZE_4MB | CPLB_DNOCACHE)},
   /* ---------------------------------------------------------------
    */

The User heap has index 1 in the custom Heap table file, and is identified in
the InitFileSystem.c file with 

	int GeneralHeapID = heap_lookup(1);

The heap is assigned to the FSS wiht the following entry in its configuration 
table:

        { ADI_FSS_CMD_SET_GENERAL_HEAP_ID,  	(void*)GeneralHeapID },


A "File Cache" Buffer is defined consisting of two cluster blocks. For a 32GB 
FAT32 partition on the hard disk, this results in a requirement of 16KB per
cluster. The following entry can be adjusted to increase the size of the File 
Cache:

        { ADI_FSS_CMD_SET_NUMBER_CACHE_BLOCKS, 	(void*)2 },

        
        
The following details or similar should be sent to the Output Window:

	Drive c: label=FAT32DATA  , size= 32767MB, type=FAT32   
	Directory Directory 1 created
	File Simple File 1 created
	Contents of Directory 1 directory:
	d	         0  May 16 2007 00:56:13	. 
	d	         0  May 16 2007 00:56:13	.. 
	f	      1024  May 16 2007 00:56:13	Simple File 1 
	MD5 Checksum of Simple File 1 = 21aebfdb913697424f9c60af7ee666d4
	Checksum matches
	File Simple File 1 removed
	Directory Directory 1 removed

	
                
Memory Requirements:

Once initialized the FSS consumes 20K of dynamic memory. Each open file requires
requires an extra 70KB of memory when opened for read access. For write access this 
requirement increased by a further 17KB.



Performance:

With the Release mode libraries (default) and with the DMA buffers located in L3, 
the File System Service can achieve a read transfer rate of 9MB/s and a write 
transfer rate of 19MB/s when the processor is run at 400MHz Core Clock and 133MHz
System Clock. With these frequencies Ultra DMA mode 5 is achieved.



File  Structure:

	Main project File:      
				HardDiskAccess.dpj

	Source Files:           
				HardDiskAccess.c
				InitFileSystem.c
				InitServices.c
				adi_ssl_init.c
				fileops.c
				md5.c
				
	Header Files:
				HardDiskAccess.h
				adi_ssl_init.h
				md5.h
				filedata.h

	Generated Files:
				HardDiskAccess.LDF
				HardDiskAccess_basiccrt.s
				HardDiskAccess_cplbtab.c
				HardDiskAccess_heaptab.c

	

Getting Started:

	1)  The hard disk may require formatting. This can be achieved by using the simple 
	    example application in 
	    
	    <VDSP5.0>\Blackfin\Examples\ADSP-BF548 EZ-KIT Lite\Services\File System\HardDisk\HardDiskFormat
	    
	    This will format the hard disk with a single 32GB FAT32 partition.

	2)	Load Project file "HardDiskAccess.dpj"
	3)	Build Project by selecting "Rebuild Project"
	4)	Run. 
	
	


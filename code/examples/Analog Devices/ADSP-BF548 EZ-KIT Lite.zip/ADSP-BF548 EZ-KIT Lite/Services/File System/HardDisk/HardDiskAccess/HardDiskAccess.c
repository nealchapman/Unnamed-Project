/*****************************************************************************
 * HardDiskAccess.c
 *
 *		Example Application to configure and use the File System Service
 *		available wiht VisualDSP 5.0.
 *
 *****************************************************************************/

#include "harddiskaccess.h"
#include <string.h>

/* static prototypes */
static u32 Init(void);
static ADI_INT_HANDLER(ExceptionHandler);


/*****************************************************************************
 * main entry point
 *****************************************************************************/
int main( void )
{
	u32 Result;
	
	/* Initialize */
	Result = Init();
	
	/* If successful, perform some simple file ops */
	if (!Result) {
		
		/* Display the mounted FAT partition */
		ShowVolumes(stdout);

		do {		
			/* Create a New sub directory */
			if ( mkdir("Directory 1",0) ==-1) {
				Result = ADI_FSS_RESULT_FAILED;
				break;
			}
			printf("Directory %s created\n","Directory 1");
		
			/* Move to the sub directory */
			if ( chdir("Directory 1") ==-1) {
				Result = ADI_FSS_RESULT_FAILED;
				break;
			}
		
			/* Create a New file in this directory */
			if ( CreateFile("Simple File 1")!=ADI_FSS_RESULT_SUCCESS ) {
				break;
			}
			printf("File %s created\n","Simple File 1");
				
			/* List the contents of the directory */
			printf("Contents of %s directory:\n","Directory 1");
			if ( ListDirectory(".")!=ADI_FSS_RESULT_SUCCESS ) {
				break;
			};
		
			/* Perform an MD5 Checksum on the file */
			if ( CheckFile("Simple File 1")!=ADI_FSS_RESULT_SUCCESS ) {
				break;
			}
			/* Remove the file */
			if ( adi_fss_FileRemove("Simple File 1", strlen("Simple File 1"))!=ADI_FSS_RESULT_SUCCESS ) {
				Result = ADI_FSS_RESULT_FAILED;
				break;
			}
			printf("File %s removed\n","Simple File 1");
		
			/* move to root directory */
			if ( chdir("..")==-1) {
				Result = ADI_FSS_RESULT_FAILED;
				break;
			}
		
			/* Remove the directory */
			if ( rmdir("Directory 1")==-1) {
				Result = ADI_FSS_RESULT_FAILED;
				break;
			}
			printf("Directory %s removed\n","Directory 1");
	 	/* WHILE (no errors or 1 pass complete) */
		} while(0);
	} 
	
	printf("All done\n");
	
	return (Result ? 0 : 1);
}


/*****************************************************************************
 * Init
 *		Initialize the application
 *****************************************************************************/
static u32 Init(void)
{
	u32 Result;
    /* Initialize services */
    Result = InitServices();
    
    if ( !Result ) {
	    /* Set the clock frequency to obtain optimal performance for ATAPI interface */
	    adi_pwr_SetFreq(400000000,133333333, ADI_PWR_DF_NONE);
    
	    /* hook exception handler */
	    adi_int_CECHook(3, ExceptionHandler, NULL, FALSE);
    
	    /* Initialize the file system */
	    Result = InitFileSystem();
    }
    
    return Result;

}

 /****************************************************************
 * Exception handler
 * (set break point in routine to aid debugging)
 *****************************************************************
 */
static ADI_INT_HANDLER(ExceptionHandler)
{
	return(ADI_INT_RESULT_PROCESSED);
}


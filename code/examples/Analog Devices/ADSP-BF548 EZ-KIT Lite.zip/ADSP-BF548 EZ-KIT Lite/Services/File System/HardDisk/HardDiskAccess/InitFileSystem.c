#include <services/services.h>
#include <services/fss/adi_fss.h>

/* File Sytem Drivers
 * ******************
*/

/* FAT12/16/32 FSD driver */

/* instruct the compiler to include code for FSD def from the header.
 * comment out the following line and add your own configuration if
 * required */
#define _ADI_FAT_DEFAULT_DEF_
#include <drivers/fsd/fat/adi_fat.h>

/* Physical Interface Device Drivers
 * *********************************
*/
/* ATAPI PID Driver */

/* instruct the compiler to include code for PID def from the header.
 * comment out the following line and add your own configuration if
 * required */
#define _ADI_ATAPI_DEFAULT_DEF_
#include <drivers/pid/atapi/adi_atapi.h>


/* DMA and Device Manager Handles */
#include "adi_ssl_init.h"

/* Heap header */
#include <heapinfo.h>

/* DCB queue handle */
extern ADI_DCB_HANDLE adi_dcb_QueueHandle;

/*******************************************************************
* InitFileSystem
*       Initializes the File System Service for use and adds it to the
*       C runtime extensible I/O table to make it the default for
*       the standard C I/O functions.
*******************************************************************/
u32 InitFileSystem(void)
{
    u32 Result;
    /*******************************************************************
    * Customized heaps for General, fat and atapi 'cache' type data
    *******************************************************************/
    int GeneralHeapID = heap_lookup(1);

    /*******************************************************************
    * Configuration table to initialize the FSS
    *******************************************************************/
    ADI_FSS_CMD_VALUE_PAIR adi_fss_Config[] = {

        /* Set up File Cache Size */
        { ADI_FSS_CMD_SET_NUMBER_CACHE_BLOCKS,  (void*)2 },

        /* Set up Heap Index of the FSS General Heap */
        { ADI_FSS_CMD_SET_GENERAL_HEAP_ID,      (void*)GeneralHeapID },

        /* Register the ATA/ATAPI interface driver */
        { ADI_FSS_CMD_ADD_DRIVER,               (void*)&ADI_ATAPI_Def },

        /* Register the FAT File System driver */
        { ADI_FSS_CMD_ADD_DRIVER,               (void*)&ADI_FAT_Def },

        /* Assign the DMA Manager Handle */
        { ADI_FSS_CMD_SET_DMA_MGR_HANDLE,       (void*)adi_dma_ManagerHandle },

        /* Assign the Device Manager Handle */
        { ADI_FSS_CMD_SET_DEV_MGR_HANDLE,       (void*)adi_dev_ManagerHandle },

        /* Assign the DCB Queue Handle */
        { ADI_FSS_CMD_SET_DCB_MGR_HANDLE,       (void*)adi_dcb_QueueHandle },

        /* Command Table Terminator */
        { ADI_FSS_CMD_END, (void*)NULL }
    };

    /* Initialize the file system service */
    Result = adi_fss_Init ( adi_fss_Config );

    /* Add to C runtime device table - which will make it the default - so we
       can use fopen(), fread(), ..., to access files on the Hard disk
    */
    if (!Result) {
        add_devtab_entry( &adi_fss_entry );
    }

    return Result;
}

/*******************************************************************
* Set up peripheral priorites, initialize System Services and the 
* Device Manager and open a DCB queue.
*******************************************************************/
#include <services/services.h>

#define SIZE_DCB ((ADI_DCB_ENTRY_SIZE)*4)

/* DCB queue data   */
static u8 DCBMgrQueue1[SIZE_DCB];     

/* DCB queue handle */
ADI_DCB_HANDLE adi_dcb_QueueHandle;                    

/* interrupt priorities for peripherals in system */
typedef struct {
	ADI_INT_PERIPHERAL_ID Peripheral;
	u32 IVG;
} ADI_INIT_SSL_INTERRUPT_DEF;

static ADI_INIT_SSL_INTERRUPT_DEF Interrupts[] = {
	{ ADI_INT_ATAPI_ERROR, 		 7 },           /* ATAPI Device Interrupt */
	{ ADI_INT_DMA10_ATAPI_RX, 	10 },           /* ATAPI DMA RX */
	{ ADI_INT_DMA11_ATAPI_TX, 	10 },           /* ATAPI DMA RX */
	{ (ADI_INT_PERIPHERAL_ID)NULL, 0}
};

/* SSL initialization routine */
extern adi_ssl_Init(void);

void InitServices(void)
{
    u32 result, ResponseCount, i=0;
    
#ifdef _USE_HEAP_FOR_SSL_DM_DATA
    DCBMgrQueue1 = (u8*)_adi_dbg_malloc( SSL_HEAPID, ((ADI_DCB_ENTRY_SIZE)*8) );
#endif
        
	/* Set interrupt priorities for peripherals in system */
	while ( Interrupts[i].IVG!=0 )
	{
		adi_int_SICSetIVG(
				Interrupts[i].Peripheral,
				Interrupts[i].IVG
				);
		i++;
				 
	}
	
    /* Initialize all services */
	adi_ssl_Init();
	
	/* Open a DCB queue for Audio Callbacks */
    result = (u32)adi_dcb_Open(
					14, 
    				DCBMgrQueue1, 
					SIZE_DCB, 
					&ResponseCount, 
					&adi_dcb_QueueHandle
					);
	if (result) 
	    exit(1);
}

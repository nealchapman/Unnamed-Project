/*****************************************************************************
 * A collection of file and directory operations
 *****************************************************************************/
 
#include "harddiskaccess.h"
#include "md5.h"
#include <string.h>

/* binary (arbitrary) data to use for file */
#include "filedata.dat"

static void printDirEntry(FILE *fp, struct dirent *pDirEntry);
static void printVolumeInfo(FILE *fp, ADI_FSS_VOLUME_INFO *pPartition);

/*****************************************************************************
 * ListDirectory
 *		Lists the contents of the named directory to STDOUT 
 *****************************************************************************/
u32 ListDirectory( char *dirname )
{
	u32 Result = ADI_FSS_RESULT_SUCCESS;
    struct dirent *pDirEntry;
    	
	DIR *pDir = opendir(dirname);
	if (pDir) {
		do {
		    pDirEntry = readdir(pDir);
		    if (pDirEntry)
		        printDirEntry(stdout, pDirEntry);
		} while (pDirEntry);
	
		closedir(pDir);
	} 
	else {
		Result = ADI_FSS_RESULT_FAILED;
	}
	return Result;
}

/*****************************************************************************
 * CreateFile
 *		Opens a file and writes a binary stream to it
 *****************************************************************************/
u32 CreateFile( char *filename )
{
	u32 Result = ADI_FSS_RESULT_SUCCESS;
	FILE *fp = fopen(filename, "wb");
	if (fp) {
		int n;
		fwrite( FileData, sizeof(u32), sizeof(FileData)/sizeof(u32), fp );
		fclose(fp);
	} else {
		Result = ADI_FSS_RESULT_FAILED;
	}
	return Result;
}

/*****************************************************************************
 * CheckFile
 *		performs an MD5 checksum calculation on the named file and 
 *		compares it to the given value.
 *****************************************************************************/
u32 CheckFile( char *filename )	
{
	u32 Result = ADI_FSS_RESULT_SUCCESS;
	char *pSum = md5_ComputeSumForFile(filename);
	if (pSum) {
	    printf("MD5 Checksum of %s = %s\n", filename, pSum);
		if ( !strcmp(pSum, FileChecksum) ) {
			printf("Checksum matches\n");
		}
		else {
			Result = ADI_FSS_RESULT_FAILED;
		}
	} 
	else {
		Result = ADI_FSS_RESULT_FAILED;
	}
	return Result;
}

/*****************************************************************************
 * ShowVolumes
 *		Reports on the volumes/partitions available 
 *****************************************************************************/
void ShowVolumes(FILE *fp)
{
    ADI_FSS_VOLUME_INFO Volume;
    
    Volume.Index=0;
    while (adi_fss_Control(
        ADI_FSS_CMD_GET_VOLUME_INFO,
        (void*)&Volume)==ADI_FSS_RESULT_SUCCESS)
    {
        printVolumeInfo(fp,&Volume);
        Volume.Index++;
    }
}

/*****************************************************************************
 * printDirEntry
 *		Writes the details of  single directory entry
 *****************************************************************************/
static void printDirEntry(FILE *fp, struct dirent *pDirEntry)
{
	char str[80];
	
	if (pDirEntry->d_type == DT_DIR)
	    fprintf(fp, "d");
	else
	    fprintf(fp, "f");
	
	fprintf(fp, "\t%10d", pDirEntry->d_size);
	    
	strftime(str,80,"%b %d %Y %H:%M:%S",&pDirEntry->DateModified);
	fprintf(fp,"  %s",str);
	fprintf(fp, "\t%s ", pDirEntry->d_name);
	fprintf(fp,"\n");

}

/*****************************************************************************
 * printVolumeInfo
 *		Writes the details of a single volume/partition
 *****************************************************************************/
static void printVolumeInfo(FILE *fp, ADI_FSS_VOLUME_INFO *pPartition)
{
	u32 i;
	u32 mbytes = pPartition->size;
	char label[40], type[40];
	for (i=0;pPartition->label[i]!=0;i++) {
	    label[i] = pPartition->label[i];
	}
	label[i] = '\0';
	for (i=0;pPartition->type[i]!=0;i++) {
	    type[i] = pPartition->type[i];
	}
	type[i] = '\0';
	fprintf(fp,"Drive %c: label=%s, size=%6dMB, type=%s\n",pPartition->Ident, label, mbytes, type);
}


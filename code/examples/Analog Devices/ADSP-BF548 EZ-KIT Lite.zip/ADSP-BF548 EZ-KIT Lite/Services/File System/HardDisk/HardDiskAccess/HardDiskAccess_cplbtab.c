/* MANAGED-BY-SYSTEM-BUILDER                                    */

/*
** CPLB table definitions generated on Aug 24, 2007 at 15:20:54.
**
** Copyright (C) 2000-2007 Analog Devices Inc., All Rights Reserved.
**
** This file is generated automatically based upon the options selected
** in the LDF Wizard. Changes to the LDF configuration should be made by
** changing the appropriate options rather than editing this file.
**
** Configuration:-
**     crt_doj:                                .\Debug\HardDiskAccess_basiccrt.doj
**     processor:                              ADSP-BF548
**     si_revision:                            automatic
**     cplb_init_cplb_ctrl:                    127
**     cplb_init_dcache_ctrl:                  dcache_wt
**     cplb_init_cplb_src_file:                C:\Build Tools\nightly_build\cvsStage\_5.0ExportBlackfinReGen\Examples\Blackfin\Examples\ADSP-BF548 EZ-KIT Lite\Services\File System\HardDisk\HardDiskAccess\HardDiskAccess_cplbtab.c
**     cplb_init_cplb_obj_file:                .\Debug\HardDiskAccess_cplbtab.doj
**     using_cplusplus:                        true
**     mem_init:                               false
**     use_vdk:                                false
**     use_eh:                                 true
**     use_argv:                               false
**     running_from_internal_memory:           true
**     user_heap_src_file:                     C:\Build Tools\nightly_build\cvsStage\_5.0ExportBlackfinReGen\Examples\Blackfin\Examples\ADSP-BF548 EZ-KIT Lite\Services\File System\HardDisk\HardDiskAccess\HardDiskAccess_heaptab.c
**     libraries_use_stdlib:                   true
**     libraries_use_fileio_libs:              false
**     libraries_use_ieeefp_emulation_libs:    false
**     libraries_use_eh_enabled_libs:          false
**     system_heap:                            L3
**     system_heap_min_size:                   2K
**     system_stack:                           L3
**     system_stack_min_size:                  2K
**     use_sdram:                              true
**     use_sdram_size:                         64M
**     use_sdram_partitioned:                  default
**     num_user_heaps:                         1
**     user_heap0:                             L3
**     user_heap0_size:                        4M
**     user_heap0_heap_name:                   FSSGeneralHeap
**
*/

#ifdef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress:misra_rule_2_2)
#pragma diag(suppress:misra_rule_8_10)
#pragma diag(suppress:misra_rule_10_1_a)
#endif /* _MISRA_RULES */


#define CACHE_MEM_MODE CPLB_DDOCACHE_WT



#include <sys/platform.h>
#include <cplbtab.h>

#pragma section("cplb_data")

cplb_entry dcplbs_table[] = {



/*$VDSG<customisable-data-cplb-table>                           */
/* This code is preserved if the CPLB tables are re-generated.  */


   // L1 Data A & B, (set write-through bit to avoid 1st write exceptions)
   {0xFF800000, (PAGE_SIZE_4MB | CPLB_DNOCACHE | CPLB_LOCK | CPLB_WT)}, 

      // L2 SRAM - possible stack use so locked 
   {0xFEB00000, (PAGE_SIZE_1MB | CPLB_DNOCACHE | CPLB_LOCK)}, 

      // 512 MB (Maximum) DDR1 memory space 
   {0x00000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE | CPLB_LOCK)}, 
   {0x00400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE | CPLB_LOCK)}, 
   {0x00800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE | CPLB_LOCK)}, 
   {0x00C00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE | CPLB_LOCK)}, 
   
   // CPLBs covering 48MB
   {0x01000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x01400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x01800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x01c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x02000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x02400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x02800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x02c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   
   /* ---------------------------------------------------------------
    * The following page is set aside for the FSS Heap and since it 
    * will be used for DMA buffers, the cache is disabled.
    */
   {0x03000000, (PAGE_SIZE_4MB | CPLB_DNOCACHE)},
   /* ---------------------------------------------------------------
    */
   {0x03400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x03800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x03c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},

   // Async Memory Bank 3
   
   // CPLBs covering 64MB
   {0x2fc00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x30000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x30400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x30800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x30c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x31000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x31400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x31800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x31c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x32000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x32400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x32800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x32c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x33000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x33400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x33800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},

   // Async Memory Bank 2
   
   // CPLBs covering 64MB
   {0x2bc00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2c000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2c400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2c800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2cc00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2d000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2d400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2d800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2dc00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2e000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2e400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2e800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2ec00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2f000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2f400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2f800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},

   // Async Memory Bank 1
   
   // CPLBs covering 64MB
   {0x27c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x28000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x28400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x28800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x28c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x29000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x29400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x29800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x29c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2a000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2a400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2a800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2ac00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2b000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2b400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x2b800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},

   // Async Memory Bank 0
   
   // CPLBs covering 64MB
   {0x23c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x24000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x24400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x24800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x24c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x25000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x25400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x25800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x25c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x26000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x26400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x26800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x26c00000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x27000000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x27400000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},
   {0x27800000, (PAGE_SIZE_4MB | CACHE_MEM_MODE)},

   // end of section - termination
   {0xffffffff, 0}, 
/*$VDSG<customisable-data-cplb-table>                           */


}; /* dcplbs_table */

cplb_entry icplbs_table[] = {



/*$VDSG<customisable-instr-cplb-table>                          */
/* This code is preserved if the CPLB tables are re-generated.  */


   // L1 Code
   {0xFFA00000, (PAGE_SIZE_1MB | CPLB_I_PAGE_MGMT)}, 

   // L2 Code
   {0xFEB00000, (PAGE_SIZE_1MB | CPLB_IDOCACHE)}, 

   // 512 MB (Maximum) DDR1 memory space 
   
   // CPLBs covering 64MB
   {0x00000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x00400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x00800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x00c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x01000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x01400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x01800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x01c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x02000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x02400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x02800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x02c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x03000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x03400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x03800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x03c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},

   // Async Memory Bank 3
   
   // CPLBs covering 64MB
   {0x2fc00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x30000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x30400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x30800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x30c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x31000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x31400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x31800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x31c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x32000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x32400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x32800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x32c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x33000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x33400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x33800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},

   // Async Memory Bank 2
   
   // CPLBs covering 64MB
   {0x2bc00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2c000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2c400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2c800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2cc00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2d000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2d400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2d800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2dc00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2e000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2e400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2e800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2ec00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2f000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2f400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2f800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},

   // Async Memory Bank 1
   
   // CPLBs covering 64MB
   {0x27c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x28000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x28400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x28800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x28c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x29000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x29400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x29800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x29c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2a000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2a400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2a800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2ac00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2b000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2b400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x2b800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},

   // Async Memory Bank 0
   
   // CPLBs covering 64MB
   {0x23c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x24000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x24400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x24800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x24c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x25000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x25400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x25800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x25c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x26000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x26400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x26800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x26c00000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x27000000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x27400000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},
   {0x27800000, (PAGE_SIZE_4MB | CPLB_IDOCACHE)},

   // end of section - termination
   {0xffffffff, 0}, 
/*$VDSG<customisable-instr-cplb-table>                          */


}; /* icplbs_table */


#ifdef _MISRA_RULES
#pragma diag(pop)
#endif /* _MISRA_RULES */


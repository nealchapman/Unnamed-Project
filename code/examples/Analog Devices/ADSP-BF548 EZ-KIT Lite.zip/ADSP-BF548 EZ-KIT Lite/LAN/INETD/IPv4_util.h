extern char* IPv4_straddr(unsigned long a);

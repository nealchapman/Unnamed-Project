// DlgProxy.h : header file
//

#if !defined(AFX_DLGPROXY_H__146A4872_72C8_4FC4_8B84_4525E3511E8B__INCLUDED_)
#define AFX_DLGPROXY_H__146A4872_72C8_4FC4_8B84_4525E3511E8B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFileServerDlg;

/////////////////////////////////////////////////////////////////////////////
// CFileServerDlgAutoProxy command target

class CFileServerDlgAutoProxy : public CCmdTarget
{
	DECLARE_DYNCREATE(CFileServerDlgAutoProxy)

	CFileServerDlgAutoProxy();           // protected constructor used by dynamic creation

// Attributes
public:
	CFileServerDlg* m_pDialog;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileServerDlgAutoProxy)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFileServerDlgAutoProxy();

	// Generated message map functions
	//{{AFX_MSG(CFileServerDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CFileServerDlgAutoProxy)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CFileServerDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPROXY_H__146A4872_72C8_4FC4_8B84_4525E3511E8B__INCLUDED_)

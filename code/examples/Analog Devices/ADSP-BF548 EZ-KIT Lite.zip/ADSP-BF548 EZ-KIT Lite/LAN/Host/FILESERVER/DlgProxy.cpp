// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "FileServer.h"
#include "DlgProxy.h"
#include "FileServerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileServerDlgAutoProxy

IMPLEMENT_DYNCREATE(CFileServerDlgAutoProxy, CCmdTarget)

CFileServerDlgAutoProxy::CFileServerDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CFileServerDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CFileServerDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CFileServerDlgAutoProxy::~CFileServerDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CFileServerDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CFileServerDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CFileServerDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CFileServerDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CFileServerDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IFileServer to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {109E8C3D-4A46-49EF-B46F-4440497952C2}
static const IID IID_IFileServer =
{ 0x109e8c3d, 0x4a46, 0x49ef, { 0xb4, 0x6f, 0x44, 0x40, 0x49, 0x79, 0x52, 0xc2 } };

BEGIN_INTERFACE_MAP(CFileServerDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CFileServerDlgAutoProxy, IID_IFileServer, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {C2A59FC7-4EAF-4DC3-AE35-8B084A7DE2CB}
IMPLEMENT_OLECREATE2(CFileServerDlgAutoProxy, "FileServer.Application", 0xc2a59fc7, 0x4eaf, 0x4dc3, 0xae, 0x35, 0x8b, 0x8, 0x4a, 0x7d, 0xe2, 0xcb)

/////////////////////////////////////////////////////////////////////////////
// CFileServerDlgAutoProxy message handlers

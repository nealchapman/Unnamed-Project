//Microsoft Developer Studio generated resource script.
//
#include "resource.h"

// Generated Help ID header file
#define APSTUDIO_HIDDEN_SYMBOLS
#include "resource.hm"
#undef APSTUDIO_HIDDEN_SYMBOLS

#define APSTUDIO_READONLY_SYMBOLS
/////////////////////////////////////////////////////////////////////////////
//
// Generated from the TEXTINCLUDE 2 resource.
//
#include "afxres.h"

/////////////////////////////////////////////////////////////////////////////
#undef APSTUDIO_READONLY_SYMBOLS

/////////////////////////////////////////////////////////////////////////////
// English (U.S.) resources

#if !defined(AFX_RESOURCE_DLL) || defined(AFX_TARG_ENU)
#ifdef _WIN32
LANGUAGE LANG_ENGLISH, SUBLANG_ENGLISH_US
#pragma code_page(1252)
#endif //_WIN32

#ifdef APSTUDIO_INVOKED
/////////////////////////////////////////////////////////////////////////////
//
// TEXTINCLUDE
//

1 TEXTINCLUDE MOVEABLE PURE 
BEGIN
    "resource.h\0"
END

2 TEXTINCLUDE MOVEABLE PURE 
BEGIN
    "#include ""afxres.h""\r\n"
    "\0"
END

3 TEXTINCLUDE MOVEABLE PURE 
BEGIN
    "#define _AFX_NO_SPLITTER_RESOURCES\r\n"
    "#define _AFX_NO_OLE_RESOURCES\r\n"
    "#define _AFX_NO_TRACKER_RESOURCES\r\n"
    "#define _AFX_NO_PROPERTY_RESOURCES\r\n"
    "\r\n"
    "#if !defined(AFX_RESOURCE_DLL) || defined(AFX_TARG_ENU)\r\n"
    "#ifdef _WIN32\r\n"
    "LANGUAGE 9, 1\r\n"
    "#pragma code_page(1252)\r\n"
    "#endif //_WIN32\r\n"
    "#include ""res\\FileServer.rc2""  // non-Microsoft Visual C++ edited resources\r\n"
    "#include ""afxres.rc""         // Standard components\r\n"
    "#endif\r\n"
    "\0"
END

#endif    // APSTUDIO_INVOKED


/////////////////////////////////////////////////////////////////////////////
//
// Icon
//

// Icon with lowest ID value placed first to ensure application icon
// remains consistent on all systems.
IDR_MAINFRAME           ICON    DISCARDABLE     "res\\FileServer.ico"

/////////////////////////////////////////////////////////////////////////////
//
// Dialog
//

IDD_ABOUTBOX DIALOG DISCARDABLE  0, 0, 235, 55
STYLE DS_MODALFRAME | WS_POPUP | WS_CAPTION | WS_SYSMENU
CAPTION "About FileServer"
FONT 8, "MS Sans Serif"
BEGIN
    ICON            IDR_MAINFRAME,IDC_STATIC,11,17,20,20
    LTEXT           "FileServer Version 1.0",IDC_STATIC,40,10,119,8,
                    SS_NOPREFIX
    LTEXT           "Copyright (C) 2003",IDC_STATIC,40,25,119,8
    DEFPUSHBUTTON   "OK",IDOK,178,7,50,14,WS_GROUP
END

IDD_FILESERVER_DIALOG DIALOGEX 0, 0, 423, 356
STYLE DS_MODALFRAME | WS_POPUP | WS_VISIBLE | WS_CAPTION | WS_SYSMENU
EXSTYLE WS_EX_APPWINDOW
CAPTION "TCP/IP File Server"
FONT 8, "MS Sans Serif"
BEGIN
    EDITTEXT        IDC_PORTNUMBER,216,31,78,14,ES_AUTOHSCROLL
    PUSHBUTTON      "Change port number",IDC_ACTION,314,31,78,14
    EDITTEXT        IDC_PATH,215,59,152,14,ES_AUTOHSCROLL
    CONTROL         "List1",IDC_FILELIST,"SysListView32",LVS_REPORT | 
                    WS_BORDER | WS_TABSTOP,25,166,373,70,0,HIDC_FILELIST
    DEFPUSHBUTTON   "Exit",IDOK,26,335,50,14
    DEFPUSHBUTTON   "Clear",IDC_CLEAR,350,335,50,14
    RTEXT           "Number of open files:",IDC_STATIC,128,86,82,8
    RTEXT           "Listen on port number:",IDC_STATIC,129,34,82,8
    LTEXT           "A - file currently being accessed",IDC_STATIC,95,122,
                    116,11
    LTEXT           "C - file access completed OK",IDC_STATIC,94,137,116,11
    GROUPBOX        "Meaning of Sts column",IDC_STATIC,62,100,299,58
    LTEXT           "R - atttempt to open the file rejected.",IDC_STATIC,215,
                    122,116,11
    LTEXT           "F - failed while reading or writing the file",
                    IDC_STATIC,214,138,132,14
    RTEXT           "Path to be prepended to all filenames:",IDC_STATIC,77,
                    61,134,8
    LISTBOX         IDC_CONSOLE,24,258,373,67,LBS_NOINTEGRALHEIGHT | 
                    LBS_NOSEL | WS_VSCROLL | WS_HSCROLL | WS_TABSTOP
    CTEXT           "Console",IDC_STATIC,183,246,61,8
    RTEXT           "IP address for this host:",IDC_STATIC,106,15,105,8
    LTEXT           "?",m_LocalIP,215,14,79,8
    LTEXT           "0",IDC_NUMFILES1,214,86,77,8
END


#ifndef _MAC
/////////////////////////////////////////////////////////////////////////////
//
// Version
//

VS_VERSION_INFO VERSIONINFO
 FILEVERSION 1,0,0,1
 PRODUCTVERSION 1,0,0,1
 FILEFLAGSMASK 0x3fL
#ifdef _DEBUG
 FILEFLAGS 0x1L
#else
 FILEFLAGS 0x0L
#endif
 FILEOS 0x4L
 FILETYPE 0x1L
 FILESUBTYPE 0x0L
BEGIN
    BLOCK "StringFileInfo"
    BEGIN
        BLOCK "040904B0"
        BEGIN
            VALUE "FileDescription", "FileServer MFC Application\0"
            VALUE "FileVersion", "1, 0, 0, 1\0"
            VALUE "InternalName", "FileServer\0"
            VALUE "LegalCopyright", "Copyright (C) 2003\0"
            VALUE "OriginalFilename", "FileServer.EXE\0"
            VALUE "ProductName", "FileServer Application\0"
            VALUE "ProductVersion", "1, 0, 0, 1\0"
        END
    END
    BLOCK "VarFileInfo"
    BEGIN
        VALUE "Translation", 0x409, 1200
    END
END

#endif    // !_MAC


/////////////////////////////////////////////////////////////////////////////
//
// DESIGNINFO
//

#ifdef APSTUDIO_INVOKED
GUIDELINES DESIGNINFO MOVEABLE PURE 
BEGIN
    IDD_ABOUTBOX, DIALOG
    BEGIN
        LEFTMARGIN, 7
        RIGHTMARGIN, 228
        TOPMARGIN, 7
        BOTTOMMARGIN, 48
    END

    IDD_FILESERVER_DIALOG, DIALOG
    BEGIN
        LEFTMARGIN, 7
        RIGHTMARGIN, 416
        TOPMARGIN, 7
        BOTTOMMARGIN, 349
    END
END
#endif    // APSTUDIO_INVOKED


/////////////////////////////////////////////////////////////////////////////
//
// String Table
//

STRINGTABLE DISCARDABLE 
BEGIN
    IDP_OLE_INIT_FAILED     "OLE initialization failed.  Make sure that the OLE libraries are the correct version."
    IDS_ABOUTBOX            "&About FileServer..."
    IDP_SOCKETS_INIT_FAILED "Windows sockets initialization failed."
    IDS_SOCKCREATION        "Failed to create a socket to listen on."
    IDS_BINDFAIL            "Failed to bind to the specified port number."
    IDS_LISTENFAILED        "Failed to listen on the speciifed port numer."
    IDS_ACCEPTFAIL          "Accept failed with error "
    IDS_THREADFAIL          "Failed to create a thread to respond to incoming connection"
    IDS_INVPORTNO           "The supplied port number is invalid"
END

#endif    // English (U.S.) resources
/////////////////////////////////////////////////////////////////////////////



#ifndef APSTUDIO_INVOKED
/////////////////////////////////////////////////////////////////////////////
//
// Generated from the TEXTINCLUDE 3 resource.
//
#define _AFX_NO_SPLITTER_RESOURCES
#define _AFX_NO_OLE_RESOURCES
#define _AFX_NO_TRACKER_RESOURCES
#define _AFX_NO_PROPERTY_RESOURCES

#if !defined(AFX_RESOURCE_DLL) || defined(AFX_TARG_ENU)
#ifdef _WIN32
LANGUAGE 9, 1
#pragma code_page(1252)
#endif //_WIN32
#include "res\FileServer.rc2"  // non-Microsoft Visual C++ edited resources
#include "afxres.rc"         // Standard components
#endif

/////////////////////////////////////////////////////////////////////////////
#endif    // not APSTUDIO_INVOKED


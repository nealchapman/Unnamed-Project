// FileServerDlg.h : header file
//

#if !defined(AFX_FILESERVERDLG_H__3995C6A2_A7E7_459F_A82C_72F36B46F49B__INCLUDED_)
#define AFX_FILESERVERDLG_H__3995C6A2_A7E7_459F_A82C_72F36B46F49B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFileServerDlgAutoProxy;

/////////////////////////////////////////////////////////////////////////////
// CFileServerDlg dialog

class CFileServerDlg : public CDialog
{
	DECLARE_DYNAMIC(CFileServerDlg);
	friend class CFileServerDlgAutoProxy;

// Construction
public:
	CFileServerDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CFileServerDlg();

// Dialog Data
	//{{AFX_DATA(CFileServerDlg)
	enum { IDD = IDD_FILESERVER_DIALOG };
	CStatic	m_NumFilesCtrl;
	CStatic	m_LocalIPCtrl;
	CListBox	m_ConsoleCtrl;
	CButton	m_ClearCtrl;
	CEdit	m_PathCtrl;
	CButton	m_ActionCtrl;
	CEdit	m_PortNumberCtrl;
	CListCtrl	m_FileListCtrl;
	UINT	m_PortNumber;
	CString	m_Path;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileServerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFileServerDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();


public:
	DWORD			m_threadid;
	HANDLE			m_Thread;
	CString			m_CurPort;
	CString			m_LeftOver;
	int				m_NumFiles;

	inline void IncFiles(void)
	{
		char vl[64];

		InterlockedIncrement((long *)&m_NumFiles);
		itoa(m_NumFiles,vl,10);
		m_NumFilesCtrl.SetWindowText(vl);

	}

	inline void DecFiles(void)
	{
		char vl[64];

		InterlockedDecrement((long *)&m_NumFiles);
		itoa(m_NumFiles,vl,10);
		m_NumFilesCtrl.SetWindowText(vl);

	}


	// Generated message map functions
	//{{AFX_MSG(CFileServerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnAction();
	afx_msg void OnChangePortnumber();
	afx_msg void OnClear();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILESERVERDLG_H__3995C6A2_A7E7_459F_A82C_72F36B46F49B__INCLUDED_)

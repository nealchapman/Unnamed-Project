// Microsoft Developer Studio generated Help ID include file.
// Used by FileServer.rc
//
#define HIDC_FILELIST                   0x806603ea    // IDD_FILESERVER_DIALOG

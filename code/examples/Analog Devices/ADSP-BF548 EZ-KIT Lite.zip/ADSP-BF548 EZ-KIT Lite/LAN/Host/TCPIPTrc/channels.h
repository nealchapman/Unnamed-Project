#ifndef _BTC_CHANNELS_H
#define _BTC_CHANNELS_H


typedef enum CHANNEL_ERRORS {
	CHNL_NOTREADY		= -1,
	CHNL_OK				= 0,
	CHNL_INV_PARAM		= 1,
	CHNL_NOT_OPEN		= 2,
	CHNL_ALREADY_OPEN	= 3,
	CHNL_ABORTED		= 4,
	CHNL_INV_DIRN		= 5,
	CHNL_CLOSING		= 6,
	CHNL_NOLINK			= 7,
	CHNL_NOVDSP			= 8,
	CHNL_INVSEQ			= 9,
	CHNL_COMM			= 10,
	CHNL_NOMEM			= 11
} CHANNEL_ERRORS;


#ifndef _BTC_CHANNELS_H_EXPORT

#ifdef __cplusplus
extern "C" {            /* Assume C declarations for C++ */
#endif    /* __cplusplus */

__declspec( dllimport ) int BtcOpen(int channelno, int transmit, HANDLE hTag);
__declspec( dllimport ) int BtcWrite(int channelno, int nobytes, const char *data, int *nosent);
__declspec( dllimport ) int BtcRead(int channelno, int nobytes, char *data, int *noread);
__declspec( dllimport ) int BtcClose(int channelno, int abort);
__declspec( dllimport ) int BtcPollTime(int channelno,  unsigned int polltime);
__declspec( dllimport ) int BtcDataReady(void);
__declspec( dllimport ) int BtcActivate(int Start);


#ifdef __cplusplus
}
#endif    /* __cplusplus */


#endif

#endif
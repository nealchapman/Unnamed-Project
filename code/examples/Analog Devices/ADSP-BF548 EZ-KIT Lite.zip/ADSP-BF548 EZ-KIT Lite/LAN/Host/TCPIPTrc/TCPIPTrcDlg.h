// TCPIPTrcDlg.h : header file
//

#if !defined(AFX_TCPIPTRCDLG_H__FBDE89CE_E29F_4B91_A313_973F2F24F95D__INCLUDED_)
#define AFX_TCPIPTRCDLG_H__FBDE89CE_E29F_4B91_A313_973F2F24F95D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTCPIPTrcDlgAutoProxy;

#define MAX_HOST_NAME 128    
typedef struct HostMapping {
	int		IpAddrs;
	const char	*HostName;
} HostMapping;


typedef struct TraceLine {
	struct TraceLine		*Next;
	int						Mark;
	char					*Data;
} TraceLine;

/////////////////////////////////////////////////////////////////////////////
// CTCPIPTrcDlg dialog

class CTCPIPTrcDlg : public CDialog
{
	DECLARE_DYNAMIC(CTCPIPTrcDlg);
	friend class CTCPIPTrcDlgAutoProxy;

// Construction
public:
	CTCPIPTrcDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CTCPIPTrcDlg();

// Dialog Data
	//{{AFX_DATA(CTCPIPTrcDlg)
	enum { IDD = IDD_TCPIPTRC_DIALOG };
	CStatic	m_ReportCtrl;
	CStatic	m_LocalIPCtrl;
	CEdit	m_ChannelCtrl;
	CButton	m_StopAcqCtrl;
	CButton	m_StartAcqCtrl;
	CButton	m_SaveFileCtrl;
	CButton	m_SaveCurCtrl;
	CButton	m_SaveAllCtrl;
	CButton	m_PauseCtrl;
	CEdit	m_NoEventsCtrl;
	CEdit	m_FileNameCtrl;
	CListBox	m_EventListCtrl;
	CString	m_FileName;
	BOOL	m_SaveAll;
	UINT	m_Channel;
	long	m_NoEvents;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTCPIPTrcDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	bool			m_Paused;
	bool			m_Continue;
	bool			m_StopAcquiring;
	bool			m_Stopped;
	int				m_NoHostNames;
	int				m_LastNdx;
	HostMapping		m_HostMap[MAX_HOST_NAME];
	char			m_StrBuffer[2049];
	long			m_TrcIndex;
	long			m_NoEntries;
	TraceLine		*m_TraceHead,*m_TraceTail;
	long			m_TraceListSize;
	CRITICAL_SECTION m_Critical;
	FILE			*m_Trc;
	char			m_SaveAlFileName[512];
	SOCKET			m_Listen;
	SOCKET			m_Client;
	void Stop(void);

	char *ResToText(int res);
	void Recv(void);
	void TcpRecv(void);
	void AppendLine(void);
	void TidyUp(void);

	char * FindHostName(int IpAddrs, char *bf);
	void  DumpIPTraceEntry(
		unsigned char id, int nbytes, unsigned short clk,
		unsigned char *hdr);
	void  DumpDefTraceEntry(
		unsigned char id, int nbytes, unsigned short clk,
		unsigned char *hdr);
	void  DumpTraceEntry(
		unsigned char *hdr);
	void  DumpArpTraceEntry(
		unsigned char id, int nbytes, unsigned short clk,
		unsigned char *hdr);

protected:
	CTCPIPTrcDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CTCPIPTrcDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnHelp();
	afx_msg void OnChangeFilename();
	afx_msg void OnChangeNoevents();
	afx_msg void OnPause();
	afx_msg void OnSavecur();
	afx_msg void OnSavefile();
	afx_msg void OnStartacq();
	afx_msg void OnStopacq();
	afx_msg void OnBrowse();
	afx_msg void OnChangeChannel();
	afx_msg void OnSaveall();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#define ICMP_PROTOCOL           1
#define TCP_PROTOCOL            6
#define UDP_PROTOCOL            17

typedef struct datagram {
	unsigned char		VersHlen;
	unsigned char		SrvType;
	unsigned short		TotalLnth;
	unsigned short		Ident;
	unsigned short		FlagsFragOffset;
	unsigned char		TTL;
	unsigned char		Protocol;
	unsigned short		HdrChecksum;
	unsigned int		Source;
	unsigned int		Dest;
} datagram;

typedef struct udp {
	unsigned short		SrcPort;
	unsigned short		DstPort;
	unsigned short		MsgLnth;
	unsigned short      Checksum;
} udp;

#define TCPF_FIN     0x01	/* FIN - to close connection */
#define TCPF_SYN     0x02	/* SYN - to open connection */
#define TCPF_RST     0x04	/* RST - to reset connection - abort */
#define TCPF_PSH     0x08	/* PSH - to push rcvd data to application */
#define TCPF_ACK     0x10	/* ACK - AckNum is valid */
#define TCPF_URG     0x20	/* URG - Urgent ptr is valid */


typedef struct tcp {
	unsigned short		SrcPort;
	unsigned short		DstPort;
	unsigned int		SeqNo;
	unsigned int		AckNo;
	unsigned char		Hlen;
	unsigned char		Code;
	unsigned short		Window;
	unsigned short		Checksum;
	unsigned short		UrgPtr;
	
} tcp;

typedef struct icmp {
	unsigned char		Type;
	unsigned char		Qual;
	unsigned short		Checksum;
} icmp;


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TCPIPTRCDLG_H__FBDE89CE_E29F_4B91_A313_973F2F24F95D__INCLUDED_)

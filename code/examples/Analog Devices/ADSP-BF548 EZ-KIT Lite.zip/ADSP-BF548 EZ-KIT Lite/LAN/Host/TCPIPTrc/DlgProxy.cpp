// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "TCPIPTrc.h"
#include "DlgProxy.h"
#include "TCPIPTrcDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTCPIPTrcDlgAutoProxy

IMPLEMENT_DYNCREATE(CTCPIPTrcDlgAutoProxy, CCmdTarget)

CTCPIPTrcDlgAutoProxy::CTCPIPTrcDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CTCPIPTrcDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CTCPIPTrcDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CTCPIPTrcDlgAutoProxy::~CTCPIPTrcDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CTCPIPTrcDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CTCPIPTrcDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CTCPIPTrcDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CTCPIPTrcDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CTCPIPTrcDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ITCPIPTrc to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {3B34DCDE-2E7D-4886-A53C-62C9CF711A5B}
static const IID IID_ITCPIPTrc =
{ 0x3b34dcde, 0x2e7d, 0x4886, { 0xa5, 0x3c, 0x62, 0xc9, 0xcf, 0x71, 0x1a, 0x5b } };

BEGIN_INTERFACE_MAP(CTCPIPTrcDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CTCPIPTrcDlgAutoProxy, IID_ITCPIPTrc, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {FD674D3D-9A7D-4E9C-BD2A-A66368B2F96D}
IMPLEMENT_OLECREATE2(CTCPIPTrcDlgAutoProxy, "TCPIPTrc.Application", 0xfd674d3d, 0x9a7d, 0x4e9c, 0xbd, 0x2a, 0xa6, 0x63, 0x68, 0xb2, 0xf9, 0x6d)

/////////////////////////////////////////////////////////////////////////////
// CTCPIPTrcDlgAutoProxy message handlers

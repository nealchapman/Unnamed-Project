// DlgProxy.h : header file
//

#if !defined(AFX_DLGPROXY_H__BADDB13D_22C4_487F_809B_3C86CAA9D48A__INCLUDED_)
#define AFX_DLGPROXY_H__BADDB13D_22C4_487F_809B_3C86CAA9D48A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTCPIPTrcDlg;

/////////////////////////////////////////////////////////////////////////////
// CTCPIPTrcDlgAutoProxy command target

class CTCPIPTrcDlgAutoProxy : public CCmdTarget
{
	DECLARE_DYNCREATE(CTCPIPTrcDlgAutoProxy)

	CTCPIPTrcDlgAutoProxy();           // protected constructor used by dynamic creation

// Attributes
public:
	CTCPIPTrcDlg* m_pDialog;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTCPIPTrcDlgAutoProxy)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CTCPIPTrcDlgAutoProxy();

	// Generated message map functions
	//{{AFX_MSG(CTCPIPTrcDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CTCPIPTrcDlgAutoProxy)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CTCPIPTrcDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPROXY_H__BADDB13D_22C4_487F_809B_3C86CAA9D48A__INCLUDED_)

// TCPIPTrc.h : main header file for the TCPIPTRC application
//

#if !defined(AFX_TCPIPTRC_H__93B83348_D883_438C_93CE_3F6E6FF7FACD__INCLUDED_)
#define AFX_TCPIPTRC_H__93B83348_D883_438C_93CE_3F6E6FF7FACD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTCPIPTrcApp:
// See TCPIPTrc.cpp for the implementation of this class
//

class CTCPIPTrcApp : public CWinApp
{
public:
	CTCPIPTrcApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTCPIPTrcApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTCPIPTrcApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TCPIPTRC_H__93B83348_D883_438C_93CE_3F6E6FF7FACD__INCLUDED_)

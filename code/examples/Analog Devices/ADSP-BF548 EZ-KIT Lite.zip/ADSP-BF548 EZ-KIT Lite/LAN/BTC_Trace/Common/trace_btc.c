#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <btc.h>

#include "..\Common\trace_int.h"



extern int _btc_nNumBtcMapEntries;
extern _BTC_MAP_DATA _btc_map[];


//#################################################################
//		TracePoll
//#################################################################
void TracePoll(TraceInfo *trc)
{
	int il;
	
	btc_poll();
	if (trc->m_BytesSent >0) {
		// the host has been notified to read the data
		if (trc->m_TrcData->NoTrcBytes == 0) {
			// the data has been read
			il = trc->m_NxtByte - trc->m_BytesSent;
			if (il > 0) {
				// we have some data to be moved down
				memcpy(trc->m_TrcData->TrcBytes,trc->m_TrcData->TrcBytes+trc->m_BytesSent,il);
				trc->m_NxtByte -= il;				
			}
			trc->m_BytesSent = 0;
		}
	}
}


//#################################################################
//		TraceWrite
//#################################################################
void TraceWrite(TraceInfo *trc)
{
	// it maybe sensible to tell the host to get some data
	if (trc->m_TrcData->NoTrcBytes == 0) {
		// tell the host to initiate reading
		trc->m_BytesSent = trc->m_NxtByte;
		trc->m_TrcData->NoTrcBytes = trc->m_NxtByte;
		while (trc->m_TrcData->NoTrcBytes >0) {
			TracePoll(trc);
			if (trc->m_TrcData->Active == 0) {
				trc->m_TrcData->NoTrcBytes=0; // act as if the data has been read
				trc->m_NxtByte = 0;
				trc->m_BytesSent = 0;
			}
		}
	}
	TracePoll(trc);
}


//#################################################################
//		TraceEmpty
//#################################################################
void TraceEmpty(TraceInfo *trc)
{
	// we have to wait till the there is at least room for one trace entry
	while (trc->m_NxtByte+trc->m_MaxBytes>=trc->m_BufSize) {
		TraceWrite(trc);
	}
}



//#################################################################
//		TraceInit
//#################################################################
int TraceInit(TraceInfo *trc, char *HostAddr, int portno)
{
   int i,res=1;
   
   // identify the base channel that we are to use
   for (i=0;i<_btc_nNumBtcMapEntries;i++) {
      if (strcmp(HostAddr,_btc_map[i].name) == 0) {
         // we have found the channel
	      _btc_map[i].length =  sizeof(TraceData)+trc->m_BufSize;
	      _btc_map[i].address = (long)trc->m_TrcData;
	      res = 0;
         break;
      }
   }
   
   btc_init();
   return res;
}

//#################################################################
//		TraceMaintain
//#################################################################
void TraceMaintain(TraceInfo *trc)
{
}


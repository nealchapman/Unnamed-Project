#ifndef TRACE_INT_H
#define TRACE_INT_H



typedef struct TraceData {
	unsigned int			Active;				// if non-zero some tracing is active
	unsigned int			ActClasses[8];		// Each bit represents one of 256 trace classes
	unsigned int			MaxTrcBytes;		// maximum number of trace bytes
	unsigned int			NoTrcBytes;			// the no of trace bytes to be read by the host
	unsigned char			TrcBytes[0];		// start of the trace buffer
					
} TraceData;


typedef struct TraceInfo {

	int 				m_Sem;
	int					m_MaxBytes;		// max size of event record
    int					m_BufSize;		// size of buffer
    int					m_NxtByte;		// next byte to be written to in buffer
    int					m_SendNow;		// start trying to send when this number 
    									// of bytes in the buffer
    int					m_CyclesPerMS;
    int					m_BytesSent;	// note the number of bytes being sent to the host
    TraceData			*m_TrcData;		// trace control and data buffer
} TraceInfo;

void TracePoll(TraceInfo *);
void TraceWrite(TraceInfo *);
void TraceEmpty(TraceInfo *);
int TraceInit(TraceInfo *, char *HostAddr, int portno); // a return of 0 means OK
void TraceMaintain(TraceInfo *trc);

#endif


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ccblkfn.h>
#include <sysreg.h>

#include "trace.h"
#include "trace_int.h"


static TraceInfo TRCINFO;
static TraceInfo *__this = &TRCINFO;

#define NULL_SEM  ker_err_sem_cre

//#################################################################
//		EnterCriticalRegion
//#################################################################
static void EnterCriticalRegion(void)
{
	if (__this->m_Sem != NULL_SEM) {
		ker_pend_semaphore(__this->m_Sem,0);
	}
}

//#################################################################
//		ExitCriticalRegion
//#################################################################
static void ExitCriticalRegion(void)
{
	if (__this->m_Sem != NULL_SEM) {
		ker_post_semaphore(__this->m_Sem);
	} 
}



//#################################################################
//		Trace_Event
//#################################################################
int Trace_Event(
        unsigned char EventId,
        unsigned short NoOfBytes,
        const unsigned char *Data)
{

	int lnth = NoOfBytes+4;
	int ldata;
	int nxt,sent,nob;
	int mr = 0;
	
	//##
	//if (EventId == 'R') Data+=2;
	
	if (__this->m_TrcData->Active==0)  return Trace_DISABLED;
	TracePoll(__this);
	if (__this->m_TrcData->Active==0)  return Trace_DISABLED;

	if (lnth>__this->m_MaxBytes) lnth = __this->m_MaxBytes;
	ldata = (lnth-4)&0xff;
	EnterCriticalRegion();
	if (lnth+__this->m_NxtByte>__this->m_BufSize) {
		// we need to write the current buffer to the channel
		TraceEmpty(__this);
		__this->m_NxtByte = 0;
	}
	if (__this->m_TrcData->Active!=0) {
		// move the event data to the buffer
		unsigned char *bf = __this->m_TrcData->TrcBytes+__this->m_NxtByte;
		*bf++ = EventId;
		*bf++ = ldata;			// timer count?
		*((unsigned short *)bf) = sysreg_read(reg_CYCLES)/__this->m_CyclesPerMS;
		if (ldata>0) {
			memcpy(bf+2,Data,ldata);
		}
		__this->m_NxtByte += lnth;
		// check if we should try and send the data
		if (__this->m_NxtByte>=__this->m_SendNow) {
			TraceWrite(__this);
			
		}
	}
	ExitCriticalRegion();
    return (int)0;
}

//#################################################################
//		Trace_Init
//#################################################################
int Trace_Init(
        int MaxBytes,
        int BufSize,
        char *HostAddr, 
        int portno)
{
	int mr = (int)0;
	int nob;
	unsigned char *Memory;
	TraceData *trc;
	
	
	__this->m_Sem = NULL_SEM;
	/* semaphore has initial and maximum count of 1 */
	__this->m_Sem = ker_get_semaphore(1,1);
	if (__this->m_Sem ==  ker_err_sem_cre) {
		return Trace_NO_RESOURCES;
	}
	BufSize = (BufSize+3)&(~0x3);  // round to a multiple of 4
	if (BufSize<MaxBytes) return Trace_INV_PARAM;
	
	Memory = (unsigned char *)malloc(sizeof(TraceData)+BufSize);
	if (Memory == NULL)  return Trace_NO_MEMORY;
	
	// initialize the trace data
	trc = (TraceData *)Memory;
	trc->Active = 0;							// no tracing going on
	memset(trc->ActClasses,sizeof(trc->ActClasses),0);
	trc->MaxTrcBytes = BufSize;
	trc->NoTrcBytes = 0;						// none to be sent to the host
	
	
	__this->m_MaxBytes = MaxBytes;
	__this->m_BufSize = BufSize;
	__this->m_NxtByte = 0;
	__this->m_SendNow = BufSize/2;
	__this->m_CyclesPerMS = 1;
	__this->m_BytesSent = 0;
	__this->m_TrcData = trc;
	
	mr = TraceInit(__this,HostAddr,portno);
	
	
    return mr;
}


//#################################################################
//		Trace_Activate
//#################################################################
void Trace_Activate(void)
{
	__this->m_TrcData->Active = 0xffffffff;							// alltracing going on
	memset(__this->m_TrcData->ActClasses,0xff,sizeof(__this->m_TrcData->ActClasses));
}

//#################################################################
//		Trace_Poll
//#################################################################
void Trace_Poll(void)
{
	EnterCriticalRegion();
	TracePoll(__this);
	ExitCriticalRegion();
}


//#################################################################
//		Trace_Active
//#################################################################
int Trace_Active(void)
{
	return (__this->m_TrcData!=NULL) && (__this->m_TrcData->Active!=0);
}


//#################################################################
//		Trace_Maintain
//#################################################################
void Trace_Maintain(void)
{
	TraceMaintain(__this);
}


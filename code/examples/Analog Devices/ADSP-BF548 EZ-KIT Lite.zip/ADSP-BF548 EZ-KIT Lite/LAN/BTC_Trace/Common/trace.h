#ifndef TRACE_H
#define TRACE_H


#include "lwip\kernel_abs.h"





#define Trace_DISABLED 				-1

#define Trace_OK					0
#define Trace_FAIL					1
#define Trace_NO_RESOURCES			2	
#define	Trace_NO_MEMORY				3
#define Trace_INV_PARAM				4
#define Trace_OUT_OF_SEQUENCE		5
#define Trace_CONN_CLOSED			6
#define Trace_RESET  				8

#ifdef __ECC__	/* for C/C++ access */
#ifdef __cplusplus
extern "C" {
#endif
#endif	

int Trace_Init(
        int MaxBytes,
        int BufSize,
        char *HostAddr, 
        int portno);
        
int Trace_Event(
        unsigned char EventId,
        unsigned short NoOfBytes,
        const unsigned char *Data);

void Trace_Activate(void);

void Trace_Poll(void);

int Trace_Active(void);

void Trace_Maintain(void);

// Set trace function
void SetTraceFunction( int (*Trace_Event) ( unsigned char EventId, unsigned short NoOfBytes, const unsigned char *Data)); 

#ifdef __ECC__	/* for C/C++ access */
#ifdef __cplusplus
}
#endif
#endif	

#endif

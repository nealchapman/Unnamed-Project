/* =============================================================================
 *
 *  Description: This is a C++ to C Thread Header file for Thread BtcPoller
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

#ifndef _BtcPoller_H_
#define _BtcPoller_H_

#include "VDK.h"

#ifdef __ECC__	/* for C/C++ access */
#ifdef __cplusplus
extern "C" void BtcPoller_InitFunction(void**, VDK::Thread::ThreadCreationBlock *);
#else
extern "C" void BtcPoller_InitFunction(void**, VDK_ThreadCreationBlock *);
#endif
extern "C" void BtcPoller_DestroyFunction(void**);
extern "C" int  BtcPoller_ErrorFunction(void**);
extern "C" void BtcPoller_RunFunction(void**);
#endif /* __ECC__ */

#ifdef __cplusplus
#include <new>

class BtcPoller_Wrapper : public VDK::Thread
{
public:
    BtcPoller_Wrapper(VDK::ThreadCreationBlock &t)
        : VDK::Thread(t)
    { BtcPoller_InitFunction(&m_DataPtr, &t); }

    ~BtcPoller_Wrapper()
    { BtcPoller_DestroyFunction(&m_DataPtr); }

    int ErrorHandler()
    { 
      return BtcPoller_ErrorFunction(&m_DataPtr);
     }

    void Run()
    { BtcPoller_RunFunction(&m_DataPtr); }

    static VDK::Thread* Create(VDK::Thread::ThreadCreationBlock &t)
    { return new (t) BtcPoller_Wrapper(t); }
};

#endif /* __cplusplus */
#endif /* _BtcPoller_H_ */

/* ========================================================================== */

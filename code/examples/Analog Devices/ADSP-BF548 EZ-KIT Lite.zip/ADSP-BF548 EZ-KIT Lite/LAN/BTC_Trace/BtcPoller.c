/* =============================================================================
 *
 *  Description: This is a C implementation for Thread BtcPoller
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

/* Get access to any of the VDK features & datatypes used */
#include <stdio.h>
#include <btc.h>

#include "BtcPoller.h"
#include "Common\trace.h"
#include <services\services.h>
#include <time.h>


BTC_MAP_BEGIN
BTC_MAP_ENTRY("TRACE_DATA_STRUCT",0,1)
BTC_MAP_END



void
BtcPoller_RunFunction(void **inPtr)
{
	int res;
	float per = VDK_GetTickPeriod ();
	int nticks = 100/per;
	clock_t ndtime;
	clock_t period = ((clock_t)CLOCKS_PER_SEC)/2; // 0.5 seconds
	
	
	nticks = 100;
	if (nticks<=0) nticks = 2;
	
	u32 fcclk,fsclk,fvco;
	adi_pwr_GetFreq(&fcclk,&fsclk,&fvco);
	printf("BF548 board running at %dMHz CCLK and %dMHz SCLK\n",fcclk,fsclk);
	
    // we initialise the BTC trace
    
	res = Trace_Init(64,1024,"TRACE_DATA_STRUCT",0); // we are using BTC so no need for port
													 // the hostname gives the name for the BTC element tobe used
	if (res != 0) {
		printf("Tracing over BTC has failed, res =%d\n",res);
		return;
	}
	SetTraceFunction(Trace_Event);
	
	// wait for 0.5 secs to give the PC a chance to activate the tracinf
	ndtime = clock()+period;
	while (clock()<ndtime) {
		Trace_Poll();
	}
    while (1)
    {
		VDK_Sleep(nticks); // sleep for 100 ms;
		Trace_Poll();
    }

    /* Put the thread's exit from "main" HERE */
    /* A thread is automatically Destroyed when it exits its run function */
}

int
BtcPoller_ErrorFunction(void **inPtr)
{

    /* TODO - Put this thread's error handling code HERE */

      /* The default ErrorHandler kills the thread */

	VDK_DestroyThread(VDK_GetThreadID(), false);
	return 0;
}

void
BtcPoller_InitFunction(void **inPtr, VDK_ThreadCreationBlock *pTCB)
{
    /* Put code to be executed when this thread has just been created HERE */

    /* This routine does NOT run in new thread's context.  Any non-static thread
     *   initialization should be performed at the beginning of "Run()."
     */
}

void
BtcPoller_DestroyFunction(void **inPtr)
{
    /* Put code to be executed when this thread is destroyed HERE */

    /* This routine does NOT run in the thread's context.  Any VDK API calls
     *   should be performed at the end of "Run()."
     */
}

/* ========================================================================== */

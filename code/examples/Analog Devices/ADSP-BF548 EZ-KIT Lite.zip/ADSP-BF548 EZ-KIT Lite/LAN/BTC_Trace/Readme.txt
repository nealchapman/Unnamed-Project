#################################################################
#
# Readme.txt file
#
#################################################################

The TCPIP Tracing application provides Windows host support to allow the 
recording of events as they happen and to trace all or some packets as they
are being sent or received by the Blackfin application and stack. This example
uses BTC (Backgroud Telemetry channel) to trasnfer trace infromation from 
blackfin to the host. 

This application consits of a Windows MFC based host program and a Blackfin 
trace program. 

Windows Host program  : <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\Host\TCPIPTrc\TCPIPTrc.exe
Blackfin projects     : <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\BTC_Trace


Instructions to run the program:
-------------------------------
1 Open <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\BTC_Trace\BF5xx project

2. Build,load and run dxe.Once the IP address is printed goto step-3.

3. Run the TCPIPTrc.exe on the Windows host.Make sure the port number is 0.
   Then press 'Start acquiring' button.
   <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\host\TCPIPTrc\TCPIPTrc.exe

4. Upon success packets received by the blackfin are printed on the windows host program.

More information is provided in the <install_path>\Blackfin\lib\src\lwip\contrib\ports\ADSP-Blackfin\docs\lwip_userguide.doc.



#################################################################
#
# Readme.txt file
#
#################################################################

The FileServer application provides Windows host support to enable standard 
C/C++ file input/output from the Blackfin to be received/sent to the host over
TCP/IP connections.

This application consists of a Windows MFC based host program and a Blackfin 
fileserver program. 

Windows Host program  : <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\Host\FILESERVER\FileServer.exe
Blackfin projects     : <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\FileServerStdio


NOTE: Users *MUST* set the FileServer host address in the Blackfin project as
described in the below steps. IP address of a windows machine can be obtained
by 'ipconfig' utility. At the DOS command prompt execute the below instruction.

cmd>ipconfig
Output:
#####
Windows IP ConfigurationEthernet adapter 
Local Area Connection:        
Connection-specific DNS Suffix  . : analog.com 
   IP Address. . . . . . . . . . . . : 10.64.204.155
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : 10.64.204.1
######

In which  10.64.204.155 is the IP address.

Instructions to run the program:
-------------------------------
1 Open  <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\FileServerStdio\BF53x project

2. Open lwip_sysboot_threadtype.c file, and change the FILE_SERVER_HOST_ADDRESS
   to the IP address of the Windows host on which Fileserver runs.This symbol is
   located at the top of the file.
   
3. Build and load the dxe.

4. Run the FilServer.exe on the Windows host.
   <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\Host\FILESERVER\FileServer.exe

5. Run the dxe at the blackfin end. 

6. Examine the output on the Windows Host program. Stdio of the Blackfin program
   is redirected to the Windows host program.

Note:
----
[a] The program by default uses c:\tmp directory on the windows host machine. If this directory is not present then output will be only written to the console.

[b] If Firewall protection software is running on Windows host then it may block the incoming connections.

More information is provided in the <install_path>\Blackfin\lib\src\lwip\contrib\ports\ADSP-Blackfin\docs\lwip_userguide.doc.

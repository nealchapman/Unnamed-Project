#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "Common\trace_int.h"
#include <lwip/sockets.h>
#include <lwip/inet.h>
#include "lwip\kernel_abs.h"
#include "Common\trace.h"


#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define closescket(s) lwip_close(s)

static int Trace_Socket = INVALID_SOCKET;
static long Trace_Host = 0;
static int Trace_Port=0;
static int Trace_Sem;
int Trace_Stack_Started=0;



//#################################################################
//		TraceClose
//#################################################################
static void TraceClose(TraceInfo *trc)
{
	trc->m_TrcData->Active = 0;
	if (Trace_Socket != INVALID_SOCKET) {
		lwip_close(Trace_Socket);
		Trace_Socket = INVALID_SOCKET;
	}
	trc->m_NxtByte = 0;
}
//#################################################################
//		TraceConnect
//#################################################################
int TraceConnect(TraceInfo *trc)
{
	int s;
	struct sockaddr_in ra,sa;

	if (Trace_Socket != INVALID_SOCKET) {
		TraceClose(trc);
	}
	// create the socket 
	s = socket(AF_INET, SOCK_STREAM, 0);  
	if (s != INVALID_SOCKET) {
		// Initilaize receiver's parameters
		memset((char *)&ra,0,sizeof(ra));
		ra.sin_family = AF_INET;
		ra.sin_addr.s_addr = Trace_Host;
		ra.sin_port = Trace_Port;  
		// Try to establish connection
		if ( connect(s, ( struct sockaddr *) &ra, sizeof(struct sockaddr_in) ) == SOCKET_ERROR) {
			lwip_close(s);
		} else {
			int nb=1;
			char bf[36];
			int mr;
			int nread=0;
			
			Trace_Socket = s;
				// can we check for receive data
			while (nread<36) {
				mr = recv(Trace_Socket,bf+nread,36-nread,0);
				if (mr>0) {
					// we have some data to process
					nread += mr;
					if (nread>=36) {
						memcpy(trc->m_TrcData,bf,36);
					}
				} else {
					if (mr<0) {
						// the connection has failed 
						TraceClose(trc);
						break;
					}
				}
			}
			TracePoll(trc);
		}
	}
	return (Trace_Socket != INVALID_SOCKET);
}


//#################################################################
//		TracePoll
//#################################################################
void TracePoll(TraceInfo *trc)
{
	if ((trc->m_NxtByte>0) && (trc->m_NxtByte>trc->m_SendNow)) {
		TraceWrite(trc);
	}
}


//#################################################################
//		TraceWrite
//#################################################################
void TraceWrite(TraceInfo *trc)
{

	if ((Trace_Socket == INVALID_SOCKET) || ((trc->m_NxtByte>0) && (trc->m_NxtByte>trc->m_SendNow))) {
		ker_post_semaphore(Trace_Sem);
		
	}
}


//#################################################################
//		TraceEmpty
//#################################################################
void TraceEmpty(TraceInfo *trc)
{
	// we have to wait till the there is at least room for one trace entry
	while (trc->m_NxtByte+trc->m_MaxBytes>=trc->m_BufSize) {
		TraceWrite(trc);
	}
}



//#################################################################
//		TraceInit
//#################################################################
int TraceInit(TraceInfo *trc, char *HostAddr, int portno)
{
	
	Trace_Socket = INVALID_SOCKET;
	Trace_Host = inet_addr(HostAddr);
	Trace_Port = htons(portno);
	
	Trace_Sem = ker_get_semaphore(0,1);
	if (Trace_Sem ==  ker_err_sem_cre) {
		return Trace_NO_RESOURCES;
	}
	TraceConnect(trc);
	SetTraceFunction(Trace_Event);
	Trace_Stack_Started = 1;	// release the poller thread
	return 0; 
}


//#################################################################
//		TraceMaintain
//#################################################################
void TraceMaintain(TraceInfo *trc)
{
	int mr=0;

	while (1) {
		ker_pend_semaphore(Trace_Sem,1000); 
		if (Trace_Socket == INVALID_SOCKET) {
			// try to re-estsblish the connection
			TraceConnect(trc);
		}
		if (Trace_Socket != INVALID_SOCKET) {
			if (trc->m_NxtByte>0) {
				mr = send(Trace_Socket,(void *)trc->m_TrcData->TrcBytes,trc->m_NxtByte,0);
				if (mr>0) {
					// some data has been sent
					if (mr<trc->m_NxtByte) {
						memcpy(trc->m_TrcData->TrcBytes,trc->m_TrcData->TrcBytes+mr,trc->m_NxtByte-mr);
						trc->m_NxtByte -= mr;
					} else {
						trc->m_NxtByte = 0;
					}
				} else {
					if (mr<0) {
						// the connection has failed 
						TraceClose(trc);
						ker_post_semaphore(Trace_Sem);
					}
				}
			}
#if 0			
			// can we check for receive data
			int mr;
			char bf[36];
			mr = recv(Trace_Socket,bf,36,0);
			if (mr>0) {
				// we have some data to process
				memcpy(trc->m_TrcData,bf,mr);
			} else {
				if (mr<0) {
					// the connection has failed 
					TraceClose(trc);
					ker_post_semaphore(Trace_Sem);
				}
			}
#endif			
		}
	}
}


#################################################################
#
# Readme.txt file
#
#################################################################

The TCPIP Tracing application provides Windows host support to allow the 
recording of events as they happen and to trace all or some packets as they
are being sent or received by the Blackfin application and stack. 

This application consists of a Windows MFC based host program and a Blackfin 
trace program. 

Windows Host program  : <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\Host\TCPIPTrc\TCPIPTrc.exe
Blackfin projects     : <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\TCPIP_Trace


NOTE: Users *MUST* set the Trace server host address in the Blackfin project as
described in the below steps. IP address of a windows machine can be obtained
by 'ipconfig' utility. At the DOS command prompt execute the below instruction.

cmd>ipconfig
Output:
#####
Windows IP ConfigurationEthernet adapter 
Local Area Connection:        
Connection-specific DNS Suffix  . : analog.com 
   IP Address. . . . . . . . . . . . : 10.64.204.155
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : 10.64.204.1
######

In which  10.64.204.155 is the IP address.

Instructions to run the program:
-------------------------------
1 Open <install_path>\Blackfin\Examples\ADSP-BF537 Ez-kit Lite\LAN\TCPIP_Trace\BF5xx project

2. Open 'lwip_sysboot_threadtype.c' file, and change the 'TRACE_OUT_HOST_ADDRESS' to the IP address of the Windows 
   host on which TCPIPTrc runs. This symbol is located at the top of the file.
   
3. Build and load the dxe.

4. Run the TCPIPTrc.exe on the Windows host.Make sure the port number is 20000.
   Then press 'Start acquiring' button.
   <install_path>\Blackfin\Examples\ADSP-BF548 Ez-kit Lite\LAN\Host\TCPIPTrc\TCPIPTrc.exe

5. Run the dxe at the blackfin end. 

6. Upon success packets received by the blackfin are printed in the windows host program.

   More information is provided in the <install_path>\Blackfin\lib\src\lwip\contrib\ports\ADSP-Blackfin\docs\lwip_userguide.doc.
   



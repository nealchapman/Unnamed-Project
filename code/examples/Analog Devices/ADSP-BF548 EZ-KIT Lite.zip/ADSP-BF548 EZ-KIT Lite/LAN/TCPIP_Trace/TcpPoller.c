/* =============================================================================
 *
 *  Description: This is a C implementation for Thread TcpPoller
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

/* Get access to any of the VDK features & datatypes used */
#include <stdio.h>
#include "TcpPoller.h"
#include "Common\trace.h"

extern int Trace_Stack_Started;
void
TcpPoller_RunFunction(void **inPtr)
{
    /* Put the thread's "main" Initialization HERE */

    while (!Trace_Stack_Started) {
    	VDK_Sleep(100);
    }
	

    while (1)
    {
    	Trace_Maintain();
    }


    /* Put the thread's exit from "main" HERE */
    /* A thread is automatically Destroyed when it exits its run function */
}

int
TcpPoller_ErrorFunction(void **inPtr)
{

    /* TODO - Put this thread's error handling code HERE */

      /* The default ErrorHandler kills the thread */

	VDK_DestroyThread(VDK_GetThreadID(), false);
	return 0;
}

void
TcpPoller_InitFunction(void **inPtr, VDK_ThreadCreationBlock *pTCB)
{
    /* Put code to be executed when this thread has just been created HERE */

    /* This routine does NOT run in new thread's context.  Any non-static thread
     *   initialization should be performed at the beginning of "Run()."
     */
}

void
TcpPoller_DestroyFunction(void **inPtr)
{
    /* Put code to be executed when this thread is destroyed HERE */

    /* This routine does NOT run in the thread's context.  Any VDK API calls
     *   should be performed at the end of "Run()."
     */
}

/* ========================================================================== */

/* =============================================================================
 *
 *  Description: This is a C++ to C Thread Header file for Thread TcpPoller
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

#ifndef _TcpPoller_H_
#define _TcpPoller_H_

#include "VDK.h"

#ifdef __ECC__	/* for C/C++ access */
#ifdef __cplusplus
extern "C" void TcpPoller_InitFunction(void**, VDK::Thread::ThreadCreationBlock *);
#else
extern "C" void TcpPoller_InitFunction(void**, VDK_ThreadCreationBlock *);
#endif
extern "C" void TcpPoller_DestroyFunction(void**);
extern "C" int  TcpPoller_ErrorFunction(void**);
extern "C" void TcpPoller_RunFunction(void**);
#endif /* __ECC__ */

#ifdef __cplusplus
#include <new>

class TcpPoller_Wrapper : public VDK::Thread
{
public:
    TcpPoller_Wrapper(VDK::ThreadCreationBlock &t)
        : VDK::Thread(t)
    { TcpPoller_InitFunction(&m_DataPtr, &t); }

    ~TcpPoller_Wrapper()
    { TcpPoller_DestroyFunction(&m_DataPtr); }

    int ErrorHandler()
    { 
      return TcpPoller_ErrorFunction(&m_DataPtr);
     }

    void Run()
    { TcpPoller_RunFunction(&m_DataPtr); }

    static VDK::Thread* Create(VDK::Thread::ThreadCreationBlock &t)
    { return new (t) TcpPoller_Wrapper(t); }
};

#endif /* __cplusplus */
#endif /* _TcpPoller_H_ */

/* ========================================================================== */

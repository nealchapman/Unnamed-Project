#ifndef _DNS_H_
#define _DNS_H_


#define DNS_PORT 53

typedef enum _dns_q_type_e
{
	DNS_REQ,
	DNS_RES
}dns_q_type_e;

typedef struct _mx_record
{
	int ip_addr;
	struct _mx_record *next;
}mx_record;


int dns_make_query(int id,char *dns_pkt,dns_q_type_e qtype,
				    char *host_name);

int dns_query_hostname(char *host_name);
#endif /* _DNS_H_ */

/* =============================================================================
 *
 *  Description: This is a C implementation for Thread DnsClientThread
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

/* Get access to any of the VDK features & datatypes used */
#include "DnsClientThread.h"

#include <lwip/cglobals.h>
#include <stdio.h>
#include <string.h>


int dns_query_hostname(char *host_name);
static char host_name_to_query[] = "analog.com";

void
DnsClientThread_RunFunction(void **inPtr)
{
    /* Put the thread's "main" Initialization HERE */

   /* quries IP address for the name specified in the host_name_to_query[]" */
    dns_query_hostname(host_name_to_query);

    /* Put the thread's exit from "main" HERE */
    /* A thread is automatically Destroyed when it exits its run function */
}

int
DnsClientThread_ErrorFunction(void **inPtr)
{

    /* TODO - Put this thread's error handling code HERE */

      /* The default ErrorHandler kills the thread */

	VDK_DestroyThread(VDK_GetThreadID(), false);
	return 0;
}

void
DnsClientThread_InitFunction(void **inPtr, VDK_ThreadCreationBlock *pTCB)
{
    /* Put code to be executed when this thread has just been created HERE */

    /* This routine does NOT run in new thread's context.  Any non-static thread
     *   initialization should be performed at the beginning of "Run()."
     */
}

void
DnsClientThread_DestroyFunction(void **inPtr)
{
    /* Put code to be executed when this thread is destroyed HERE */

    /* This routine does NOT run in the thread's context.  Any VDK API calls
     *   should be performed at the end of "Run()."
     */
}

/* ========================================================================== */

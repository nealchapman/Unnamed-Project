
##########################################################################
#
# Readme.txt
#
##########################################################################

Description:
-----------
Domain Name System or DNS is a distributed database that is used by the TCP/IP
applications to map between the Host Names and IP addresses. DNS protocol 
allows the client and server to communicate each other.

This simple DNS client example talks to the DNS server in the LAN and retrieves
the ANALOG.COM's IP address.  

NOTE:
*****  TO-DO  *******
Applications must manually setup the DNS server address by setting up the
DNS_HOST_ADDRR in dns.c file. Application Will NOT work without this change.

One can find their DNS server by executing 'nslookup.exe' at the DOS prompt.
The output is something like this

Command -->
cmd>nslookup

Output -->
Default Server: default-dns-server
Address: 192.1.24.24

If users want to Query different domain/hostname
they can change the variable 'host_name_to_query[]' in DnsClientThread.c.



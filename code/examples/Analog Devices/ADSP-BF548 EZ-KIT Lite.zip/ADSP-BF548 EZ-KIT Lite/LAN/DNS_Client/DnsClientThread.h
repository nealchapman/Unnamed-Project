/* =============================================================================
 *
 *  Description: This is a C++ to C Thread Header file for Thread DnsClientThread
 *
 * -----------------------------------------------------------------------------
 *  Comments:
 *
 * ===========================================================================*/

#ifndef _DnsClientThread_H_
#define _DnsClientThread_H_

#include "VDK.h"

#ifdef __ECC__	/* for C/C++ access */
#ifdef __cplusplus
extern "C" void DnsClientThread_InitFunction(void**, VDK::Thread::ThreadCreationBlock *);
#else
extern "C" void DnsClientThread_InitFunction(void**, VDK_ThreadCreationBlock *);
#endif
extern "C" void DnsClientThread_DestroyFunction(void**);
extern "C" int  DnsClientThread_ErrorFunction(void**);
extern "C" void DnsClientThread_RunFunction(void**);
#endif /* __ECC__ */

#ifdef __cplusplus
#include <new>

class DnsClientThread_Wrapper : public VDK::Thread
{
public:
    DnsClientThread_Wrapper(VDK::ThreadCreationBlock &t)
        : VDK::Thread(t)
    { DnsClientThread_InitFunction(&m_DataPtr, &t); }

    ~DnsClientThread_Wrapper()
    { DnsClientThread_DestroyFunction(&m_DataPtr); }

    int ErrorHandler()
    { 
      return DnsClientThread_ErrorFunction(&m_DataPtr);
     }

    void Run()
    { DnsClientThread_RunFunction(&m_DataPtr); }

    static VDK::Thread* Create(VDK::Thread::ThreadCreationBlock &t)
    { return new (t) DnsClientThread_Wrapper(t); }
};

#endif /* __cplusplus */
#endif /* _DnsClientThread_H_ */

/* ========================================================================== */

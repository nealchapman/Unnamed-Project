################################################################
#
#  Readme.txt	
#
################################################################

Webserver:
Go-ahead webserver ported on to Blackfin using lwIP TCP/IP stack and
VDK. This example demonstrates HTTP server functionality. A set of
ROM based files were used. 

Directory Information:
---------------------
	ws031202\     - Go Ahead library sources.
	.        - BF548 webserver and library projects.
	ws031202\web\ - Utility to generate files(html) data in a .c file.
			The generated file is build with the webserver. 
			See webrom.c. A seperate Readme.txt provided in this
                        directory on 'how to build' your own html pages.
Proejcts:
--------
Two project files in the BF548 and BF537 directories hold the application
and Go Ahead webserver libraries. 

A Project Group file is present in each directory (.dpg) which facilitate to
build the library and the application together.

Build for BF548 [analogous to BF537]:
------------------------------------
1. Open httpsvr-grpbf548.dpg in the IDDE through  "File->Open->Project Group"
2. It opens TWO projects, httpserver-BF548.dpj and libwebsvrbf548.dpj.
3. Build the httpserver-bf548.dpj project. It builds the library & application.
4. Run the application.

Application prints the URL to access, something like

Webserver running# Type  'http://10.64.204.167/blackfin.html' from window|unix browser

Test:
----
Open Netscape or Internet Explorer Browser and paste the printed URL in the VisualDSP++. Server responds with the HTML pages.


################################################################
#
# Readme
#
################################################################

Description:
This file describes how to build your own webserver pages using GoAhead's 
webcomp utility. webcomp utitily executable is present in the web\ directory.
webcomp.c file is present in ws031202 directory. one can used Microsoft 
visualC++ compiler to build the same executable. 


webcomp utilty takes set of html files and generates a data file by placing
data in a static array. The list of files to be compiled are specified in 
'files' file.

For example to generate an output file 'webrom.c' by taking files present in
'files' one would use the below command  at the dos prompt in the web\.
   webcomp.exe / files > webrom.c


To build your own server pages:

1. copy the files into the web\ directory.
2. Add the list of files that are used by the server into 'files' file.
3. Generate the .c file using webcomp.exe utility as below at the dos prompt.
   webcomp.exe / files > webrom.c
4. copy the newly generated webrom.c file in to ws031202 directory.
5. rebuild the libwebsvrxx library and the associated httmpserver-BFxx project.

The new webserver services the newly built pages.

Note:
In the web\ directory the file 'files' holds the list of files that are 
serviced by the webserver.

webrom.c is the generated file from the webcomp utility taking 



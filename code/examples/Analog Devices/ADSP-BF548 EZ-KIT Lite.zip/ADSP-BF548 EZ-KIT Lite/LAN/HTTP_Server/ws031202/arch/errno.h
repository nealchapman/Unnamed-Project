#ifndef __ERRNO_H_
#define __ERRNO_H_

#ifdef ERRNO
int errno;
#endif
int GetSocketError(void);
#endif /* __ERRNO_H_ */
